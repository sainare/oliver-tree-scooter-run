                                                                



import math

import random



import pygame



import sprites as sp

from settings import (CANVAS_W, CANVAS_H, GROUND_Y, PLAYER_X, RIDER_SCALE, SPEED_START,

                      SPEED_MAX, SPEED_GAIN, SPEED_LOCK, START_LIVES, INVULN_FRAMES, OBST_LEVELS, PREP_ITEMS, START_LEVELS,

                      BACKFLIP_CHANCE, BACKFLIP_BONUS, TAPES, TAPE_BONUS,

                      TRICKS, TRICK_COOLDOWN, SLOW_FRAMES, SLOW_START,

                      ZONES, ZONE_SCORE, ZONE_FX_FRAMES,

                      MAX_LIVES, LIFE_CHANCE, LIFE_MIN_GAP,

                      RAMP_APEX, RAMP_APEX_JUMP, RAMP_GRAV, RAMP_JUMP_GRACE,

                      RAMP_JUMP_AHEAD,

                      RAMP_BONUS, RAMP_SUPER_BONUS, RAMP_REACH,

                      BOOST_FRAMES, BOOST_SECONDS, BOOST_CHANCE, BOOST_MIN_GAP,

                      C_SKY_TOP, C_SKY_BOT, C_CLOUD, C_CLOUD_SH, C_CITY,

                      C_CITY_DARK, C_CITY_WIN, C_TREE, C_TREE_DARK, C_TRUNK,

                      C_ROAD, C_ROAD_HI, C_ROAD_DARK, C_ROAD_LINE,

                      C_WHITE, C_BLACK, C_YELLOW, C_STAR, C_CYAN,
                      FRUTIGER_UNLOCK_SCORE, FRUTIGER_TAPE_LABEL)



                                                                         

                                                                                  

RIDE_H = round((sp.SPR_H + 2) * RIDER_SCALE)

                                                             

RIDE_OFF = round((sp.WHEEL_BACK[1] + sp.WHEEL_R + 1) * RIDER_SCALE)



                                                                          

INTRO_WAIT = 40

INTRO_BLINK = 16

INTRO_DARK = 120                                                          

INTRO_ACCEL = 0.075



                                                                     

                                                                        

HIT_X, HIT_W = PLAYER_X + round(9 * RIDER_SCALE), round(15 * RIDER_SCALE)

HIT_TOP = round(42 * RIDER_SCALE)







def _cloud(pal, size, face=False):

                                                                             

    w, h = (30, 12) if size == 0 else ((44, 16) if size == 1 else (60, 20))

    s = pygame.Surface((w, h), pygame.SRCALPHA)

    body, shade = pal["cloud"], pal["cloud_sh"]

    lumps = ((0.10, 0.40), (0.30, 0.10), (0.55, 0.22), (0.76, 0.45))

    for fx, fy in lumps:

        bw = int(w * 0.34)

        bh = int(h * (0.95 - fy))

        s.fill(body, pygame.Rect(int(w * fx), int(h * fy), bw, bh))

    s.fill(body, pygame.Rect(1, int(h * 0.55), w - 2, int(h * 0.45)))

    s.fill(shade, pygame.Rect(2, h - 3, w - 4, 2))                      

    if face and size > 0:

        eye_y = int(h * 0.44)

        for ex in (int(w * 0.36), int(w * 0.58)):

            s.fill(shade, pygame.Rect(ex, eye_y, 2, 3))

        smile_y = eye_y + 5                                               

        s.fill(shade, pygame.Rect(int(w * 0.38), smile_y + 1, 6, 1))

        s.fill(shade, pygame.Rect(int(w * 0.36), smile_y, 1, 1))

        s.fill(shade, pygame.Rect(int(w * 0.38) + 6, smile_y, 1, 1))

    return s





def _tree(pal, tall):

                                                                      

    w, h = (34, 44) if tall else (26, 34)

    s = pygame.Surface((w, h), pygame.SRCALPHA)

    ch_ = int(h * 0.78)                                                   

    light, dark = pal["tree"], pal["tree_dark"]

    mid = tuple(int(c * 0.8) for c in light)

    s.fill(dark, pygame.Rect(1, 5, w - 2, ch_ - 5))                       

    s.fill(dark, pygame.Rect(4, 2, w - 8, ch_ - 1))

    s.fill(dark, pygame.Rect(8, 0, w - 16, ch_))

    s.fill(mid, pygame.Rect(3, 6, w - 10, ch_ - 12))                     

    s.fill(mid, pygame.Rect(7, 3, w - 16, ch_ - 8))

    s.fill(light, pygame.Rect(5, 7, w - 17, ch_ - 18))                  

    s.fill(light, pygame.Rect(9, 4, w - 22, 4))

    s.fill(pal["trunk"], pygame.Rect(w // 2 - 3, ch_ - 3, 6, h - ch_ + 3))

    return s





def _palm(pal, tall):

                                             

    w, h = (30, 46) if tall else (24, 36)

    s = pygame.Surface((w, h), pygame.SRCALPHA)

    light, dark = pal["tree"], pal["tree_dark"]

    cx, top = w // 2, 6

    s.fill(pal["trunk"], pygame.Rect(cx - 2, top, 4, h - top))

    for i, (dx, dy) in enumerate(((-11, 2), (-7, -3), (0, -5),

                                  (7, -3), (11, 2))):

        col = light if i % 2 else dark

        s.fill(col, pygame.Rect(cx + min(dx, 0), top + dy, abs(dx) + 3, 3))

    s.fill(light, pygame.Rect(cx - 4, top - 4, 9, 4))

    return s





def _pine(pal, tall):

                                        

    w, h = (26, 48) if tall else (20, 36)

    s = pygame.Surface((w, h), pygame.SRCALPHA)

    light, dark = pal["tree"], pal["tree_dark"]

    cx = w // 2

    s.fill(pal["trunk"], pygame.Rect(cx - 2, h - 7, 4, 7))

    tier_h = (h - 7) // 3

    for k in range(3):

        top = k * tier_h

        for i in range(tier_h):

            half = int((w // 2) * (0.35 + 0.65 * (i / max(tier_h - 1, 1))))

            s.fill(dark if i > tier_h * 0.6 else light,

                   pygame.Rect(cx - half, top + i, half * 2, 1))

    return s





def _cactus(pal, tall):

                                   

    w, h = (22, 40) if tall else (18, 30)

    s = pygame.Surface((w, h), pygame.SRCALPHA)

    light, dark = pal["tree"], pal["tree_dark"]

    cx = w // 2

    s.fill(light, pygame.Rect(cx - 3, 4, 7, h - 4))

    s.fill(dark, pygame.Rect(cx + 2, 4, 2, h - 4))

    s.fill(light, pygame.Rect(2, 12, 4, 3))                          

    s.fill(light, pygame.Rect(2, 8, 3, 7))

    s.fill(light, pygame.Rect(w - 6, 18, 4, 3))                  

    s.fill(light, pygame.Rect(w - 5, 13, 3, 8))

    s.fill(dark, pygame.Rect(cx - 3, 4, 1, h - 4))

    return s





_SCENERY = {"tree": _tree, "palm": _palm, "pine": _pine, "cactus": _cactus}





def _backdrop_city(pal, rng):

                                    

    city = pygame.Surface((CANVAS_W, CANVAS_H), pygame.SRCALPHA)

    x = 0

    while x < CANVAS_W:

        w = rng.randint(14, 28)

        h = rng.randint(20, 50)

        top = GROUND_Y - 20 - h

        city.fill(pal["city"], pygame.Rect(x, top, w, h + 20))

        city.fill(pal["city_dark"], pygame.Rect(x + w - 3, top, 3, h + 20))

        for wy in range(top + 4, GROUND_Y - 22, 7):

            for wx in range(x + 3, x + w - 5, 6):

                if rng.random() < 0.5:

                    city.fill(pal["city_win"], pygame.Rect(wx, wy, 2, 3))

        x += w + rng.randint(1, 5)

    return city





def _mixc(a, b, k):

                                                        

    return tuple(int(x + (y - x) * k) for x, y in zip(a, b))





def _backdrop_mountains(pal, rng):

    



       

    back = pygame.Surface((CANVAS_W, CANVAS_H), pygame.SRCALPHA)

    rock = _mixc(pal["city"], pal["cloud"], 0.32)

    rock_dark = _mixc(pal["city_dark"], pal["cloud"], 0.15)

    snow = pal["cloud"]

    x = -20

    while x < CANVAS_W + 20:

        half = rng.randint(24, 46)

        h = rng.randint(34, 64)

        base = GROUND_Y - 18

        for i in range(h):                                          

            w = int(half * 2 * (i / h))

            back.fill(rock, pygame.Rect(x + half - w // 2,

                                        base - h + i, w, 1))

            if i < h * 0.22:                                    

                back.fill(snow,

                          pygame.Rect(x + half - w // 2, base - h + i, w, 1))

        back.fill(rock_dark,

                  pygame.Rect(x + half, base - h, 2, h))                    

        back.fill(rock, pygame.Rect(x - 4, base, half * 2 + 8, 18))

        x += half + rng.randint(10, 34)

    return back





def _backdrop_hills(pal, rng):

                                            

    back = pygame.Surface((CANVAS_W, CANVAS_H), pygame.SRCALPHA)

    for plan, color in ((0, pal["city_dark"]), (1, pal["city"])):

        base = GROUND_Y - 18 + plan * 6

        x = -30

        while x < CANVAS_W + 30:

            rw = rng.randint(38, 72)

            rh = rng.randint(16, 34) + plan * 6

            pygame.draw.ellipse(back, color,

                                pygame.Rect(x, base - rh, rw, rh * 2))

            x += rw // 2 + rng.randint(6, 20)

        back.fill(color, pygame.Rect(0, base, CANVAS_W, 20))

    return back





def _backdrop_mesas(pal, rng):

                                                    

    back = pygame.Surface((CANVAS_W, CANVAS_H), pygame.SRCALPHA)

    x = -16

    while x < CANVAS_W + 16:

        w = rng.randint(26, 54)

        h = rng.randint(22, 46)

        top = GROUND_Y - 18 - h

        back.fill(pal["city"], pygame.Rect(x, top, w, h + 18))

        back.fill(pal["city_dark"], pygame.Rect(x + w - 4, top, 4, h + 18))

        back.fill(pal["city_win"], pygame.Rect(x, top, w, 2))                     

        for k in range(1, 4):                                                  

            back.fill(pal["city_dark"],

                      pygame.Rect(x, top + int(h * k / 4), w, 1))

        x += w + rng.randint(8, 30)

    return back





def _backdrop_factory(pal, rng):

                                              

    back = pygame.Surface((CANVAS_W, CANVAS_H), pygame.SRCALPHA)

    x = 0

    while x < CANVAS_W:

        w = rng.randint(26, 42)

        h = rng.randint(16, 30)

        top = GROUND_Y - 18 - h

        back.fill(pal["city"], pygame.Rect(x, top, w, h + 18))

        back.fill(pal["city_dark"], pygame.Rect(x, top, w, 2))

        for k in range(rng.randint(1, 3)):                               

            cx = x + 5 + k * 12

            ch_ = rng.randint(14, 30)

            back.fill(pal["city"], pygame.Rect(cx, top - ch_, 5, ch_))

            back.fill(pal["city_dark"], pygame.Rect(cx + 3, top - ch_, 2, ch_))

            back.fill(pal["city_win"], pygame.Rect(cx, top - ch_, 5, 2))

            for d in range(3):                                                

                back.fill(pal["cloud_sh"],

                          pygame.Rect(cx - 2 + d * 2, top - ch_ - 5 - d * 4,

                                      6, 3))

        for wy in range(top + 5, GROUND_Y - 20, 8):

            for wx in range(x + 3, x + w - 4, 7):

                back.fill(pal["city_win"], pygame.Rect(wx, wy, 3, 3))

        x += w + rng.randint(2, 10)

    return back





_BACKDROP = {"city": _backdrop_city, "mountains": _backdrop_mountains,

             "hills": _backdrop_hills, "mesas": _backdrop_mesas,

             "factory": _backdrop_factory}





def make_menu_backdrop():

    



       

    back = pygame.Surface((CANVAS_W, CANVAS_H))

    for y in range(CANVAS_H):                                            

        t = y / CANVAS_H

        back.fill((int(28 + 26 * t), int(10 + 8 * t), int(44 + 30 * t)),

                  pygame.Rect(0, y, CANVAS_W, 1))



    rng = random.Random(7788)

    curtain = (108, 22, 44)

    curtain_hi = (152, 38, 64)

    curtain_sh = (66, 12, 30)

    for x in range(0, CANVAS_W, 10):                                

        w = rng.randint(5, 8)

        back.fill(curtain, pygame.Rect(x, 0, w, GROUND_Y - 18))

        back.fill(curtain_hi, pygame.Rect(x, 0, 2, GROUND_Y - 18))

        back.fill(curtain_sh, pygame.Rect(x + w - 2, 0, 2, GROUND_Y - 18))

    back.fill(curtain_sh, pygame.Rect(0, GROUND_Y - 22, CANVAS_W, 4))

    for x in range(0, CANVAS_W, 16):                                         

        pygame.draw.ellipse(back, curtain,

                            pygame.Rect(x - 2, GROUND_Y - 30, 20, 16))



    stage, stage_hi = (44, 34, 58), (78, 62, 96)          

    back.fill(stage, pygame.Rect(0, GROUND_Y - 18, CANVAS_W, CANVAS_H))

    back.fill(stage_hi, pygame.Rect(0, GROUND_Y - 18, CANVAS_W, 2))

    for x in range(4, CANVAS_W, 24):                                      

        back.fill((252, 226, 140), pygame.Rect(x, GROUND_Y - 13, 3, 3))

        back.fill((160, 130, 60), pygame.Rect(x, GROUND_Y - 10, 3, 1))

    return back





def draw_spotlights(surf, t):

                                                               

    beams = pygame.Surface((CANVAS_W, CANVAS_H))

    beams.fill((0, 0, 0))

    for k, base_x in enumerate((CANVAS_W // 3, CANVAS_W * 2 // 3)):

        swing = math.sin(t * 0.013 + k * 2.1) * 34

        tip = (base_x + swing, GROUND_Y - 10)

        pygame.draw.polygon(beams, (34, 26, 14),

                            [(base_x - 6, -4), (base_x + 6, -4),

                             (tip[0] + 30, tip[1]), (tip[0] - 30, tip[1])])

    surf.blit(beams, (0, 0), special_flags=pygame.BLEND_RGB_ADD)





def make_background(pal):

                                                                   

    sky = pygame.Surface((CANVAS_W, CANVAS_H))

    for y in range(CANVAS_H):

        t = min(1.0, y / (GROUND_Y * 1.05))

        sky.fill(tuple(int(a + (b - a) * t) for a, b in

                       zip(pal["sky_top"], pal["sky_bot"])),

                 pygame.Rect(0, y, CANVAS_W, 1))



    rng = random.Random(20260728)



    if pal["stars"]:                                                        

        for _ in range(46):

            sx, sy = rng.randrange(CANVAS_W), rng.randrange(2, 84)

            sky.fill((236, 240, 255), pygame.Rect(sx, sy, 1, 1))



    clouds = pygame.Surface((CANVAS_W, CANVAS_H), pygame.SRCALPHA)

    sprites_c = [_cloud(pal, 0), _cloud(pal, 1), _cloud(pal, 2),

                 _cloud(pal, 1, face=True), _cloud(pal, 2, face=True)]

    for _ in range(9):

        img = sprites_c[rng.randrange(len(sprites_c))]

        clouds.blit(img, (rng.randrange(-10, CANVAS_W - 10),

                          rng.randrange(6, 74)))



    city = _BACKDROP[pal.get("backdrop", "city")](pal, rng)



    trees = pygame.Surface((CANVAS_W, CANVAS_H), pygame.SRCALPHA)

    grow = _SCENERY[pal.get("scenery", "tree")]

    sprites_t = [grow(pal, False), grow(pal, True)]

    x = rng.randint(0, 40)

    while x < CANVAS_W:

        img = sprites_t[rng.randrange(2)]

        trees.blit(img, (x, GROUND_Y - img.get_height() + 2))

        x += rng.randint(58, 104)



    return dict(sky=sky, clouds=clouds, city=city, trees=trees, pal=pal)





FIRE_COLORS = ((150, 26, 30), (226, 60, 40), (250, 160, 40), (252, 236, 120))





def draw_flames(surf, t, base_y, height=30):

                                                            

    step = 2

    for i, x in enumerate(range(-2, CANVAS_W + 2, step)):

                                                                

        wave = (math.sin(t * 0.20 + i * 0.85) * 0.5

                + math.sin(t * 0.09 + i * 0.31) * 0.5)

        h = int(height * (0.45 + 0.55 * abs(wave)))

        top = base_y - h

        bands = (h, int(h * 0.72), int(h * 0.44), int(h * 0.18))

        for color, bh in zip(FIRE_COLORS, bands):

            if bh > 0:

                surf.fill(color, pygame.Rect(x, base_y - bh, step, bh))

        if h > height * 0.8 and (i + int(t * 0.3)) % 7 == 0:

            surf.fill(FIRE_COLORS[3], pygame.Rect(x, top - 4, step, 2))





def draw_campfire(surf, t, cx, base_y, width=26, height=26):

                                                               

    log = (92, 58, 34)

    log_d = (58, 34, 20)

    ember = (232, 108, 40)



    step = 2

    half = width // 2

    for i, x in enumerate(range(cx - half, cx + half, step)):

        edge = abs(x + step / 2 - cx) / max(half, 1)                          

        wave = (math.sin(t * 0.26 + i * 1.1) * 0.5

                + math.sin(t * 0.13 + i * 0.43) * 0.5)

        h = int(height * (1.0 - edge * edge) * (0.5 + 0.5 * abs(wave)))

        if h <= 0:

            continue

        for color, frac in zip(FIRE_COLORS, (1.0, 0.74, 0.46, 0.2)):

            bh = int(h * frac)

            if bh > 0:

                surf.fill(color, pygame.Rect(x, base_y - bh, step, bh))



    surf.fill(log, pygame.Rect(cx - half, base_y - 1, width, 3))

    surf.fill(log_d, pygame.Rect(cx - half, base_y + 1, width, 1))

    surf.fill(log, pygame.Rect(cx - half - 3, base_y, 6, 2))

    surf.fill(log, pygame.Rect(cx + half - 3, base_y, 6, 2))

    if (t // 6) % 2 == 0:                                                   

        surf.fill(ember, pygame.Rect(cx - 4, base_y, 2, 1))

        surf.fill(ember, pygame.Rect(cx + 3, base_y, 2, 1))





def draw_fire_glow(surf, t, cx, cy):

    



       

    pulse = 0.85 + 0.15 * math.sin(t * 0.14)

    glow = pygame.Surface(surf.get_size())

    glow.fill((0, 0, 0))

    for r, level in ((84, 10), (62, 12), (42, 16), (24, 20)):

        col = (int(level * 1.6 * pulse), int(level * 0.9 * pulse),

               int(level * 0.35 * pulse))

        pygame.draw.circle(glow, col, (cx, cy), int(r * pulse))

    surf.blit(glow, (0, 0), special_flags=pygame.BLEND_RGB_ADD)





class Particle:

                                                                       



    __slots__ = ("x", "y", "vx", "vy", "grav", "life", "age", "color", "size")



    def __init__(self, x, y, vx, vy, color, life, grav=0.0, size=1):

        self.x, self.y = float(x), float(y)

        self.vx, self.vy = vx, vy

        self.grav = grav

        self.life = life

        self.age = 0

        self.color = color

        self.size = size



    def update(self, scroll):

        self.x += self.vx - scroll

        self.y += self.vy

        self.vy += self.grav

        self.age += 1

        return self.age < self.life



    def draw(self, surf):

        if (self.life - self.age) < 6 and self.age % 2:

            return                                                   

        surf.fill(self.color, pygame.Rect(int(self.x), int(self.y),

                                          self.size, self.size))





class Rider:

                               



    def __init__(self, char, frames):

        self.char = char

        self.frames = frames

        self.y = float(GROUND_Y)

        self.vy = 0.0

        self.on_ground = True

        self.jumps_left = 0

        self.anim = 0.0

        self.spin = 0.0

        self.lives = START_LIVES

        self.invuln = 0

        self.dead = False

        self.flip_angle = 0.0                                         

        self.flip_speed = 0.0                                

        self.landed_flip = False                                            

        self.boost = 0                                             

        self.boost_max = BOOST_FRAMES                                                 

        self.fly_t = 0                                                     

        self.holding = False                                             

        self.double_owned = False                           

        self.ground_trick = 0                                 

        self.trick = None                                          

        self.trick_t = 0                                         

        self.landed_trick = None                                   

        self.tilt = 0.0                                                              

        self.trick_cd = 0                                                 

        self.ramp_air = False                                                     

        self.ramp_super = False                                                   

        self.ramp_grace = 0                                                        



    def roll(self, speed):

                                                                       

        self.anim += 0.18 + speed * 0.05

        self.spin += speed * 0.22

        if self.invuln > 0:

            self.invuln -= 1



    @property

    def pose(self):

        if not self.on_ground:

            return "air"

        return "run"



    def image(self):

        idx = int(self.anim) % 4

        return self.frames[self.pose][idx]



    def rect(self):

                                                                        

        return pygame.Rect(HIT_X, int(self.y) - HIT_TOP, HIT_W, HIT_TOP - 1)



    def _try_backflip(self, rng):

                                                                             

        if rng.random() >= BACKFLIP_CHANCE:

            return

        air = 2.0 * abs(self.char["jump"]) / self.char["grav"]

        self.flip_angle = 0.0

        self.flip_speed = 360.0 / max(air * 0.92, 1.0)



    def jump(self, audio, rng=None):

        if self.dead:

            return

        self.holding = True

        if self.fly_t > 0:                                                    

            return

        if self.ramp_air and self.ramp_grace > 0 and not self.ramp_super:

            self.ramp_boost()                                              

            audio.play("jump2")

            return

        if self.on_ground:

            self.vy = self.char["jump"]

            self.on_ground = False

            self.jumps_left = 1 if (self.char["double"] or self.double_owned) else 0

            audio.play("jump")

            if rng is not None:

                self._try_backflip(rng)

        elif self.jumps_left > 0:

                                                                   

            self.vy = min(self.vy, self.char["jump"] * 0.92)

            self.jumps_left -= 1

            audio.play("jump2")



    def release_jump(self):

        




                                            

        self.holding = False

        if self.ramp_air or self.fly_t > 0:

            return

        cap = self.char["jump"] * 0.62

        if self.vy < cap:

            self.vy = cap



    def _ramp_vy(self, apex):

                                                                               

        g = self.char["grav"] * RAMP_GRAV

        rise = max(6.0, apex - (GROUND_Y - self.y))

        return -math.sqrt(2.0 * g * rise)



    def _ramp_air_left(self):

                                                                                

        g = self.char["grav"] * RAMP_GRAV

        up = max(0.0, -self.vy) / g

        top = (GROUND_Y - self.y) + (self.vy * self.vy / (2.0 * g)

                                     if self.vy < 0 else 0.0)

        return up + math.sqrt(2.0 * max(top, 0.0) / g)



    def launch(self, audio, super_jump=False):

        
                                                  

        self.vy = self._ramp_vy(RAMP_APEX_JUMP if super_jump else RAMP_APEX)

        self.on_ground = False

        self.jumps_left = 0                                                

        self.ground_trick = 0

        self.tilt = 0.0

        self.ramp_air = True

        self.ramp_super = super_jump

        self.ramp_grace = 0 if super_jump else RAMP_JUMP_GRACE

                                                                          

        self.flip_angle = 0.0

        self.flip_speed = 360.0 / max(self._ramp_air_left() * 0.9, 1.0)

        audio.play("ramp")



    def ramp_boost(self):

                                                                       

        self.ramp_super = True

        self.ramp_grace = 0

        self.vy = min(self.vy, self._ramp_vy(RAMP_APEX_JUMP))

        left = max(0.0, 360.0 - self.flip_angle)                                    

        self.flip_speed = left / max(self._ramp_air_left() * 0.9, 1.0)



    def start_ground_trick(self, audio):

                                                                        

        if (self.dead or not self.on_ground or self.ground_trick

                or self.trick_cd > 0):

            return False

        self.trick_cd = TRICK_COOLDOWN

        self.ground_trick = TRICKS["wheelie"]["frames"]

        audio.play("trick")

        return True



    def start_trick(self, name, audio):

                                                                  

        if (self.dead or self.on_ground or self.trick or name not in TRICKS

                or self.trick_cd > 0):

            return False

        self.trick_cd = TRICK_COOLDOWN

        self.trick = name

        self.trick_t = 0

        audio.play("trick")

        return True



    def _fly_update(self, speed):

                                                                               

        self.fly_t -= 1

        target = GROUND_Y - (98 if self.holding else 52)

        self.y += (target - self.y) * 0.1

        self.vy = 0.0

        self.on_ground = False

        self.flip_speed = self.flip_angle = 0.0

        self.trick = None

        self.trick_t = 0

        self.ground_trick = 0

        self.tilt = max(-15.0, min(15.0, (target - self.y) * 0.5))

        self.anim += 0.18 + speed * 0.05

        self.spin += speed * 0.22

        if self.trick_cd > 0:

            self.trick_cd -= 1

        if self.invuln > 0:

            self.invuln -= 1

        if self.boost > 0:

            self.boost -= 1

        if self.fly_t == 0:                                                            

            self.tilt = 0.0

            self.invuln = max(self.invuln, 90)



    def update(self, speed):

        if self.fly_t > 0:

            self._fly_update(speed)

            return

        self.vy += self.char["grav"] * (RAMP_GRAV if self.ramp_air else 1.0)

        self.y += self.vy

        if self.ramp_grace > 0:

            self.ramp_grace -= 1

        if self.flip_speed:

            self.flip_angle += self.flip_speed

        if self.ground_trick:

            self.ground_trick -= 1

            if self.ground_trick == 0:

                self.landed_trick = "wheelie"

        if self.trick:

            self.trick_t += 1

            if self.trick_t >= TRICKS[self.trick]["frames"]:

                                                                

                                                                

                self.landed_trick = self.trick

                self.trick = None

                self.trick_t = 0

        if self.y >= GROUND_Y:

            self.y = GROUND_Y

            self.vy = 0.0

            self.on_ground = True

            self.jumps_left = 0

            self.tilt = 0.0

            self.ramp_air = self.ramp_super = False

            self.ramp_grace = 0

            if self.flip_speed:                                                 

                self.landed_flip = self.flip_angle >= 300.0

                self.flip_speed = 0.0

                self.flip_angle = 0.0

            self.trick = None                                              

            self.trick_t = 0

        self.anim += 0.18 + speed * 0.05

        self.spin += speed * 0.22

        if self.trick_cd > 0:

            self.trick_cd -= 1

        if self.invuln > 0:

            self.invuln -= 1

        if self.boost > 0:

            self.boost -= 1



    def hit(self, audio):

        if self.invuln > 0 or self.boost > 0:

            return False

        self.flip_speed = 0.0                                        

        self.flip_angle = 0.0

        self.trick = None

        self.trick_t = 0

        self.lives -= 1

        self.invuln = INVULN_FRAMES

        audio.play("hit")

        if self.lives <= 0:

            self.dead = True

        return True



    def draw(self, surf):

        if self.invuln > 0 and (self.invuln // 4) % 2 == 0 and not self.dead:

            return                                           

        img = self.image()

        base = self.image_rect()

        if self.boost > 0:                                                 

            tint = (255, 236, 120) if (self.boost // 4) % 2 else (140, 226, 255)

            halo = pygame.mask.from_surface(img).to_surface(

                setcolor=tint, unsetcolor=(0, 0, 0, 0))

            for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)):

                surf.blit(halo, (base.x + dx, base.y + dy))

        if self.trick:

            self._draw_trick(surf, base)

            return



        if self.ground_trick:

            self._draw_wheelie(surf, base, img)

            return



        angle = 0.0

        if self.dead:

            angle = -24.0                                              

        elif self.flip_speed:

                                                                        

            angle = round(self.flip_angle / 15.0) * 15.0

        elif self.tilt:

            angle = round(self.tilt / 15.0) * 15.0

        if angle:

            img = pygame.transform.rotate(img, angle)

        surf.blit(img, img.get_rect(center=base.center))



    def _draw_wheelie(self, surf, base, img):

        



           

        spec = TRICKS["wheelie"]

        total, rise = spec["frames"], spec["rise"]

        gone = total - self.ground_trick

        if gone < rise:                                    

            k = gone / rise

        elif self.ground_trick < rise:                    

            k = self.ground_trick / rise

        else:                                              

            k = 1.0

        angle = round(spec["angle"] * k / 6.0) * 6.0

        if not angle:

            surf.blit(img, base)

            return

        pivot = (round((sp.WHEEL_BACK[0] + 1) * RIDER_SCALE),

                 round((sp.WHEEL_BACK[1] + 1) * RIDER_SCALE))

        rot = pygame.transform.rotate(img, angle)

        rad = math.radians(angle)

        ox = pivot[0] - img.get_width() / 2

        oy = pivot[1] - img.get_height() / 2

        rx = ox * math.cos(rad) + oy * math.sin(rad)

        ry = -ox * math.sin(rad) + oy * math.cos(rad)

        cx = base.x + pivot[0] - rx

        cy = base.y + pivot[1] - ry

        surf.blit(rot, rot.get_rect(center=(cx, cy)))



    def _draw_trick(self, surf, base):

                                                                       

        idx = int(self.anim) % 4

        body = self.frames["body"][0]

        scooter = self.frames["scooter"][idx]

        prog = min(1.0, self.trick_t / TRICKS[self.trick]["frames"])

        flip = round(self.flip_angle / 15.0) * 15.0 if self.flip_speed else 0.0



        if self.trick == "tailwhip":

                                                                 

            ang = round(prog * 360.0 / 20.0) * 20.0

            spun = pygame.transform.rotate(scooter, ang)

            surf.blit(spun, spun.get_rect(center=base.center))

            b = pygame.transform.rotate(body, flip) if flip else body

            surf.blit(b, b.get_rect(center=base.center))

        else:

                                                                  

            reach = math.sin(prog * math.pi)

            dx = int(-13 * reach)

            dy = int(-5 * reach)

            s = pygame.transform.rotate(scooter, flip) if flip else scooter

            surf.blit(s, s.get_rect(center=base.center))

            b = pygame.transform.rotate(body, flip) if flip else body

            r = b.get_rect(center=base.center)

            surf.blit(b, (r.x + dx, r.y + dy))



    def image_rect(self):

                                                                            

        img = self.image()

        return pygame.Rect(PLAYER_X - 1, int(self.y) - RIDE_OFF,

                           img.get_width(), img.get_height())





class Obstacle:

    def __init__(self, kind, image, x):

        self.kind = kind

        self.used = False                                              

        self.jumped = False                                                        

        self.image = image

        self.x = float(x)

        w, h = image.get_size()

        self.y = GROUND_Y - h + 2

        self.w, self.h = w, h



    def rect(self):

                                                                    

        return pygame.Rect(int(self.x) + 1, int(self.y) + 1,

                           self.w - 2, self.h - 2)



    def draw(self, surf):

        surf.blit(self.image, (int(self.x), int(self.y)))





class Pickup:

                                                                                    



    def __init__(self, image, x, y, kind="tape", tape=0, ramp=None):

        self.image = image

        self.x = float(x)

        self.y = float(y)

        self.kind = kind

        self.tape = tape

        self.ramp = ramp                                                         

        self.taken = False

        self._mask = None

        self.bob = random.random() * 6.28



    def rect(self):

                                                           

        w, h = self.image.get_size()

        return pygame.Rect(int(self.x) - 2, int(self.y) - 3, w + 4, h + 6)



    def center(self):

        w, h = self.image.get_size()

        return self.x + w / 2.0, self.y + h / 2.0



    def draw(self, surf, t):

        dy = math.sin(t * 0.12 + self.bob) * 2

        if self.kind == "star":                                                 

            x, y = int(self.x), int(self.y + dy)

            w, h = self.image.get_size()

            if self._mask is None:                                                      

                self._mask = pygame.mask.Mask((w, h))

                for gx in range(w):

                    for gy in range(h):

                        c = self.image.get_at((gx, gy))

                        if c.a and c.r > 150:

                            self._mask.set_at((gx, gy), 1)

            pulse = abs(math.sin(t * 0.1))

            glow = self._mask.to_surface(

                setcolor=(10 + int(pulse * 70), 8 + int(pulse * 55), 0, 255),

                unsetcolor=(0, 0, 0, 255))

            surf.blit(self.image, (x, y))

            surf.blit(glow, (x, y), special_flags=pygame.BLEND_RGB_ADD)

            for k in range(2):                                                 

                if (t // 5 + k) % 3 == 0:

                    continue

                a = t * 0.07 + k * math.pi

                sx = int(x + w / 2 + math.cos(a) * (w * 0.78))

                sy = int(y + h / 2 + math.sin(a) * (h * 0.78))

                for ddx, ddy in ((0, 0), (-1, 0), (1, 0), (0, -1), (0, 1)):

                    surf.fill((255, 250, 210), pygame.Rect(sx + ddx, sy + ddy, 1, 1))

        else:

            x, y = int(self.x), int(self.y + dy)

            surf.blit(self.image, (x, y))

            phase = (t + int(self.bob * 16)) % 90

            if self.kind in ("tape", "tape_frutiger") and phase < 9:

                k = 2 if 2 < phase < 6 else 1

                sx, sy = x + self.image.get_width() - 4, y + 2

                for ddx, ddy in ((0, 0), (-k, 0), (k, 0), (0, -k), (0, k)):

                    surf.fill((255, 252, 230), pygame.Rect(sx + ddx, sy + ddy, 1, 1))





class Heli:

                                                          



    def __init__(self, frames, rng):

        self.right = rng.random() < 0.5                                

        pair = frames["right"] if self.right else frames["left"]

        self.frames = pair

        self.w = pair[0].get_width()

        self.y = float(rng.randint(14, 62))

        self.vx = rng.uniform(0.55, 1.05) * (1 if self.right else -1)

                                                                   

        self.x = float(-self.w - 4) if self.right else float(CANVAS_W + 4)

        self.phase = rng.random() * 6.28

        self.t = 0



    def update(self, scroll):

        self.t += 1

        self.x += self.vx - scroll * 0.12                                      

        return -self.w - 10 < self.x < CANVAS_W + 10



    def draw(self, surf):

        img = self.frames[(self.t // 2) % 2]                           

        bob = math.sin(self.t * 0.07 + self.phase) * 2

        surf.blit(img, (int(self.x), int(self.y + bob)))





class Popup:

                                                          



    def __init__(self, text, x, y, color=C_YELLOW, life=70):

        self.text = text

        self.x, self.y = float(x), float(y)

        self.color = color

        self.life = life

        self.max_life = life



    def update(self):

        self.y -= 0.45

        self.life -= 1



    def draw(self, surf, font):

        if self.life <= 0:

            return

        if self.life < 16 and (self.life // 3) % 2 == 0:

            return                                                           

        img = font.render(self.text, False, self.color)

        sh = font.render(self.text, False, C_BLACK)

        rect = img.get_rect(center=(int(self.x), int(self.y)))

        surf.blit(sh, (rect.x + 1, rect.y + 1))

        surf.blit(img, rect)





    def stack_above(self, others):

        


           

        for _ in range(2):

            if not any(o is not self and abs(o.y - self.y) < 11

                       for o in others):

                break

            self.y -= 11





class World:

                                    



    def __init__(self, char, art, audio, best=0):

        self.art = art

        self.audio = audio

        self.rider = Rider(char, art["riders"][char["key"]])

        self.speed = SPEED_START

        self.base_speed = SPEED_START

        self.start_speed = SPEED_START                                   

        self.dist = 0.0

        self.tapes = 0

        self.best = best

        self.frames = 0

        self.obstacles = []

        self.pickups = []

        self.popups = []

        self.particles = []

        self.was_on_ground = True

        self.flips = 0

        self.tricks = 0

        self.trick_points = 0

        self.stars = 0

        self.ramp_points = 0

        self.last_life = -LIFE_MIN_GAP

        self.zone_idx = 0

        self.zone_prev = 0

        self.zone_t = 0

        self.zone_step = 0

        self.last_star = -BOOST_MIN_GAP

        self.next_spawn = 120

        self.scroll = {"clouds": 0.0, "city": 0.0, "trees": 0.0, "road": 0.0}

        self.rng = random.Random()

        self.shake = 0

        self.flash = 0

        self.haptic = None                                                    

        self.on_zone = None

        self.on_tape = None

        self.on_frutiger_tape = None

        self.frutiger_pending = False

        self.frutiger_active = False

        self.frutiger_spawned = False

        self.frutiger_bg = None

        self.pre = ()

        self.pre_applied = False

        self.speed_lock = 0                                     

        self.shake_on = True                                      

        self.slow_t = None                                                             

        self.jump_frame = -10 ** 6                                     

        self.obst = 1                                                                           

        self.helis = []

        self.next_heli = self.rng.randint(300, 700)

                                                                         

        self.intro = True

        self.intro_t = 0

        self.intro_v = 0.0

        self.ramp_x = float(PLAYER_X + 17 - 16)

        self.ramp_on = True

        self.rider.y = float(GROUND_Y - sp.LAUNCH_H)

        self.rider.invuln = INTRO_BLINK                                          



                  

    @property

    def score(self):

        return (int(self.dist / 32) + self.tapes * TAPE_BONUS

                + self.flips * BACKFLIP_BONUS + self.trick_points

                + self.ramp_points)



    def jump(self):

                                                                       

        if self.intro:                                           

            self.skip_intro()

            self.rider.on_ground = True

        r = self.rider

        self.jump_frame = self.frames

        for ob in self.obstacles:                                                   

            if ob.kind == "ramp" and not ob.used:

                dx = PLAYER_X + 17 - (ob.x + sp.RAMP_X0)

                if -RAMP_JUMP_AHEAD <= dx < sp.RAMP_W:

                    ob.jumped = True

        was_down, was_super, y0 = r.on_ground, r.ramp_super, r.y

        r.jump(self.audio, self.rng)

        if was_down and not r.on_ground:

            self._puff(PLAYER_X + 17, y0, 6)

        if r.ramp_air and r.ramp_super and not was_super:

                                                                      

            self.ramp_points += RAMP_SUPER_BONUS - RAMP_BONUS

            self._ramp_blast(r.y, small=True)

            self._add_popup(Popup(f"СУПЕРТРАМПЛИН! +{RAMP_SUPER_BONUS}",

                                  PLAYER_X + 24, GROUND_Y - 66, C_STAR))



    def _puff(self, x, y, n=7, color=(236, 232, 244)):

                                                                   

        for _ in range(n):

            self.particles.append(Particle(

                x + self.rng.randint(-5, 5), y - self.rng.randint(0, 3),

                self.rng.uniform(-1.1, 0.5), self.rng.uniform(-1.0, -0.2),

                color, self.rng.randint(14, 24), grav=0.05))



    def _sparkle(self, x, y, color):

                                                                    

        for _ in range(10):

            self.particles.append(Particle(

                x, y, self.rng.uniform(-1.4, 1.4), self.rng.uniform(-2.0, -0.4),

                color, self.rng.randint(16, 28), grav=0.10))



    def _burst(self, x, y):

                                        

        for _ in range(16):

            self.particles.append(Particle(

                x, y, self.rng.uniform(-2.4, 2.4), self.rng.uniform(-2.6, 0.6),

                self.rng.choice(((252, 226, 110), (232, 60, 72), C_WHITE)),

                self.rng.randint(16, 30), grav=0.16, size=2))



    def _ramp_blast(self, y, small=False):

                                                                              

        self._puff(PLAYER_X + 24, y - 2, 7 if small else 14, (196, 244, 252))

        colors = ((252, 226, 110), C_WHITE) if small else (

            (196, 244, 252), (108, 206, 226), C_WHITE)

        for _ in range(10 if small else 18):

            self.particles.append(Particle(

                PLAYER_X + 22 + self.rng.randint(-3, 6),

                y - self.rng.randint(0, 10),

                self.rng.uniform(-3.0, -0.6), self.rng.uniform(-2.8, -0.4),

                self.rng.choice(colors), self.rng.randint(18, 34),

                grav=0.13, size=2))

        self.shake = max(self.shake, 5 if small else 8)



    def _add_popup(self, popup):

        popup.stack_above(self.popups)

        self.popups.append(popup)



    @property

    def slow_mul(self):

                                                                        

        if self.slow_t is None:

            return 1.0

        k = min(1.0, self.slow_t / float(SLOW_FRAMES))

        return SLOW_START + (1.0 - SLOW_START) * k * k



    @property

    def char_speed(self):

        base = max(SPEED_LOCK, self.start_speed) if self.speed_lock > 0 else self.speed

        return base * self.rider.char["speed"] * self.slow_mul



    def _apply_pre(self):

                                                                              

        self.pre_applied = True

        r = self.rider

        for pid, name, _d, _p, secs in PREP_ITEMS:

            if pid not in self.pre:

                continue

            if pid == "star":

                r.boost = r.boost_max = secs * 60

            elif pid == "fly":

                r.fly_t = secs * 60

            elif pid == "hp1":

                r.lives += 1

            else:

                self.speed_lock = secs * 60

            self._add_popup(Popup(name + "!", PLAYER_X + 24, GROUND_Y - 70, C_STAR, 70))



                   

    def _spawn(self):

        speed = self.char_speed

        kinds = ["cone", "hydrant", "pothole", "ramp"]

        if self.score > 30:

            kinds += ["spikeball", "sign"]

        if self.score > 120:

            kinds += ["van", "dumpster"]

        kind = self.rng.choice(kinds)

        img = self.art["obstacles"][kind]

        ob = Obstacle(kind, img, CANVAS_W + 8)

        self.obstacles.append(ob)



                                                                           

                                             

        if kind == "ramp":

            self._spawn_pickup(ramp=ob)

        elif self.rng.random() < 0.55:

            self._spawn_pickup()



                                                                

                                                                     

                                                                    

        gap = ((92 + speed * 20 + self.rng.randint(24, 100))

               * OBST_LEVELS[self.obst][1])

                                                                              

                                               

        ch = self.rider.char

        jump_air = 2.0 * abs(ch["jump"]) / ch["grav"]

        gap = max(gap, jump_air * max(speed, self.speed * ch["speed"]) + 42)

        if kind == "ramp":

                                                                    

                                                                       

                                            

            g = ch["grav"] * RAMP_GRAV

            air = (math.sqrt(2.0 * g * (RAMP_APEX_JUMP - sp.RAMP_H))

                   + math.sqrt(2.0 * g * RAMP_APEX_JUMP)) / g

            fly = max(speed, self.speed * ch["speed"])

            gap = max(gap, sp.RAMP_X0 + sp.RAMP_W + air * fly + 90)

        self.next_spawn = int(gap / max(speed, 0.6))



    def _spawn_pickup(self, ramp=None):

                                                                                    

        star_ready = self.frames - self.last_star > BOOST_MIN_GAP

        life_ready = (self.frames - self.last_life > LIFE_MIN_GAP

                      and self.rider.lives < MAX_LIVES)

        idx = 0

        if (self.frutiger_pending and not self.frutiger_spawned

                and self.score >= FRUTIGER_UNLOCK_SCORE):

            self.frutiger_spawned = True

            if "tape_frutiger" not in self.art:

                self.art["tape_frutiger"] = sp.make_tape_pickup(FRUTIGER_TAPE_LABEL)

            img, kind = self.art["tape_frutiger"], "tape_frutiger"

        elif star_ready and self.rng.random() < BOOST_CHANCE:

            self.last_star = self.frames

            img, kind = self.art["star_pickup"], "star"

        elif life_ready and self.rng.random() < LIFE_CHANCE:

            self.last_life = self.frames

            img, kind = self.art["life"], "life"

        else:

            idx = self.rng.randrange(len(TAPES))

            img, kind = self.art["tapes"][idx], "tape"

        w, h = img.get_size()

        if ramp is None:

            px = CANVAS_W + 8 + self.rng.randint(-2, 10)

            ty = GROUND_Y - self.rng.choice((40, 48, 56))

        else:                                                                      

            dx = sp.RAMP_W * 0.6

            px = ramp.x + sp.RAMP_X0 + dx - w / 2.0

            ty = GROUND_Y - sp.ramp_height(dx) - h - 3

        self.pickups.append(Pickup(img, px, ty, kind, idx, ramp=ramp))



                           

    def skip_intro(self):

        


                                                         

        if not self.intro:

            return

        r = self.rider

        self.intro = False

        self.speed = self.start_speed

        self.next_spawn = 80

        r.tilt = 0.0

        r.invuln = 0

        if r.y < GROUND_Y - 0.5:

            r.on_ground = False

            r.vy = 0.0

        else:

            r.y = float(GROUND_Y)

            r.on_ground = True

        self.was_on_ground = r.on_ground



    def _update_intro(self):

                                                                            

        r = self.rider

        t = self.intro_t

        self.intro_t += 1

        feet = PLAYER_X + 17

        if t == 2:                                                              

            self.flash = 5

            self.audio.play("flip")

            for _ in range(4):

                self._sparkle(feet + self.rng.randint(-10, 10),

                              r.y - self.rng.randint(8, 34),

                              self.rng.choice((C_STAR, C_CYAN, C_WHITE)))

        if t == INTRO_WAIT:

            self.audio.play("ramp")

            self._add_popup(Popup("ПОЕХАЛИ!", PLAYER_X + 14,

                                  GROUND_Y - sp.LAUNCH_H - 30, C_STAR, 60))

        if t >= INTRO_WAIT:

            self.intro_v = min(self.char_speed, self.intro_v + INTRO_ACCEL)

        v = self.intro_v

        self.ramp_x -= v



        self.scroll["clouds"] = (self.scroll["clouds"] + v * 0.10) % CANVAS_W

        self.scroll["city"] = (self.scroll["city"] + v * 0.28) % CANVAS_W

        self.scroll["trees"] = (self.scroll["trees"] + v * 0.62) % CANVAS_W

        self.scroll["road"] = (self.scroll["road"] + v) % 96



        dx = feet - self.ramp_x

        h = sp.launch_height(dx)

        ahead = sp.launch_height(dx + 6)

        r.y = GROUND_Y - h

        r.tilt = -min(30.0, 0.7 * math.degrees(math.atan2(h - ahead, 6.0)))

        r.roll(v)

        if v > 0.4 and h > 0 and t % 2 == 0:                                   

            self.particles.append(Particle(

                feet - 9, r.y - 1, self.rng.uniform(-1.0, -0.3),

                self.rng.uniform(-1.0, -0.2), (196, 244, 252),

                self.rng.randint(8, 14), grav=0.06))



        for pop in self.popups:

            pop.update()

        self.popups = [p for p in self.popups if p.life > 0]

        self.particles = [p for p in self.particles if p.update(v * 0.6)]

        if self.shake > 0:

            self.shake -= 1

        if self.flash > 0:

            self.flash -= 1



        if dx > sp.LAUNCH_W + 6:                                            

            r.tilt = 0.0

            r.y = float(GROUND_Y)

            r.vy = 0.0

            r.on_ground = True

            self.intro = False

            self.speed = self.start_speed

            self.next_spawn = 80

            self.was_on_ground = True

            self._puff(feet, GROUND_Y, 10)

            self.shake = 5



    def update(self):

        self.frames += 1

        if self.intro:

            self._update_intro()

            return

        if not self.pre_applied:

            self._apply_pre()

        if self.zone_t > 0:

            self.zone_t -= 1

        step = self.score // ZONE_SCORE

        if step != self.zone_step and not self.rider.dead:

            self.zone_step = step

            self._next_zone()

        if not self.rider.dead:

            if self.speed_lock > 0:

                self.speed_lock -= 1                                        

            else:

                self.speed = min(SPEED_MAX, self.speed + SPEED_GAIN)

            self.dist += self.char_speed

        else:

            self.speed = max(0.0, self.speed - 0.12)



        if self.slow_t is not None:

            self.slow_t += 1

            if self.slow_t >= SLOW_FRAMES:

                self.slow_t = None

        speed = self.char_speed

        self.rider.update(self.speed * self.slow_mul)



        self.next_heli -= 1                                                  

        if self.next_heli <= 0:

            if len(self.helis) < 2 and not self.rider.dead:

                self.helis.append(Heli(self.art["helis"], self.rng))

            self.next_heli = self.rng.randint(520, 1500)

        self.helis = [h for h in self.helis if h.update(speed)]



        self.scroll["clouds"] = (self.scroll["clouds"] + speed * 0.10) % CANVAS_W

        self.scroll["city"] = (self.scroll["city"] + speed * 0.28) % CANVAS_W

        self.scroll["trees"] = (self.scroll["trees"] + speed * 0.62) % CANVAS_W

        self.scroll["road"] = (self.scroll["road"] + speed) % 96



        if not self.rider.dead:

            self.next_spawn -= 1

            if self.next_spawn <= 0:

                self._spawn()



        for ob in self.obstacles:

            ob.x -= speed

        for pk in self.pickups:

            pk.x -= speed

        if self.ramp_on:                                                      

            self.ramp_x -= speed

            if self.ramp_x < -sp.LAUNCH_W - 8:

                self.ramp_on = False

                                                                                        

        self.obstacles = [o for o in self.obstacles if o.x + o.w > -4]

        self.pickups = [p for p in self.pickups

                        if p.x + p.image.get_width() > -4 and not p.taken]

        if not self.rider.dead:

            self._ride_ramps()



        feet = PLAYER_X + 17

        if self.rider.on_ground and not self.was_on_ground:

            self._puff(feet, self.rider.y, 9)                                      

        self.was_on_ground = self.rider.on_ground



        if self.rider.landed_trick:                                         

            name = self.rider.landed_trick

            self.rider.landed_trick = None

            self.tricks += 1

            self.trick_points += TRICKS[name]["bonus"]

            self.audio.play("flip")

            self._sparkle(PLAYER_X + 17, self.rider.y - 24, C_STAR)

            self._add_popup(

                Popup(f"{TRICKS[name]['title']}! +{TRICKS[name]['bonus']}",

                      PLAYER_X + 22, GROUND_Y - 60, C_STAR))



        if self.rider.landed_flip:                                      

            self.rider.landed_flip = False

            self.flips += 1

            self.audio.play("flip")

            self._add_popup(

                Popup(f"САЛЬТО! +{BACKFLIP_BONUS}", PLAYER_X + 18,

                      GROUND_Y - 56))



        for pop in self.popups:

            pop.update()

        self.popups = [p for p in self.popups if p.life > 0]

        self.particles = [p for p in self.particles

                          if p.update(self.speed * 0.6)]



        if not self.rider.dead:

            self._collide()



        if self.shake > 0:

            self.shake -= 1

        if self.flash > 0:

            self.flash -= 1



    def _ride_ramps(self):

        



                           

        r = self.rider

        if r.fly_t > 0:

            return

        feet = PLAYER_X + 17

        for ob in self.obstacles:

            if ob.kind != "ramp" or ob.used:

                continue

            dx = feet - (ob.x + sp.RAMP_X0)

            if dx < 0:

                continue

            if dx >= sp.RAMP_W:                                                  

                ob.used = True

                if GROUND_Y - r.y <= sp.RAMP_H + RAMP_REACH:

                    jumped = (not r.on_ground or ob.jumped or

                              self.frames - self.jump_frame <= RAMP_JUMP_GRACE)

                    self._ramp_launch(ob, jumped)

                continue

            deck = sp.ramp_height(dx)

            surf_y = GROUND_Y - deck

            if r.y >= surf_y:                                            

                r.y = surf_y

                if r.vy >= 0:

                    r.vy = 0.0

                    r.on_ground = True

                    r.jumps_left = 0

                    slope = math.degrees(math.atan2(

                        sp.ramp_height(dx + 6) - deck, 6.0))

                    r.tilt = min(32.0, 0.8 * slope)                        



    def _ramp_launch(self, ob, super_jump):

        r = self.rider

        r.launch(self.audio, super_jump)

        for pk in self.pickups:                                                       

            if pk.ramp is ob and not pk.taken:

                self._take(pk)

        bonus = RAMP_SUPER_BONUS if super_jump else RAMP_BONUS

        self.ramp_points += bonus

        self._ramp_blast(r.y)

        if self.haptic:

            self.haptic(45 if super_jump else 30)

        if super_jump:

            self.flash = max(self.flash, 3)

            self._add_popup(Popup(f"СУПЕРТРАМПЛИН! +{bonus}", PLAYER_X + 24,

                                  GROUND_Y - 66, C_STAR))

        else:

            self._add_popup(Popup(f"ТРАМПЛИН! +{bonus}", PLAYER_X + 20,

                                  GROUND_Y - 60, C_CYAN))



    def _collide(self):

        pr = self.rider.rect()

        for ob in self.obstacles:

            if ob.kind == "ramp" or self.rider.fly_t > 0:                                                  

                continue

            if not pr.colliderect(ob.rect()):

                continue

            if self.rider.hit(self.audio):

                self.slow_t = 0                                               

                if self.haptic:

                    self.haptic(220 if self.rider.dead else 70)

                self.shake = 14

                self.flash = 6

                self._burst(PLAYER_X + 17, self.rider.y - 20)

                if self.rider.dead:

                    self.audio.play("over")

            break

        for pk in self.pickups:

            if not pk.taken and pr.colliderect(pk.rect()):

                self._take(pk)



    def _take(self, pk):

                                                            

        pk.taken = True

        cx, cy = pk.center()

        if pk.kind == "life":

            self.rider.lives = min(MAX_LIVES, self.rider.lives + 1)

            self.audio.play("life")

            if self.haptic:

                self.haptic(25)

            self._sparkle(cx, cy, (250, 120, 140))

            self._add_popup(Popup("+1 ЖИЗНЬ", PLAYER_X + 26,

                                  GROUND_Y - 60, (250, 120, 140), 85))

        elif pk.kind == "star":

            self.rider.boost = self.rider.boost_max = BOOST_FRAMES

            self.stars += 1

            self.audio.play("star")

            self._sparkle(cx, cy, C_STAR)

            self._add_popup(

                Popup(f"НЕУЯЗВИМОСТЬ {BOOST_SECONDS} СЕК",

                      PLAYER_X + 26, GROUND_Y - 62, C_STAR, 90))

        elif pk.kind == "tape_frutiger":

            self.tapes += 1

            if self.on_tape:

                self.on_tape()

            self.audio.play("pickup")

            self._sparkle(cx, cy, FRUTIGER_TAPE_LABEL)

            self._add_popup(

                Popup(f"FRUTIGER AERO  +{TAPE_BONUS}",

                      PLAYER_X + 26, GROUND_Y - 58,

                      FRUTIGER_TAPE_LABEL, 75))

            if self.on_frutiger_tape:

                self.on_frutiger_tape()

        else:

            self.tapes += 1

            if self.on_tape:

                self.on_tape()

            self.audio.play("pickup")

            self.audio.play_tape(pk.tape)

            self._sparkle(cx, cy, TAPES[pk.tape]["label"])

            self._add_popup(

                Popup(f"{TAPES[pk.tape]['title']}  +{TAPE_BONUS}",

                      PLAYER_X + 26, GROUND_Y - 58,

                      TAPES[pk.tape]["label"], 75))



                  

    @property

    def zone(self):

        if self.frutiger_active and self.frutiger_bg:

            return self.frutiger_bg

        return self.art["zones"][self.zone_idx]



    def _next_zone(self):



        self.zone_prev = self.zone_idx

        others = [i for i in range(len(ZONES)) if i != self.zone_idx]

        self.zone_idx = self.rng.choice(others)

        self.audio.play("zone")

        if self.on_zone:

            self.on_zone()

        if self.frutiger_active and self.frutiger_bg:

            self.zone_t = 0

            return

        self.zone_t = ZONE_FX_FRAMES

        self._add_popup(Popup(ZONES[self.zone_idx]["name"],

                              CANVAS_W // 2 - 16, GROUND_Y - 84, C_WHITE, 80))



                       

    def _draw_scene(self, surf, zone, ox):

        surf.blit(zone["sky"], (0, 0))

        self._layer(surf, zone["clouds"], self.scroll["clouds"], ox)

        self._layer(surf, zone["city"], self.scroll["city"], ox)

        self._layer(surf, zone["trees"], self.scroll["trees"], ox)

        self._draw_road(surf, ox, zone["pal"])



    def draw(self, surf):

        ox = 0

        if self.shake > 0 and self.shake_on:

            ox = (-2, 2)[self.shake % 2]



        if self.zone_t > 0:

                                                               

            self._draw_scene(surf, self.art["zones"][self.zone_prev], ox)

            done = 1.0 - self.zone_t / ZONE_FX_FRAMES

            wipe = int(CANVAS_W * done)

            keep = surf.get_clip()

            surf.set_clip(pygame.Rect(0, 0, wipe, CANVAS_H))

            self._draw_scene(surf, self.zone, ox)

            surf.set_clip(keep)

            for k, col in enumerate(((252, 236, 120), (250, 160, 40))):

                surf.fill(col, pygame.Rect(wipe - 2 + k * 2, 0, 2, CANVAS_H))

        else:

            self._draw_scene(surf, self.zone, ox)



        for h in self.helis:

            h.draw(surf)

        if self.ramp_on:

            surf.blit(self.art["launch_ramp"],

                      (int(self.ramp_x) - 2 + ox,

                       GROUND_Y + 1 - (sp.LAUNCH_H + 3 + sp.LAUNCH_PAD)))

        for ob in self.obstacles:

            ob.draw(surf)

        for pk in self.pickups:

            pk.draw(surf, self.frames)

        self.rider.draw(surf)

        for pt in self.particles:

            pt.draw(surf)

        for pop in self.popups:

            pop.draw(surf, self.art["font"])



        if self.flash > 0:

            veil = pygame.Surface((CANVAS_W, CANVAS_H), pygame.SRCALPHA)

            veil.fill((255, 255, 255, 80))

            surf.blit(veil, (0, 0))

        if self.frames < INTRO_DARK:                                            

                                                                           

            k = 1.0 - self.frames / INTRO_DARK

            veil = pygame.Surface((CANVAS_W, CANVAS_H), pygame.SRCALPHA)

            veil.fill((6, 4, 16, int(240 * k ** 1.4)))

            surf.blit(veil, (0, 0))



    def _layer(self, surf, img, offset, ox):

                                                         

        x = -int(offset) + ox

        surf.blit(img, (x, 0))

        surf.blit(img, (x + CANVAS_W, 0))



    def _draw_road(self, surf, ox, pal):

                                                                     

        surf.fill(pal["road_hi"], pygame.Rect(0, GROUND_Y - 3, CANVAS_W, 3))

        surf.fill(pal["road"],

                  pygame.Rect(0, GROUND_Y, CANVAS_W, CANVAS_H - GROUND_Y))

        surf.fill(pal["road_dark"], pygame.Rect(0, GROUND_Y + 14, CANVAS_W,

                                                CANVAS_H - GROUND_Y - 14))

        off = int(self.scroll["road"])

        for x in range(-32, CANVAS_W + 32, 32):

            surf.fill(C_ROAD_LINE, pygame.Rect(x - off + ox, GROUND_Y + 6, 14, 2))

        for x in range(-24, CANVAS_W + 24, 24):

            surf.fill(pal["road"], pygame.Rect(x - off + ox, GROUND_Y + 18, 10, 2))

