"""Музыка игры: треки собираются из аккордов, стилей партий и мелодий.

Трек описывается секциями по 4-8 тактов. В каждой секции:
  chords — ступень аккорда на каждый такт (1..7, аккорд строится по ладу);
  lead   — мелодия по тактам в формате «ступень:длительность», например
           «5:4 1':4 3':4 2':2 1':2» (длительность в шестнадцатых, сумма 16;
           ' — октава вверх, , — вниз, «-» — пауза; «pad» — длинные ноты
           по аккорду, None — мелодии нет);
  bass / arp / drum — названия стилей из BASS, ARP, DRUM;
  fill   — последний такт с барабанной сбивкой.

build() превращает это в словарь партий для chiptune.render_song().
Здесь нет ни numpy, ни pygame: модуль только сочиняет строки нот.
"""

MODES = {
    "minor":      (0, 2, 3, 5, 7, 8, 10),
    "major":      (0, 2, 4, 5, 7, 9, 11),
    "dorian":     (0, 2, 3, 5, 7, 9, 10),
    "phrygian":   (0, 1, 3, 5, 7, 8, 10),
    "lydian":     (0, 2, 4, 6, 7, 9, 11),
    "mixolydian": (0, 2, 4, 5, 7, 9, 10),
    "harmonic":   (0, 2, 3, 5, 7, 8, 11),
}
_NAMES = ("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")

# --- стили партий: 16 шагов на такт; r/o/f/t/b — ноты аккорда -------------
BASS = {
    "pulse":  "r . r . r . r . r . r . r . r .",
    "bounce": "r . o . r . o . r . o . r . o .",
    "octave": "r . . . o . r . . . o . r . f .",
    "sync":   "r . . r . . r . . r . r . . r .",
    "walk":   "r . . . t . . . f . . . t . . .",
    "half":   "r . . . . . . . f . . . . . . .",
    "gallop": "r . r r . r r . r . r r . r r .",
}
ARP = {      # r t f — основа, терция, квинта; o T F — то же октавой выше
    "up":     "r t f t r t f t r t f t r t f t",
    "broken": "r f t f r f t f r f t f r f t f",
    "wide":   "r f o f r f o f r f o f r f o f",
    "stab":   "- - T - - - T - - - T - - - T -",
    "pulse":  "r - r - r - r - r - r - r - r -",
    "pad":    "t . . . . . . . f . . . . . . .",
}
DRUM = {
    "four":  "KH - H - SH - H - KH - H K SH - H -",
    "rock":  "KH - H - SH - H - KH - KH - SH - H -",
    "half":  "KH - H - H - H - SH - H - H - H -",
    "dnb":   "KH - H - SH - H K - K H - SH - H -",
    "disco": "KH - H - SH - H - KH - H - SH - H H",
    "shuf":  "KH H H H SH H H H KH H KH H SH H H H",
    "march": "KH - S - KH - S - KH - S - KH S S S",
    "euro":  "K - H - KS - H - K - H - KS - H -",
}
FILL = "KH - S - S - S S KS S KS S S S S S"
REST = "- - - - - - - - - - - - - - - -"


def _check16(pattern, what):
    n = len(pattern.split())
    if n != 16:
        raise ValueError("%s: %d шагов вместо 16: %r" % (what, n, pattern))


for _k, _v in BASS.items():
    _check16(_v, "BASS " + _k)
for _k, _v in ARP.items():
    _check16(_v, "ARP " + _k)
for _k, _v in DRUM.items():
    _check16(_v, "DRUM " + _k)
_check16(FILL, "FILL")


def _name(m):
    return "%s%d" % (_NAMES[m % 12], m // 12 - 1)


def _ext(scale, i):
    return scale[i % 7] + 12 * (i // 7)


def _chord(scale, degree):
    i = degree - 1
    return _ext(scale, i), _ext(scale, i + 2), _ext(scale, i + 4)


def _lead_bar(text, scale, root, shift, where):
    """'5:4 1':4 -:2 3:2 ...' -> ноты-токены для трекера (ровно 16 шагов)."""
    out, total = [], 0
    for tok in text.split():
        deg, _, dur = tok.partition(":")
        dur = int(dur or 1)
        total += dur
        if deg == "-":
            out.extend(["-"] * dur)
            continue
        base = deg.rstrip("',")
        octave = deg.count("'") - deg.count(",")
        d = int(base)
        midi = root + _ext(scale, d - 1) + 12 * octave + shift
        out.append(_name(midi))
        out.extend(["."] * (dur - 1))
    if total != 16:
        raise ValueError("%s: такт даёт %d шагов вместо 16: %r"
                         % (where, total, text))
    return out


def _pad_bar(scale, root, degree, shift):
    """Длинные ноты по аккорду: квинта и терция, по половине такта."""
    i = degree - 1
    notes = []
    for idx in (i + 4, i + 2):
        midi = root + _ext(scale, idx) + shift
        notes.append(_name(midi))
    return [notes[0]] + ["."] * 7 + [notes[1]] + ["."] * 7


def build(bpm, mode, lead_root, arp_root, bass_root, sections, lead_duty=0.5,
          lead_vol=0.19, harm_duty=0.25, harm_vol=0.11, bass_vol=0.27,
          drum_vol=0.23):
    scale = MODES[mode]
    lead, harm, bass, drum = [], [], [], []
    all_chords = []
    for si, sec in enumerate(sections):
        all_chords.extend(sec["chords"])
        chords = sec["chords"]
        bars = sec.get("lead")
        for bi, deg in enumerate(chords):
            where = "секция %d, такт %d" % (si + 1, bi + 1)
            r0, t0, f0 = _chord(scale, deg)
            shift = sec.get("shift", 0)
            # мелодия
            if bars is None:
                lead.extend(["-"] * 16)
            elif bars == "pad":
                lead.extend(_pad_bar(scale, lead_root, deg, shift))
            else:
                lead.extend(_lead_bar(bars[bi % len(bars)], scale, lead_root,
                                      shift, where))
            # бас
            bt = {"r": _name(bass_root + r0), "o": _name(bass_root + r0 + 12),
                  "f": _name(bass_root + f0), "t": _name(bass_root + t0),
                  "b": _name(bass_root + f0 - 12)}
            bass.extend(bt.get(tok, tok) for tok in
                        BASS[sec.get("bass", "pulse")].split())
            # арпеджио / подложка
            at = {"r": _name(arp_root + r0), "t": _name(arp_root + t0),
                  "f": _name(arp_root + f0), "o": _name(arp_root + r0 + 12),
                  "T": _name(arp_root + t0 + 12),
                  "F": _name(arp_root + f0 + 12)}
            style = sec.get("arp")
            if style:
                harm.extend(at.get(tok, tok) for tok in ARP[style].split())
            else:
                harm.extend(["-"] * 16)
            # барабаны: в последнем такте секции — сбивка
            dstyle = sec.get("drum")
            if not dstyle:
                drum.extend(REST.split())
            elif sec.get("fill") and bi == len(chords) - 1:
                drum.extend(FILL.split())
            else:
                drum.extend(DRUM[dstyle].split())
    return dict(bpm=bpm, lead=" ".join(lead), harm=" ".join(harm),
                bass=" ".join(bass), drum=" ".join(drum), lead_duty=lead_duty,
                lead_vol=lead_vol, harm_duty=harm_duty, harm_vol=harm_vol,
                bass_vol=bass_vol, drum_vol=drum_vol,
                meta=dict(mode=mode, chords=all_chords, lead_root=lead_root))


def _game(bpm, mode, lead_root, arp_root, bass_root, prog_a, prog_b, A, A_alt,
          B, B_alt, bass=("pulse", "pulse"), arp=("up", "broken", "wide"),
          drum=("four", "four", "four"), **params):
    """Игровой трек на 24 такта: куплет, повтор, припев, спокойный бридж,
    куплет «на полную» и припев с финальной сбивкой."""
    prog_c = [prog_b[2], prog_b[3], prog_b[0], prog_b[1]]
    sections = [
        dict(chords=prog_a, lead=A, bass=bass[0], arp=arp[0], drum=drum[0]),
        dict(chords=prog_a, lead=A[:3] + [A_alt], bass=bass[0], arp=arp[0],
             drum=drum[0], fill=True),
        dict(chords=prog_b, lead=B, bass=bass[1], arp=arp[1], drum=drum[1]),
        dict(chords=prog_c, lead="pad", bass="half", arp="pad", drum=None,
             shift=-12),
        dict(chords=prog_a, lead=A[:3] + [A_alt], bass=bass[1], arp=arp[2],
             drum=drum[2]),
        dict(chords=prog_b, lead=B[:3] + [B_alt], bass=bass[1], arp=arp[2],
             drum=drum[2], fill=True),
    ]
    return build(bpm, mode, lead_root, arp_root, bass_root, sections, **params)


# ======================================================================
# Восемь игровых треков
# ======================================================================

# 1. НЕОН-ДРАЙВ — ля минор, синтвейв, 150 BPM
G1 = _game(
    150, "minor", 69, 57, 45, [1, 6, 3, 7], [6, 7, 1, 5],
    A=["5:4 1':4 3':4 2':2 1':2", "6:4 1':4 6:4 5:2 3:2",
       "3:4 5:4 7:4 1':2 7:2", "2':4 7:4 4:4 7:2 2':2"],
    A_alt="2':2 4':2 2':2 7:2 5:2 7:2 2':2 4':2",
    B=["1':2 1':2 6:2 1':2 3':4 1':2 6:2", "2':2 2':2 7:2 2':2 4':4 2':2 7:2",
       "3':2 3':2 1':2 3':2 5':4 3':2 1':2", "7:2 5:2 2:2 5:2 7:6 5:2"],
    B_alt="7:2 5:2 2:2 5:2 7:2 2':2 7:2 5:2",
    bass=("pulse", "octave"), arp=("up", "broken", "wide"),
    drum=("four", "four", "euro"), lead_duty=0.5)

# 2. СОЛНЕЧНЫЙ ДЕНЬ — соль мажор, бодрый и светлый, 138 BPM
G2 = _game(
    138, "major", 67, 55, 43, [1, 5, 6, 4], [4, 5, 3, 6],
    A=["1:2 3:2 5:2 3:2 1':4 5:2 3:2", "5:2 7:2 2':2 7:2 5':4 2':2 7:2",
       "6:2 1':2 3':2 1':2 6:4 3':2 1':2", "4:2 6:2 1':2 6:2 4':4 1':2 6:2"],
    A_alt="4:2 6:2 1':2 3':2 5':4 3':2 1':2",
    B=["6:6 4:2 6:4 1':4", "7:6 5:2 7:4 2':4", "5:6 3:2 5:4 7:4",
       "6:4 3':4 1':4 6:4"],
    B_alt="6:2 1':2 3':2 1':2 6:4 5:2 6:2",
    bass=("bounce", "walk"), arp=("broken", "up", "wide"),
    drum=("rock", "rock", "four"), lead_duty=0.25, harm_duty=0.5)

# 3. ГРОЗА — ре минор, злой и быстрый, 168 BPM
G3 = _game(
    168, "minor", 74, 62, 38, [1, 6, 7, 1], [4, 5, 6, 5],
    A=["1:1 3:1 5:1 3:1 1:1 3:1 5:1 3:1 1':4 5:2 3:2",
       "6:1 1':1 3':1 1':1 6:1 1':1 3':1 1':1 6:4 3:2 1:2",
       "7,:1 2:1 4:1 2:1 7,:1 2:1 4:1 2:1 7:4 4:2 2:2", "1:6 5:2 3:4 1:4"],
    A_alt="1:2 3:2 5:2 1':2 5:2 3:2 1:4",
    B=["4:2 6:2 1':2 6:2 4:2 6:2 1':4", "5:2 7:2 2':2 7:2 5:2 7:2 2':4",
       "6:2 1':2 3':2 1':2 6:2 1':2 3':4", "5:2 7:2 2':2 7:2 5:8"],
    B_alt="5:2 7:2 2':2 7:2 5:2 7:2 5:2 3:2",
    bass=("pulse", "sync"), arp=("up", "pulse", "broken"),
    drum=("dnb", "dnb", "march"), lead_duty=0.125, lead_vol=0.17,
    bass_vol=0.30, drum_vol=0.25)

# 4. ПУСТЫННЫЙ ЗАКАТ — ми гармонический минор, восточный колорит, 128 BPM
G4 = _game(
    128, "harmonic", 64, 52, 40, [1, 4, 5, 1], [6, 5, 1, 5],
    A=["5':3 4':1 3':2 2':2 1':3 7:1 1':2 3':2",
       "4':2 3':1 2':1 1':4 6:2 7:2 1':4",
       "5':4 7':2 5':2 2':4 7:4", "1':6 7:2 1':4 5:4"],
    A_alt="1':2 3':2 5':2 3':2 1':2 7:2 5:2 1':2",
    B=["6:2 1':2 3':2 1':2 6:4 3':2 1':2", "5:2 7:2 2':2 7:2 5:4 2':2 7:2",
       "1':6 3':2 5':4 3':4", "5':4 2':2 5':2 7:4 5:4"],
    B_alt="5':2 7':2 5':2 2':2 7:2 2':2 5':4",
    bass=("walk", "sync"), arp=("broken", "up", "wide"),
    drum=("half", "rock", "rock"), lead_duty=0.25, harm_duty=0.5)

# 5. НОЧНОЙ ГОРОД — ре дорийский, ровный грув, 124 BPM
G5 = _game(
    124, "dorian", 62, 50, 38, [1, 4, 1, 7], [4, 7, 1, 5],
    A=["5':3 3':3 1':2 3':3 5':3 3':2", "4':3 6':3 1'':2 6':3 4':3 6':2",
       "5':3 3':3 1':2 3':3 5':3 7':2", "7:3 2':3 4':2 2':3 7:3 2':2"],
    A_alt="7:3 2':3 4':2 7':3 4':3 2':2",
    B=["6:2 1':2 4':2 1':2 6:2 1':2 4':4", "7:2 2':2 4':2 2':2 7:2 2':2 4':4",
       "1':2 3':2 5':2 3':2 1':2 3':2 5':4", "5:2 7:2 2':2 7:2 5:8"],
    B_alt="5:2 7:2 2':2 4':2 2':2 7:2 5:4",
    bass=("bounce", "sync"), arp=("pulse", "up", "broken"),
    drum=("disco", "disco", "shuf"), lead_duty=0.25)

# 6. РАССВЕТ — фа лидийский, светлый подъём, 144 BPM
G6 = _game(
    144, "lydian", 65, 53, 41, [1, 2, 5, 1], [6, 3, 2, 5],
    A=["1':3 3':3 5':2 3':3 1':3 5:2", "2':3 4':3 6':2 4':3 2':3 6:2",
       "5:3 7:3 2':2 7:3 5:3 2':2", "1':6 5:2 3':4 1':4"],
    A_alt="1':2 3':2 5':2 3':2 1':2 5:2 3:2 1':2",
    B=["6:2 1':2 3':2 1':2 6:2 1':2 3':4", "3:2 5:2 7:2 5:2 3:2 5:2 7:4",
       "2':2 4':2 6':2 4':2 2':2 4':2 6':4", "5:4 7:2 5:2 2':4 7:4"],
    B_alt="5:2 7:2 2':2 5':2 2':2 7:2 5:4",
    bass=("bounce", "octave"), arp=("up", "wide", "broken"),
    drum=("four", "four", "euro"), lead_duty=0.25, harm_duty=0.5)

# 7. ЗАВОД — до фригийский, тяжёлый индастриал, 160 BPM
G7 = _game(
    160, "phrygian", 72, 60, 36, [1, 2, 1, 7], [4, 1, 2, 1],
    A=["1:2 1:1 2:1 1:2 3:2 1:2 5:2 3:2 1:2",
       "2:2 2:1 3:1 2:2 4:2 2:2 6:2 4:2 2:2",
       "1:2 1:1 2:1 1:2 3:2 1:2 5:2 3:2 5:2",
       "7,:2 7,:1 1:1 7,:2 2:2 7,:2 4:2 2:2 7,:2"],
    A_alt="7,:2 2:2 4:2 6:2 4:2 2:2 7,:4",
    B=["4:2 4:1 5:1 4:2 6:2 4:2 1':2 6:2 4:2", "1:2 3:2 5:2 3:2 1:2 3:2 5:4",
       "2:2 4:2 6:2 4:2 2:2 4:2 6:4", "1:6 3:2 5:4 1':4"],
    B_alt="1:2 3:2 5:2 1':2 5:2 3:2 1:4",
    bass=("gallop", "pulse"), arp=("stab", "pulse", "broken"),
    drum=("march", "dnb", "march"), lead_duty=0.125, lead_vol=0.17,
    bass_vol=0.31, drum_vol=0.26)

# 8. ТУРБО — си-бемоль миксолидийский, евробит, 176 BPM
G8 = _game(
    176, "mixolydian", 70, 58, 46, [1, 7, 4, 1], [6, 4, 1, 5],
    A=["1:2 3:2 5:2 1':2 5:2 3:2 1:2 3:2", "7,:2 2:2 4:2 7:2 4:2 2:2 7,:2 2:2",
       "4:2 6:2 1':2 4':2 1':2 6:2 4:2 6:2", "1':4 5:2 3:2 1':4 3:2 5:2"],
    A_alt="1:2 3:2 5:2 1':2 3':2 1':2 5:2 3:2",
    B=["6:2 1':2 3':2 1':2 6:2 1':2 3':4", "4:2 6:2 1':2 6:2 4:2 6:2 1':4",
       "1:2 3:2 5:2 3:2 1:2 3:2 5:4", "5:2 7:2 2':2 7:2 5:8"],
    B_alt="5:2 7:2 2':2 4':2 2':2 7:2 5:4",
    bass=("bounce", "octave"), arp=("wide", "up", "broken"),
    drum=("euro", "euro", "four"), lead_duty=0.5, drum_vol=0.24)

GAME_TRACKS = (
    ("g1", "НЕОН-ДРАЙВ", G1), ("g2", "СОЛНЕЧНЫЙ ДЕНЬ", G2),
    ("g3", "ГРОЗА", G3), ("g4", "ПУСТЫННЫЙ ЗАКАТ", G4),
    ("g5", "НОЧНОЙ ГОРОД", G5), ("g6", "РАССВЕТ", G6),
    ("g7", "ЗАВОД", G7), ("g8", "ТУРБО", G8),
)

# ======================================================================
# Выбор персонажа: длинная песня на 32 такта, до мажор, 110 BPM
# ======================================================================
_SA = ["3:4 5:2 3:2 1':4 5:4", "7:4 5:2 7:2 2':4 7:4",
       "6:4 1':2 6:2 3':4 1':4", "4:4 6:2 4:2 1':4 6:4"]
_SA_ALT = "4:2 6:2 1':2 6:2 4:2 5:2 7:2 2':2"
_SB = ["1':3 7:1 6:2 5:2 6:4 1':4", "6:3 5:1 4:2 3:2 4:4 6:4",
       "5:3 4:1 3:2 2:2 3:4 5:4", "7:4 2':4 5:4 7:4"]
_SB_ALT = "7:2 2':2 7:2 5:2 7:2 2':2 5:4"
_SC = ["6:8 4:8", "7:8 5:8", "3:8 5:8", "6:8 1':4 3':4"]
_SD = ["4:2 6:2 1':2 6:2 4:2 6:2 1':4", "6:2 1':2 3':2 1':2 6:2 1':2 3':4",
       "7:2 2':2 5:2 7:2 2':2 7:2 5:4", "7:2 2':2 4':2 2':2 7:2 5:2 7:4"]

SELECT = build(
    110, "major", 60, 48, 36,
    [
        dict(chords=[1, 5, 6, 4], lead=None, bass="walk", arp="up", drum=None),
        dict(chords=[1, 5, 6, 4], lead=_SA, bass="octave", arp="up",
             drum="half"),
        dict(chords=[1, 5, 6, 4], lead=_SA[:3] + [_SA_ALT], bass="bounce",
             arp="broken", drum="rock", fill=True),
        dict(chords=[6, 4, 1, 5], lead=_SB, bass="bounce", arp="up",
             drum="rock"),
        dict(chords=[4, 5, 3, 6], lead=_SC, bass="half", arp="stab", drum=None),
        dict(chords=[1, 5, 6, 4], lead=_SA, bass="bounce", arp="wide",
             drum="four"),
        dict(chords=[6, 4, 1, 5], lead=_SB[:3] + [_SB_ALT], bass="octave",
             arp="broken", drum="four", fill=True),
        dict(chords=[4, 6, 5, 5], lead=_SD, bass="bounce", arp="wide",
             drum="four", fill=True),
    ],
    lead_duty=0.25, lead_vol=0.18, bass_vol=0.26, drum_vol=0.21)

# ======================================================================
# Главное меню: ми минор, 118 BPM, 16 тактов
# ======================================================================
_MA = ["1:3 3:3 5:3 4:2 3:5", "1:3 3:3 4:2 5:4 7:2 5:2",
       "6,:3 1:3 3:3 7,:2 1:5", "6,:3 1:3 3:2 4:4 3:2 1:2",
       "5,:3 7,:3 3:3 2:2 7,:5", "5,:3 7,:3 3:2 4:4 5:2 3:2",
       "4,:3 7,:3 2:3 1:2 7,:5", "4,:2 7,:2 2:2 4:2 -:2 5:2 4:2 2:2"]
_MB = ["6,:2 1:2 3:2 1:2 6,:2 1:2 3:4", "7,:2 2:2 4:2 2:2 7,:2 2:2 4:4",
       "1:2 3:2 5:2 3:2 1:2 3:2 5:4", "5:4 7:2 5:2 2:4 7,:4",
       "6,:2 1:2 3:2 1:2 6,:2 1:2 3:4", "7,:2 2:2 4:2 2:2 7,:2 2:2 4:4",
       "5,:2 7,:2 2:2 7,:2 5,:2 7,:2 2:4", "1:6 3:2 5:4 3:2 1:2"]

MAIN = build(
    118, "minor", 76, 64, 40,
    [
        dict(chords=[1, 1, 6, 6, 3, 3, 7, 7], lead=_MA, bass="octave",
             arp="up", drum="four"),
        dict(chords=[6, 7, 1, 5, 6, 7, 5, 1], lead=_MB, bass="bounce",
             arp="broken", drum="four", fill=True),
    ],
    lead_duty=0.5, lead_vol=0.19, bass_vol=0.27, drum_vol=0.22)

# ----------------------------------------------------------------------
SONGS = {"menu": SELECT, "main": MAIN}
SONGS.update({key: spec for key, _title, spec in GAME_TRACKS})
TRACK_KEYS = tuple(key for key, _t, _s in GAME_TRACKS)
TRACK_TITLES = {key: title for key, title, _s in GAME_TRACKS}
