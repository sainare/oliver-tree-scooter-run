




















   



import random



MODES = {

    "minor":      (0, 2, 3, 5, 7, 8, 10),

    "major":      (0, 2, 4, 5, 7, 9, 11),

    "dorian":     (0, 2, 3, 5, 7, 9, 10),

    "phrygian":   (0, 1, 3, 5, 7, 8, 10),

    "lydian":     (0, 2, 4, 6, 7, 9, 11),

    "mixolydian": (0, 2, 4, 5, 7, 9, 10),

    "harmonic":   (0, 2, 3, 5, 7, 8, 11),

}

_NAMES = ("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")



                                                                            

BASS = {

    "pulse":  "r . r . r . r . r . r . r . r .",

    "bounce": "r . o . r . o . r . o . r . o .",

    "octave": "r . . . o . r . . . o . r . f .",

    "sync":   "r . . r . . r . . r . r . . r .",

    "walk":   "r . . . t . . . f . . . t . . .",

    "half":   "r . . . . . . . f . . . . . . .",

    "gallop": "r . r r . r r . r . r r . r r .",

    "pedal":  "r . . . . . . . r . . . . . . .",

    "swing":  "r . . . f . . . o . . . f . . .",

    "funk":   "r . . r . r . . r . . r . . o .",

    "chug":   "r r . r r . r r . r r . r r . r",

}

ARP = {                                                                  

    "up":        "r t f t r t f t r t f t r t f t",

    "broken":    "r f t f r f t f r f t f r f t f",

    "wide":      "r f o f r f o f r f o f r f o f",

    "stab":      "- - T - - - T - - - T - - - T -",

    "pulse":     "r - r - r - r - r - r - r - r -",

    "pad":       "t . . . . . . . f . . . . . . .",

    "sparkle":   "o - f - T - f - o - f - T - f -",

    "gate":      "r - r - t - t - f - f - o - o -",

    "pingpong":  "r t f o f t r t f o f t r t f t",

    "sixteenth": "r r t t f f t t r r t t f f t t",

    "down":      "o f t r o f t r o f t r o f t r",

}

DRUM = {

    "four":  "KH - H - SH - H - KH - H K SH - H -",

    "rock":  "KH - H - SH - H - KH - KH - SH - H -",

    "half":  "KH - H - H - H - SH - H - H - H -",

    "dnb":   "KH - H - SH - H K - K H - SH - H -",

    "disco": "KH - H - SH - H - KH - H - SH - H H",

    "shuf":  "KH H H H SH H H H KH H KH H SH H H H",

    "march": "KH - S - KH - S - KH - S - KH S S S",

    "euro":  "K - H - KS - H - K - H - KS - H -",

}

FILL = "KH - S - S - S S KS S KS S S S S S"

REST = "- - - - - - - - - - - - - - - -"



                                                                                

                                                                           

                                                                          

MOTIFS = {

    "calm": [

        "4:6 2:4 0:6", "0:4 2:4 4:4 2:4", "7:8 4:4 2:4", "2:8 4:4 7:4",

        "4:4 2:4 4:4 7:4", "0:6 2:2 4:8", "7:6 5:2 4:4 2:4", "2:4 4:4 2:4 0:4",

        "4:8 2:4 0:4", "0:8 4:4 2:4",

    ],

    "mid": [

        "0:3 2:3 4:3 2:2 0:5", "4:3 2:3 0:2 2:4 4:4",

        "0:2 2:2 4:2 2:2 7:4 4:2 2:2", "4:2 4:2 4:2 5:2 2:4 0:4",

        "2:3 4:3 7:3 4:2 2:5", "7:3 5:1 4:2 2:2 4:4 7:4",

        "0:2 0:2 2:2 4:2 2:2 0:2 2:2 4:2", "4:4 4:3 5:1 2:4 0:2 2:2",

        "7:4 4:2 2:2 0:4 2:4", "2:2 4:2 2:2 0:2 2:2 4:2 7:4",

    ],

    "drive": [

        "0:2 2:2 4:2 2:2 0:2 2:2 4:2 7:2",

        "0:1 2:1 4:1 2:1 0:1 2:1 4:1 2:1 7:4 4:2 2:2",

        "4:2 2:2 0:2 2:2 4:2 7:2 4:2 2:2", "7:2 4:2 7:2 9:2 7:2 4:2 2:2 4:2",

        "0:2 0:2 2:2 4:2 7:2 4:2 2:2 0:2",

        "0:1 2:1 4:1 7:1 4:1 2:1 0:1 2:1 4:4 2:2 0:2",

        "7:2 7:2 4:2 7:2 9:2 7:2 4:2 2:2", "0:2 4:2 2:2 4:2 0:2 4:2 7:2 4:2",

    ],

    "hook": [

        "4:3 2:3 0:2 2:3 4:3 2:2", "0:3 4:3 2:2 7:3 4:3 2:2",

        "7:3 4:3 2:2 4:3 2:3 0:2", "2:3 4:3 7:2 4:3 2:3 0:2",

        "0:3 0:3 2:2 4:3 2:3 0:2", "4:3 7:3 4:2 2:3 4:3 7:2",

        "2:3 0:3 2:2 4:3 7:3 4:2",

    ],

    "cad": [                                                        

        "4:4 2:4 0:8", "2:4 4:4 7:8", "7:6 4:2 2:4 0:4",

        "4:2 2:2 0:4 2:4 0:2 -3:2", "0:8 2:4 0:4", "4:6 2:2 0:8",

    ],

    "fill": [                                                      

        "0:2 2:2 4:2 7:2 9:2 7:2 4:2 2:2", "7:2 4:2 2:2 0:2 2:2 4:2 7:2 9:2",

        "4:1 2:1 0:1 2:1 4:1 7:1 9:1 7:1 4:4 7:2 4:2",

    ],

}



                                                                

                                                

PROGS = {

    "minor": [[1, 6, 3, 7], [1, 4, 5, 1], [1, 7, 6, 7], [1, 6, 7, 1],

              [1, 3, 7, 6], [1, 4, 7, 3], [6, 7, 1, 1], [1, 6, 4, 5],

              [1, 5, 6, 4], [1, 3, 4, 7]],

    "major": [[1, 5, 6, 4], [1, 4, 5, 4], [1, 6, 4, 5], [6, 4, 1, 5],

              [1, 3, 4, 5], [1, 4, 6, 5], [4, 5, 1, 6], [1, 5, 4, 5],

              [1, 6, 2, 5]],

    "dorian": [[1, 4, 1, 7], [1, 2, 4, 1], [1, 7, 4, 1], [1, 4, 5, 4],

               [1, 3, 4, 7], [4, 7, 1, 1], [1, 4, 7, 4]],

    "mixolydian": [[1, 7, 4, 1], [1, 4, 7, 1], [1, 5, 4, 1], [1, 7, 6, 7],

                   [4, 1, 5, 1], [1, 4, 1, 7]],

    "lydian": [[1, 2, 5, 1], [1, 2, 1, 5], [1, 5, 2, 1], [1, 3, 2, 5],

               [6, 2, 1, 5], [1, 2, 3, 2]],

    "phrygian": [[1, 2, 1, 7], [1, 2, 3, 2], [1, 7, 6, 7], [1, 4, 2, 1],

                 [1, 2, 7, 1], [1, 3, 2, 1]],

    "harmonic": [[1, 4, 5, 1], [1, 6, 5, 1], [1, 4, 5, 6], [1, 5, 6, 5],

                 [1, 4, 1, 5], [6, 5, 1, 5]],

}



                                                                                

                                                                             

STYLES = [

    dict(name="synthwave", mode="minor", energy="mid", tempo=0.5,

         bass=("pulse", "octave"), arp=("up", "broken", "wide"),

         drum=("four", "four", "euro"), duty=0.5, hduty=0.25),

    dict(name="sunny", mode="major", energy="mid", tempo=0.4,

         bass=("bounce", "walk"), arp=("broken", "up", "wide"),

         drum=("rock", "rock", "four"), duty=0.25, hduty=0.5),

    dict(name="storm", mode="minor", energy="high", tempo=0.9,

         bass=("pulse", "sync"), arp=("up", "pulse", "broken"),

         drum=("dnb", "dnb", "march"), duty=0.125, lead_vol=0.17, bass_vol=0.30),

    dict(name="desert", mode="harmonic", energy="mid", tempo=0.3,

         bass=("walk", "sync"), arp=("broken", "up", "wide"),

         drum=("half", "rock", "rock"), duty=0.25, hduty=0.5),

    dict(name="midnight", mode="dorian", energy="low", tempo=0.3,

         bass=("bounce", "sync"), arp=("pulse", "up", "broken"),

         drum=("disco", "disco", "shuf"), duty=0.25, hduty=0.25),

    dict(name="dawn", mode="lydian", energy="mid", tempo=0.55,

         bass=("bounce", "octave"), arp=("up", "wide", "broken"),

         drum=("four", "four", "euro"), duty=0.25, hduty=0.5),

    dict(name="factory", mode="phrygian", energy="high", tempo=0.75,

         bass=("gallop", "pulse"), arp=("stab", "pulse", "broken"),

         drum=("march", "dnb", "march"), duty=0.125, lead_vol=0.17, bass_vol=0.31),

    dict(name="eurobeat", mode="mixolydian", energy="high", tempo=1.0,

         bass=("bounce", "octave"), arp=("wide", "up", "broken"),

         drum=("euro", "euro", "four"), duty=0.5, hduty=0.25),

    dict(name="pirate", mode="dorian", energy="mid", tempo=0.45,

         bass=("walk", "octave"), arp=("pulse", "broken", "up"),

         drum=("march", "rock", "march"), duty=0.25, hduty=0.25),

    dict(name="space", mode="lydian", energy="low", tempo=0.2,

         bass=("pedal", "half"), arp=("sparkle", "up", "wide"),

         drum=("half", "four", "four"), duty=0.5, hduty=0.5),

    dict(name="ice", mode="major", energy="mid", tempo=0.6,

         bass=("swing", "bounce"), arp=("sparkle", "broken", "up"),

         drum=("rock", "four", "euro"), duty=0.5, hduty=0.5),

    dict(name="jungle", mode="dorian", energy="high", tempo=0.65,

         bass=("funk", "sync"), arp=("gate", "up", "broken"),

         drum=("shuf", "dnb", "shuf"), duty=0.25, hduty=0.25),

    dict(name="carnival", mode="major", energy="mid", tempo=0.7,

         bass=("bounce", "pulse"), arp=("pulse", "up", "gate"),

         drum=("march", "four", "rock"), duty=0.25, hduty=0.25),

    dict(name="boss", mode="phrygian", energy="high", tempo=0.85,

         bass=("chug", "gallop"), arp=("stab", "up", "broken"),

         drum=("dnb", "march", "dnb"), duty=0.125, lead_vol=0.17, bass_vol=0.30),

    dict(name="metropolis", mode="mixolydian", energy="mid", tempo=0.5,

         bass=("funk", "octave"), arp=("pingpong", "wide", "up"),

         drum=("disco", "four", "disco"), duty=0.5, hduty=0.25),

    dict(name="chase", mode="harmonic", energy="high", tempo=0.95,

         bass=("sync", "gallop"), arp=("sixteenth", "up", "wide"),

         drum=("dnb", "euro", "dnb"), duty=0.25, hduty=0.25),

]



                                                                        

                                                                                

                                                                             

CATS = {

    "menu":   dict(prefix="m", seed=1000, offset=1, bpm=(92, 126), shift=-1,

                   key=4, form="menu16",

                   drum_map={"dnb": "rock", "march": "half", "euro": "four",

                             "shuf": "disco"},

                   bass_map={"gallop": "pulse", "chug": "pulse", "sync": "bounce"}),

    "select": dict(prefix="s", seed=2000, offset=5, bpm=(100, 132), shift=0,

                   key=0, form="select32",

                   drum_map={"dnb": "rock", "march": "rock"},

                   bass_map={"gallop": "bounce", "chug": "pulse"}),

    "game":   dict(prefix="g", seed=3000, offset=0, bpm=(128, 178), shift=0,

                   key=0, form="game24", drum_map={}, bass_map={}),

    "load":   dict(prefix="l", seed=4000, offset=9, bpm=(116, 152), shift=0,

                   key=0, form="load16", drum_map={"march": "four"},

                   bass_map={"chug": "pulse"}),

}



TITLES_BY_CAT = {

    "menu": ("ГЛАВНАЯ ТЕМА", "УТРЕННИЙ КОФЕ", "ВЕЧЕРНИЙ ГОРОД", "ЛЕТНИЙ БРИЗ",

             "НЕОНОВЫЕ ОГНИ", "ПЛЯЖ", "МЯГКИЙ СТАРТ", "СИНТ-ПОП",

             "ЗВЁЗДНАЯ НОЧЬ", "ДОРОГА ДОМОЙ", "ПИКСЕЛЬНЫЙ САД", "ТЁПЛЫЙ ВЕТЕР",

             "АРКАДА", "ЛУННЫЙ СВЕТ", "ЗОЛОТОЙ ЧАС", "ФИНАЛЬНЫЙ ТИТР"),

    "select": ("ВЫБОР ГЕРОЯ", "ГОТОВ К СТАРТУ", "РАЗМИНКА", "ТРЕНИРОВКА",

               "КОМАНДА", "ПОДГОТОВКА", "СКЕЙТ-ПАРК", "ВЕСЁЛЫЙ СКУТЕР",

               "ГАРАЖ", "ТЮНИНГ", "ПАДДОК", "СБОРЫ", "ПРИМЕРКА", "КУЛИСЫ",

               "ДЕБЮТ", "ГРИМЁРКА"),

    "game": ("НЕОН-ДРАЙВ", "СОЛНЕЧНЫЙ ДЕНЬ", "ГРОЗА", "ПУСТЫННЫЙ ЗАКАТ",

             "НОЧНОЙ ГОРОД", "РАССВЕТ", "ЗАВОД", "ТУРБО", "ПИРАТЫ",

             "КОСМОДРОМ", "ЛЕДНИК", "ДЖУНГЛИ", "КАРНАВАЛ", "БОСС",

             "МЕГАПОЛИС", "ПОГОНЯ"),

    "load": ("РАЗГОН", "ТУРБО-СТАРТ", "КИБЕР-ПАНК", "ГОРОД СПИТ",

             "ПОЛНЫЙ ВПЕРЁД", "ЛАЗЕРЫ", "ХРОМ", "ПЛАЗМА", "ГИПЕРПРЫЖОК",

             "СИНТ-ВОЛНА", "БАС-ДРОП", "ПИКСЕЛЬ-ПОП", "ТАЙМЛАЙН",

             "СКОРОСТЬ СВЕТА", "НОЧНОЙ ЗАПУСК", "ЭНЕРГИЯ"),

}

CAT_KEYS = {cat: tuple("%s%d" % (cfg["prefix"], i + 1) for i in range(16))

            for cat, cfg in CATS.items()}

TITLES = {key: TITLES_BY_CAT[cat][i]

          for cat, keys in CAT_KEYS.items() for i, key in enumerate(keys)}

CAT_ORDER = ("menu", "select", "game", "load")

                                                                            

                                                                                 

DEFAULT_PICKS = {"menu": 8, "select": 16, "game": 16, "load": 16}

CAT_LABELS = {"menu": "МЕНЮ", "select": "ПЕРСОНАЖ", "game": "ЗАБЕГ",

              "load": "ЗАГРУЗКА"}





class Motif(str):

                                                                                   





def _check16(pattern, what):

    n = len(pattern.split())

    if n != 16:

        raise ValueError("%s: %d шагов вместо 16: %r" % (what, n, pattern))





def _name(m):

    return "%s%d" % (_NAMES[m % 12], m // 12 - 1)





def _ext(scale, i):

    return scale[i % 7] + 12 * (i // 7)





def _chord(scale, degree):

    i = degree - 1

    return _ext(scale, i), _ext(scale, i + 2), _ext(scale, i + 4)





def _fold(midi, lo, hi):

                                                                                  

    while midi > hi:

        midi -= 12

    while midi < lo:

        midi += 12

    return midi





def _lead_bar(text, scale, root, shift, where):

                                                                             

    out, total = [], 0

    for tok in text.split():

        deg, _, dur = tok.partition(":")

        dur = int(dur or 1)

        total += dur

        if deg == "-":

            out.extend(["-"] * dur)

            continue

        base = deg.rstrip("',")

        octave = deg.count("'") - deg.count(",")

        d = int(base)

        midi = root + _ext(scale, d - 1) + 12 * octave + shift

        out.append(_name(midi))

        out.extend(["."] * (dur - 1))

    if total != 16:

        raise ValueError("%s: такт даёт %d шагов вместо 16: %r"

                         % (where, total, text))

    return out





def _motif_bar(text, scale, root, degree, shift, where):

                                                                           

    out, total = [], 0

    for tok in text.split():

        off, _, dur = tok.partition(":")

        dur = int(dur)

        total += dur

        if off == "r":

            out.extend(["-"] * dur)

            continue

        midi = root + _ext(scale, degree - 1 + int(off)) + shift

        out.append(_name(_fold(midi, 50, 88)))

        out.extend(["."] * (dur - 1))

    if total != 16:

        raise ValueError("%s: мотив даёт %d шагов вместо 16: %r"

                         % (where, total, text))

    return out





def _pad_bar(scale, root, degree, shift):

                                                                      

    i = degree - 1

    notes = []

    for idx in (i + 4, i + 2):

        midi = root + _ext(scale, idx) + shift

        notes.append(_name(_fold(midi, 50, 88)))

    return [notes[0]] + ["."] * 7 + [notes[1]] + ["."] * 7





def build(bpm, mode, lead_root, arp_root, bass_root, sections, lead_duty=0.5,

          lead_vol=0.19, harm_duty=0.25, harm_vol=0.11, bass_vol=0.27,

          drum_vol=0.23):

    scale = MODES[mode]

    lead, harm, bass, drum = [], [], [], []

    all_chords = []

    for si, sec in enumerate(sections):

        all_chords.extend(sec["chords"])

        chords = sec["chords"]

        bars = sec.get("lead")

        for bi, deg in enumerate(chords):

            where = "секция %d, такт %d" % (si + 1, bi + 1)

            r0, t0, f0 = _chord(scale, deg)

            shift = sec.get("shift", 0)

                     

            if bars is None:

                lead.extend(["-"] * 16)

            elif bars == "pad":

                lead.extend(_pad_bar(scale, lead_root, deg, shift))

            else:

                bar = bars[bi % len(bars)]

                if isinstance(bar, Motif):

                    lead.extend(_motif_bar(bar, scale, lead_root, deg, shift,

                                           where))

                else:

                    lead.extend(_lead_bar(bar, scale, lead_root, shift, where))

                 

            bt = {"r": _name(bass_root + r0), "o": _name(bass_root + r0 + 12),

                  "f": _name(bass_root + f0), "t": _name(bass_root + t0),

                  "b": _name(bass_root + f0 - 12)}

            bass.extend(bt.get(tok, tok) for tok in

                        BASS[sec.get("bass", "pulse")].split())

                                 

            at = {"r": _name(_fold(arp_root + r0, 40, 84)),

                  "t": _name(_fold(arp_root + t0, 40, 84)),

                  "f": _name(_fold(arp_root + f0, 40, 84)),

                  "o": _name(_fold(arp_root + r0 + 12, 40, 84)),

                  "T": _name(_fold(arp_root + t0 + 12, 40, 84)),

                  "F": _name(_fold(arp_root + f0 + 12, 40, 84))}

            style = sec.get("arp")

            if style:

                harm.extend(at.get(tok, tok) for tok in ARP[style].split())

            else:

                harm.extend(["-"] * 16)

                                                         

            dstyle = sec.get("drum")

            if not dstyle:

                drum.extend(REST.split())

            elif sec.get("fill") and bi == len(chords) - 1:

                drum.extend(FILL.split())

            else:

                drum.extend(DRUM[dstyle].split())

    return dict(bpm=bpm, lead=" ".join(lead), harm=" ".join(harm),

                bass=" ".join(bass), drum=" ".join(drum), lead_duty=lead_duty,

                lead_vol=lead_vol, harm_duty=harm_duty, harm_vol=harm_vol,

                bass_vol=bass_vol, drum_vol=drum_vol,

                meta=dict(mode=mode, chords=all_chords, lead_root=lead_root))





def _game(bpm, mode, lead_root, arp_root, bass_root, prog_a, prog_b, A, A_alt,

          B, B_alt, bass=("pulse", "pulse"), arp=("up", "broken", "wide"),

          drum=("four", "four", "four"), **params):

    
                                                       

    prog_c = [prog_b[2], prog_b[3], prog_b[0], prog_b[1]]

    sections = [

        dict(chords=prog_a, lead=A, bass=bass[0], arp=arp[0], drum=drum[0]),

        dict(chords=prog_a, lead=A[:3] + [A_alt], bass=bass[0], arp=arp[0],

             drum=drum[0], fill=True),

        dict(chords=prog_b, lead=B, bass=bass[1], arp=arp[1], drum=drum[1]),

        dict(chords=prog_c, lead="pad", bass="half", arp="pad", drum=None,

             shift=-12),

        dict(chords=prog_a, lead=A[:3] + [A_alt], bass=bass[1], arp=arp[2],

             drum=drum[2]),

        dict(chords=prog_b, lead=B[:3] + [B_alt], bass=bass[1], arp=arp[2],

             drum=drum[2], fill=True),

    ]

    return build(bpm, mode, lead_root, arp_root, bass_root, sections, **params)





                                                                        

                                                                          

                                                                        

def _hand_g1():                                             

    return _game(

        150, "minor", 69, 57, 45, [1, 6, 3, 7], [6, 7, 1, 5],

        A=["5:4 1':4 3':4 2':2 1':2", "6:4 1':4 6:4 5:2 3:2",

           "3:4 5:4 7:4 1':2 7:2", "2':4 7:4 4:4 7:2 2':2"],

        A_alt="2':2 4':2 2':2 7:2 5:2 7:2 2':2 4':2",

        B=["1':2 1':2 6:2 1':2 3':4 1':2 6:2", "2':2 2':2 7:2 2':2 4':4 2':2 7:2",

           "3':2 3':2 1':2 3':2 5':4 3':2 1':2", "7:2 5:2 2:2 5:2 7:6 5:2"],

        B_alt="7:2 5:2 2:2 5:2 7:2 2':2 7:2 5:2",

        bass=("pulse", "octave"), arp=("up", "broken", "wide"),

        drum=("four", "four", "euro"), lead_duty=0.5)





def _hand_g2():                                                           

    return _game(

        138, "major", 67, 55, 43, [1, 5, 6, 4], [4, 5, 3, 6],

        A=["1:2 3:2 5:2 3:2 1':4 5:2 3:2", "5:2 7:2 2':2 7:2 5':4 2':2 7:2",

           "6:2 1':2 3':2 1':2 6:4 3':2 1':2", "4:2 6:2 1':2 6:2 4':4 1':2 6:2"],

        A_alt="4:2 6:2 1':2 3':2 5':4 3':2 1':2",

        B=["6:6 4:2 6:4 1':4", "7:6 5:2 7:4 2':4", "5:6 3:2 5:4 7:4",

           "6:4 3':4 1':4 6:4"],

        B_alt="6:2 1':2 3':2 1':2 6:4 5:2 6:2",

        bass=("bounce", "walk"), arp=("broken", "up", "wide"),

        drum=("rock", "rock", "four"), lead_duty=0.25, harm_duty=0.5)





def _hand_g3():                                              

    return _game(

        168, "minor", 74, 62, 38, [1, 6, 7, 1], [4, 5, 6, 5],

        A=["1:1 3:1 5:1 3:1 1:1 3:1 5:1 3:1 1':4 5:2 3:2",

           "6:1 1':1 3':1 1':1 6:1 1':1 3':1 1':1 6:4 3:2 1:2",

           "7,:1 2:1 4:1 2:1 7,:1 2:1 4:1 2:1 7:4 4:2 2:2", "1:6 5:2 3:4 1:4"],

        A_alt="1:2 3:2 5:2 1':2 5:2 3:2 1:4",

        B=["4:2 6:2 1':2 6:2 4:2 6:2 1':4", "5:2 7:2 2':2 7:2 5:2 7:2 2':4",

           "6:2 1':2 3':2 1':2 6:2 1':2 3':4", "5:2 7:2 2':2 7:2 5:8"],

        B_alt="5:2 7:2 2':2 7:2 5:2 7:2 5:2 3:2",

        bass=("pulse", "sync"), arp=("up", "pulse", "broken"),

        drum=("dnb", "dnb", "march"), lead_duty=0.125, lead_vol=0.17,

        bass_vol=0.30, drum_vol=0.25)





def _hand_g4():                                                      

    return _game(

        128, "harmonic", 64, 52, 40, [1, 4, 5, 1], [6, 5, 1, 5],

        A=["5':3 4':1 3':2 2':2 1':3 7:1 1':2 3':2",

           "4':2 3':1 2':1 1':4 6:2 7:2 1':4",

           "5':4 7':2 5':2 2':4 7:4", "1':6 7:2 1':4 5:4"],

        A_alt="1':2 3':2 5':2 3':2 1':2 7:2 5:2 1':2",

        B=["6:2 1':2 3':2 1':2 6:4 3':2 1':2", "5:2 7:2 2':2 7:2 5:4 2':2 7:2",

           "1':6 3':2 5':4 3':4", "5':4 2':2 5':2 7:4 5:4"],

        B_alt="5':2 7':2 5':2 2':2 7:2 2':2 5':4",

        bass=("walk", "sync"), arp=("broken", "up", "wide"),

        drum=("half", "rock", "rock"), lead_duty=0.25, harm_duty=0.5)





def _hand_g5():                                                      

    return _game(

        124, "dorian", 62, 50, 38, [1, 4, 1, 7], [4, 7, 1, 5],

        A=["5':3 3':3 1':2 3':3 5':3 3':2", "4':3 6':3 1'':2 6':3 4':3 6':2",

           "5':3 3':3 1':2 3':3 5':3 7':2", "7:3 2':3 4':2 2':3 7:3 2':2"],

        A_alt="7:3 2':3 4':2 7':3 4':3 2':2",

        B=["6:2 1':2 4':2 1':2 6:2 1':2 4':4", "7:2 2':2 4':2 2':2 7:2 2':2 4':4",

           "1':2 3':2 5':2 3':2 1':2 3':2 5':4", "5:2 7:2 2':2 7:2 5:8"],

        B_alt="5:2 7:2 2':2 4':2 2':2 7:2 5:4",

        bass=("bounce", "sync"), arp=("pulse", "up", "broken"),

        drum=("disco", "disco", "shuf"), lead_duty=0.25)





def _hand_g6():                                                    

    return _game(

        144, "lydian", 65, 53, 41, [1, 2, 5, 1], [6, 3, 2, 5],

        A=["1':3 3':3 5':2 3':3 1':3 5:2", "2':3 4':3 6':2 4':3 2':3 6:2",

           "5:3 7:3 2':2 7:3 5:3 2':2", "1':6 5:2 3':4 1':4"],

        A_alt="1':2 3':2 5':2 3':2 1':2 5:2 3:2 1':2",

        B=["6:2 1':2 3':2 1':2 6:2 1':2 3':4", "3:2 5:2 7:2 5:2 3:2 5:2 7:4",

           "2':2 4':2 6':2 4':2 2':2 4':2 6':4", "5:4 7:2 5:2 2':4 7:4"],

        B_alt="5:2 7:2 2':2 5':2 2':2 7:2 5:4",

        bass=("bounce", "octave"), arp=("up", "wide", "broken"),

        drum=("four", "four", "euro"), lead_duty=0.25, harm_duty=0.5)





def _hand_g7():                                                       

    return _game(

        160, "phrygian", 72, 60, 36, [1, 2, 1, 7], [4, 1, 2, 1],

        A=["1:2 1:1 2:1 1:2 3:2 1:2 5:2 3:2 1:2",

           "2:2 2:1 3:1 2:2 4:2 2:2 6:2 4:2 2:2",

           "1:2 1:1 2:1 1:2 3:2 1:2 5:2 3:2 5:2",

           "7,:2 7,:1 1:1 7,:2 2:2 7,:2 4:2 2:2 7,:2"],

        A_alt="7,:2 2:2 4:2 6:2 4:2 2:2 7,:4",

        B=["4:2 4:1 5:1 4:2 6:2 4:2 1':2 6:2 4:2", "1:2 3:2 5:2 3:2 1:2 3:2 5:4",

           "2:2 4:2 6:2 4:2 2:2 4:2 6:4", "1:6 3:2 5:4 1':4"],

        B_alt="1:2 3:2 5:2 1':2 5:2 3:2 1:4",

        bass=("gallop", "pulse"), arp=("stab", "pulse", "broken"),

        drum=("march", "dnb", "march"), lead_duty=0.125, lead_vol=0.17,

        bass_vol=0.31, drum_vol=0.26)





def _hand_g8():                                                       

    return _game(

        176, "mixolydian", 70, 58, 46, [1, 7, 4, 1], [6, 4, 1, 5],

        A=["1:2 3:2 5:2 1':2 5:2 3:2 1:2 3:2",

           "7,:2 2:2 4:2 7:2 4:2 2:2 7,:2 2:2",

           "4:2 6:2 1':2 4':2 1':2 6:2 4:2 6:2", "1':4 5:2 3:2 1':4 3:2 5:2"],

        A_alt="1:2 3:2 5:2 1':2 3':2 1':2 5:2 3:2",

        B=["6:2 1':2 3':2 1':2 6:2 1':2 3':4", "4:2 6:2 1':2 6:2 4:2 6:2 1':4",

           "1:2 3:2 5:2 3:2 1:2 3:2 5:4", "5:2 7:2 2':2 7:2 5:8"],

        B_alt="5:2 7:2 2':2 4':2 2':2 7:2 5:4",

        bass=("bounce", "octave"), arp=("wide", "up", "broken"),

        drum=("euro", "euro", "four"), lead_duty=0.5, drum_vol=0.24)





def _hand_s1():                                              

    sa = ["3:4 5:2 3:2 1':4 5:4", "7:4 5:2 7:2 2':4 7:4",

          "6:4 1':2 6:2 3':4 1':4", "4:4 6:2 4:2 1':4 6:4"]

    sa_alt = "4:2 6:2 1':2 6:2 4:2 5:2 7:2 2':2"

    sb = ["1':3 7:1 6:2 5:2 6:4 1':4", "6:3 5:1 4:2 3:2 4:4 6:4",

          "5:3 4:1 3:2 2:2 3:4 5:4", "7:4 2':4 5:4 7:4"]

    sb_alt = "7:2 2':2 7:2 5:2 7:2 2':2 5:4"

    sc = ["6:8 4:8", "7:8 5:8", "3:8 5:8", "6:8 1':4 3':4"]

    sd = ["4:2 6:2 1':2 6:2 4:2 6:2 1':4", "6:2 1':2 3':2 1':2 6:2 1':2 3':4",

          "7:2 2':2 5:2 7:2 2':2 7:2 5:4", "7:2 2':2 4':2 2':2 7:2 5:2 7:4"]

    return build(

        110, "major", 60, 48, 36,

        [

            dict(chords=[1, 5, 6, 4], lead=None, bass="walk", arp="up",

                 drum=None),

            dict(chords=[1, 5, 6, 4], lead=sa, bass="octave", arp="up",

                 drum="half"),

            dict(chords=[1, 5, 6, 4], lead=sa[:3] + [sa_alt], bass="bounce",

                 arp="broken", drum="rock", fill=True),

            dict(chords=[6, 4, 1, 5], lead=sb, bass="bounce", arp="up",

                 drum="rock"),

            dict(chords=[4, 5, 3, 6], lead=sc, bass="half", arp="stab",

                 drum=None),

            dict(chords=[1, 5, 6, 4], lead=sa, bass="bounce", arp="wide",

                 drum="four"),

            dict(chords=[6, 4, 1, 5], lead=sb[:3] + [sb_alt], bass="octave",

                 arp="broken", drum="four", fill=True),

            dict(chords=[4, 6, 5, 5], lead=sd, bass="bounce", arp="wide",

                 drum="four", fill=True),

        ],

        lead_duty=0.25, lead_vol=0.18, bass_vol=0.26, drum_vol=0.21)





def _hand_m1():                                                

    ma = ["1:3 3:3 5:3 4:2 3:5", "1:3 3:3 4:2 5:4 7:2 5:2",

          "6,:3 1:3 3:3 7,:2 1:5", "6,:3 1:3 3:2 4:4 3:2 1:2",

          "5,:3 7,:3 3:3 2:2 7,:5", "5,:3 7,:3 3:2 4:4 5:2 3:2",

          "4,:3 7,:3 2:3 1:2 7,:5", "4,:2 7,:2 2:2 4:2 -:2 5:2 4:2 2:2"]

    mb = ["6,:2 1:2 3:2 1:2 6,:2 1:2 3:4", "7,:2 2:2 4:2 2:2 7,:2 2:2 4:4",

          "1:2 3:2 5:2 3:2 1:2 3:2 5:4", "5:4 7:2 5:2 2:4 7,:4",

          "6,:2 1:2 3:2 1:2 6,:2 1:2 3:4", "7,:2 2:2 4:2 2:2 7,:2 2:2 4:4",

          "5,:2 7,:2 2:2 7,:2 5,:2 7,:2 2:4", "1:6 3:2 5:4 3:2 1:2"]

    return build(

        118, "minor", 76, 64, 40,

        [

            dict(chords=[1, 1, 6, 6, 3, 3, 7, 7], lead=ma, bass="octave",

                 arp="up", drum="four"),

            dict(chords=[6, 7, 1, 5, 6, 7, 5, 1], lead=mb, bass="bounce",

                 arp="broken", drum="four", fill=True),

        ],

        lead_duty=0.5, lead_vol=0.19, bass_vol=0.27, drum_vol=0.22)





_HAND = {"g1": _hand_g1, "g2": _hand_g2, "g3": _hand_g3, "g4": _hand_g4,

         "g5": _hand_g5, "g6": _hand_g6, "g7": _hand_g7, "g8": _hand_g8,

         "s1": _hand_s1, "m1": _hand_m1}





                                                                        

                                                  

                                                                        

def _phrase(rng, mood_a, mood_b):

                                                                  

    a = Motif(rng.choice(MOTIFS[mood_a]))

    a2 = Motif(rng.choice(MOTIFS[mood_a]))

    b = Motif(rng.choice(MOTIFS[mood_b]))

    c = Motif(rng.choice(MOTIFS["cad"]))

    return list(rng.choice([(a, a, b, c), (a, b, a, c), (a, a, a2, c),

                            (a, b, a2, c)]))





def _fill_bar(rng):

    return Motif(rng.choice(MOTIFS["fill"]))





def _pick_prog(mode, n, skip=None):

    progs = PROGS[mode]

    p = progs[n % len(progs)]

    if skip is not None and p == skip:

        p = progs[(n + 1) % len(progs)]

    return list(p)





def _tonic(cat, index):

    

                                                                                  

    return (CATS[cat]["key"] + 7 * index + 4 * (index // 12)) % 12





def compose(cat, index):

                                                                                

    cfg = CATS[cat]

    style_id = (index + cfg["offset"]) % len(STYLES)

    st = STYLES[style_id]

    rng = random.Random(cfg["seed"] + index * 131 + style_id * 17)

    mode = st["mode"]

    tonic = _tonic(cat, index)

    lead_root = 57 + ((tonic - 57) % 12)                                             

    arp_root = lead_root - 12

    bass_root = 36 + tonic

    lo, hi = cfg["bpm"]

    bpm = int(round(lo + (hi - lo) * st["tempo"] + rng.randint(-3, 3)))

    energies = ("low", "mid", "high")

    e = max(0, min(2, energies.index(st["energy"]) + cfg["shift"]))

    ma, mb = (("calm", "mid"), ("mid", "hook"), ("hook", "drive"))[e]

    prog_a = _pick_prog(mode, index + style_id)

    prog_b = _pick_prog(mode, index + style_id + 2, skip=prog_a)

    dmap, bmap = cfg["drum_map"], cfg["bass_map"]

    drums = tuple(dmap.get(x, x) for x in st["drum"])

    basses = tuple(bmap.get(x, x) for x in st["bass"])

    arps = st["arp"]

    A = _phrase(rng, ma, mb)

    B = _phrase(rng, mb, ma)

    a_alt, b_alt = _fill_bar(rng), _fill_bar(rng)

    params = dict(lead_duty=st["duty"], harm_duty=st.get("hduty", 0.25))

    for k in ("lead_vol", "bass_vol", "drum_vol"):

        if k in st:

            params[k] = st[k]

    prog_c = [prog_b[2], prog_b[3], prog_b[0], prog_b[1]]

    form = cfg["form"]

    if form == "game24":

        sections = [

            dict(chords=prog_a, lead=A, bass=basses[0], arp=arps[0], drum=drums[0]),

            dict(chords=prog_a, lead=A[:3] + [a_alt], bass=basses[0], arp=arps[0],

                 drum=drums[0], fill=True),

            dict(chords=prog_b, lead=B, bass=basses[1], arp=arps[1], drum=drums[1]),

            dict(chords=prog_c, lead="pad", bass="half", arp="pad", drum=None,

                 shift=-12),

            dict(chords=prog_a, lead=A[:3] + [a_alt], bass=basses[1], arp=arps[2],

                 drum=drums[2]),

            dict(chords=prog_b, lead=B[:3] + [b_alt], bass=basses[1], arp=arps[2],

                 drum=drums[2], fill=True),

        ]

    elif form == "load16":

        sections = [

            dict(chords=prog_a, lead=A, bass=basses[0], arp=arps[0], drum=drums[0]),

            dict(chords=prog_a, lead=A[:3] + [a_alt], bass=basses[0], arp=arps[2],

                 drum=drums[2], fill=True),

            dict(chords=prog_b, lead=B, bass=basses[1], arp=arps[1], drum=drums[1]),

            dict(chords=prog_b, lead=B[:3] + [b_alt], bass=basses[1], arp=arps[2],

                 drum=drums[2], fill=True),

        ]

    elif form == "menu16":

        sections = [

            dict(chords=prog_a, lead=A, bass=basses[0], arp=arps[0], drum=drums[0]),

            dict(chords=prog_a, lead=A[:3] + [a_alt], bass=basses[0], arp=arps[1],

                 drum=drums[0], fill=True),

            dict(chords=prog_b, lead=B, bass=basses[1], arp=arps[1], drum=drums[1]),

            dict(chords=prog_a, lead=A[:3] + [a_alt], bass=basses[1], arp=arps[2],

                 drum=drums[2], fill=True),

        ]

    else:                                                 

        D = _phrase(rng, "drive", "hook")

        sections = [

            dict(chords=prog_a, lead=None, bass="walk", arp=arps[0], drum=None),

            dict(chords=prog_a, lead=A, bass=basses[0], arp=arps[0],

                 drum=drums[0]),

            dict(chords=prog_a, lead=A[:3] + [a_alt], bass=basses[0],

                 arp=arps[1], drum=drums[1], fill=True),

            dict(chords=prog_b, lead=B, bass=basses[1], arp=arps[0],

                 drum=drums[1]),

            dict(chords=prog_c, lead="pad", bass="half", arp="pad", drum=None,

                 shift=-12),

            dict(chords=prog_a, lead=A, bass=basses[1], arp=arps[2],

                 drum=drums[2]),

            dict(chords=prog_b, lead=B[:3] + [b_alt], bass=basses[0],

                 arp=arps[1], drum=drums[2], fill=True),

            dict(chords=prog_b, lead=D, bass=basses[1], arp=arps[2],

                 drum=drums[2], fill=True),

        ]

    return build(bpm, mode, lead_root, arp_root, bass_root, sections, **params)





                                                                        

                                        

                                                                        

_CACHE = {}





def all_keys():

    return [key for cat in CAT_ORDER for key in CAT_KEYS[cat]]





def spec(key):

                                                                                 

    if key in _CACHE:

        return _CACHE[key]

    result = None

    if key in _HAND:

        result = _HAND[key]()

    else:

        for cat, keys in CAT_KEYS.items():

            if key in keys:

                result = compose(cat, keys.index(key))

    if result is not None:

        _CACHE[key] = result

    return result





def category_of(key):

    for cat, keys in CAT_KEYS.items():

        if key in keys:

            return cat

    return None





                                                                            

def validate_patterns():

    for table, what in ((BASS, "BASS"), (ARP, "ARP"), (DRUM, "DRUM")):

        for k, v in table.items():

            _check16(v, what + " " + k)

    _check16(FILL, "FILL")

    _check16(REST, "REST")





def validate_motifs():

                                                                            

    problems = []

    for mood, items in MOTIFS.items():

        for text in items:

            steps, active = 0, []

            for tok in text.split():

                off, _, dur = tok.partition(":")

                active.extend([int(off)] * int(dur))

                steps += int(dur)

            if steps != 16:

                problems.append((mood, text, "сумма %d" % steps))

                continue

            for beat in (0, 4, 8, 12):

                if active[beat] % 7 not in (0, 2, 4):

                    problems.append((mood, text, "нота %d на доле %d"

                                     % (active[beat], beat)))

    return problems

