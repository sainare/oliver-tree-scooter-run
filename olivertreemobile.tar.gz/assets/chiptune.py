"""Мини-синтезатор в духе NES: квадрат, треугольник и шум.

Вся встроенная музыка и все звуки считаются numpy'ем прямо при запуске,
поэтому игра не тащит с собой ни одного аудиофайла. При желании игрок
может положить рядом свой трек — см. find_external().
"""

import os
import sys

import pygame

if sys.platform != "emscripten":        # в браузере звук берётся из готовых файлов
    import numpy as np

# в браузере синтез при запуске слишком медленный: грузим готовые файлы,
# которые кладёт tools/bake_audio.py
WEB = sys.platform == "emscripten"
BAKED_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "audio")

SR = 44100                      # частота дискретизации
_NOTE = {"C": 0, "D": 2, "E": 4, "F": 5, "G": 7, "A": 9, "B": 11}


# --- ноты --------------------------------------------------------------
def note_to_midi(token):
    """'A#4' -> номер MIDI-ноты (C4 = 60)."""
    semi = _NOTE[token[0].upper()]
    i = 1
    if len(token) > 1 and token[1] in "#b":
        semi += 1 if token[1] == "#" else -1
        i = 2
    return 12 * (int(token[i:]) + 1) + semi


def midi_to_freq(m):
    return 440.0 * 2.0 ** ((m - 69) / 12.0)


def parse_pattern(pattern):
    """Строка трекера -> [(midi|None, длительность в шагах), ...].

    'A4' — взять ноту, '.' — тянуть предыдущее, '-' — пауза.
    """
    events = []
    for tok in pattern.split():
        if tok == ".":
            if events:
                events[-1][1] += 1
            else:
                events.append([None, 1])
        elif tok == "-":
            if events and events[-1][0] is None:
                events[-1][1] += 1
            else:
                events.append([None, 1])
        else:
            events.append([note_to_midi(tok), 1])
    return events


# --- волны -------------------------------------------------------------
def square(freq, n, duty=0.5):
    phase = (np.arange(n) * (freq / SR)) % 1.0
    return np.where(phase < duty, 1.0, -1.0)


def triangle(freq, n):
    phase = (np.arange(n) * (freq / SR)) % 1.0
    return 4.0 * np.abs(phase - 0.5) - 1.0


def envelope(n, a=0.004, d=0.06, s=0.65, r=0.05):
    """Простая ADSR-огибающая длиной n сэмплов."""
    env = np.ones(n)
    na = min(int(a * SR), n)
    nd = min(int(d * SR), n - na)
    nr = min(int(r * SR), max(0, n - na - nd))
    pos = 0
    if na:
        env[:na] = np.linspace(0.0, 1.0, na)
        pos = na
    if nd:
        env[pos:pos + nd] = np.linspace(1.0, s, nd)
        pos += nd
    hold = n - pos - nr
    if hold > 0:
        env[pos:pos + hold] = s
        pos += hold
    if n - pos > 0:
        env[pos:] = np.linspace(s, 0.0, n - pos)
    return env


# --- каналы ------------------------------------------------------------
def render_tone_channel(pattern, step_samples, total, kind="square",
                        duty=0.5, vol=0.22, octave=0, detune=0.0):
    buf = np.zeros(total)
    pos = 0
    for midi, steps in parse_pattern(pattern):
        length = steps * step_samples
        if midi is not None and pos < total:
            n = min(length, total - pos)
            freq = midi_to_freq(midi + 12 * octave) * (2.0 ** (detune / 1200.0))
            wave = square(freq, n, duty) if kind == "square" else triangle(freq, n)
            buf[pos:pos + n] += wave * envelope(n) * vol
        pos += length
    return buf


def _kick(n):
    freq = np.linspace(160.0, 45.0, n)
    phase = np.cumsum(freq) / SR
    env = np.exp(-np.linspace(0.0, 9.0, n))
    return np.sin(2 * np.pi * phase) * env


def _snare(n, rng):
    env = np.exp(-np.linspace(0.0, 14.0, n))
    tone = np.sin(2 * np.pi * np.arange(n) * 190.0 / SR) * 0.35
    return (rng.uniform(-1.0, 1.0, n) * 0.8 + tone) * env


def _hat(n, rng):
    env = np.exp(-np.linspace(0.0, 45.0, n))
    noise = rng.uniform(-1.0, 1.0, n)
    noise[1:] -= noise[:-1] * 0.7          # грубый «высокочастотный» фильтр
    return noise * env


def render_drum_channel(pattern, step_samples, total, vol=0.34, seed=7):
    """Токен — набор букв: 'K' бочка, 'S' малый, 'H' хэт.

    Буквы можно склеивать: 'KH' — бочка и хэт на одном шаге.
    """
    rng = np.random.default_rng(seed)
    buf = np.zeros(total)
    length = {"K": 0.14, "S": 0.16, "H": 0.05}
    for i, tok in enumerate(pattern.split()):
        pos = i * step_samples
        if pos >= total:
            break
        for ch in tok:
            if ch not in length:
                continue
            n = min(int(length[ch] * SR), total - pos)
            if ch == "K":
                sound = _kick(n)
            elif ch == "S":
                sound = _snare(n, rng)
            else:
                sound = _hat(n, rng) * 0.45
            buf[pos:pos + n] += sound * vol
    return buf


def mix(*parts):
    """Сложить дорожки разной длины, дополнив короткие тишиной."""
    n = max(len(p) for p in parts)
    out = np.zeros(n)
    for p in parts:
        out[:len(p)] += p
    return out


def _to_sound(mono, gain=0.85):
    mono = np.clip(mono, -1.0, 1.0) * gain
    data = (mono * 32767.0).astype(np.int16)
    stereo = np.ascontiguousarray(np.column_stack((data, data)))
    return pygame.sndarray.make_sound(stereo)


def render_song(song):
    """song: dict с bpm и партиями lead/harm/bass/drum."""
    step_samples = int(SR * 60.0 / song["bpm"] / 4.0)      # шаг = 1/16
    steps = max(len(song[k].split()) for k in ("lead", "bass", "drum")
                if k in song)
    total = steps * step_samples

    mix = np.zeros(total)
    mix += render_tone_channel(song["lead"], step_samples, total,
                               duty=song.get("lead_duty", 0.5),
                               vol=song.get("lead_vol", 0.20))
    if song.get("harm"):
        mix += render_tone_channel(song["harm"], step_samples, total,
                                   duty=0.25, vol=0.12, detune=6.0)
    mix += render_tone_channel(song["bass"], step_samples, total,
                               kind="tri", vol=song.get("bass_vol", 0.30))
    mix += render_drum_channel(song["drum"], step_samples, total,
                               vol=song.get("drum_vol", 0.32))
    return _to_sound(mix)


def sweep(f0, f1, dur, kind="square", duty=0.5, vol=0.3, curve=1.0):
    n = int(dur * SR)
    t = np.linspace(0.0, 1.0, n) ** curve
    freq = f0 + (f1 - f0) * t
    phase = np.cumsum(freq) / SR
    if kind == "square":
        wave = np.where((phase % 1.0) < duty, 1.0, -1.0)
    else:
        wave = np.sin(2 * np.pi * phase)
    return wave * envelope(n, a=0.002, d=dur * 0.3, s=0.55, r=dur * 0.45) * vol


def noise_burst(dur, vol=0.3, decay=12.0, seed=3):
    n = int(dur * SR)
    rng = np.random.default_rng(seed)
    return rng.uniform(-1.0, 1.0, n) * np.exp(-np.linspace(0, decay, n)) * vol


# --- материал ----------------------------------------------------------
# Тональность до минор измерена по видео-референсу (профиль высотных
# классов), темп там же вышел 159 BPM — но по просьбе игрока разогнан
# до 174. Взяты только эти параметры: они не охраняются авторским правом.
# Все мелодии, басы и барабаны ниже написаны с нуля.
#
# Ходы i-VI-III-VII (Cm-Ab-Eb-Bb): минор по букве, но за счёт мажорных
# III и VI звучит бодро и попадает в яркую дневную картинку.
SONG_GAME = dict(
    bpm=174,
    scale={0, 2, 3, 5, 7, 8, 10},          # до минор
    # Хук строится на повторе мотива: два такта одинаково начинаются
    # и по-разному заканчиваются — так мелодия запоминается.
    # референс заметно «серединный» (46% энергии), поэтому лид чуть громче
    # баса; сильнее подгонять смысла нет — телефонный микрофон срезал края
    lead_duty=0.5, lead_vol=0.22, bass_vol=0.26,
    # мелодия идёт шестнадцатыми пробежками — забег ощущается злее
    # Пентатоника (до-ми♭-фа-соль-си♭) звучит колюче и по-игровому.
    # Такты 1-2 начинаются одинаково — вопрос и ответ, легко запоминается.
    lead=(
        "C5 . C5 Eb5 F5 . G5 . Bb5 . G5 F5 Eb5 . C5 . "
        "C5 . C5 Eb5 F5 . G5 . C6 . Bb5 G5 F5 . Eb5 . "
        "F5 . F5 G5 Bb5 . C6 . Eb6 . C6 Bb5 G5 . F5 . "
        "G5 . Bb5 . C6 . Bb5 G5 F5 . Eb5 C5 D5 . Eb5 . "
    ),
    harm=(
        "G4 . . . Eb4 . . . G4 . . . Bb4 . . . "
        "G4 . . . Eb4 . . . C5 . . . Bb4 . . . "
        "C5 . . . Ab4 . . . C5 . . . Eb5 . . . "
        "Bb4 . . . G4 . . . Bb4 . . . G4 . . . "
    ),
    bass=(
        "C2 . C3 . C2 . Eb2 . F2 . C2 . G2 . Bb2 . "
        "C2 . C3 . C2 . Eb2 . F2 . C2 . G2 . Bb2 . "
        "F2 . F3 . F2 . Ab2 . Bb2 . F2 . C3 . Eb3 . "
        "G2 . G3 . G2 . Bb2 . C3 . G2 . F2 . Eb2 . "
    ),
    # Грув снят с референса: ровные хэты по восьмым, бочка на 1 и 3
    # плюс синкопа на «и» третьей доли, малый — на 2 и 4.
    drum=(
        "KH - H - SH - H - KH - KH - SH - H - "
        "KH - H - SH - H - KH - KH - SH - H - "
        "KH - H - SH - H - KH - KH - SH - H - "
        "KH - H - SH - H - KH - KH - SH - S S "
    ),
)

# Выбор персонажа: ре дорийский. Мажорная четвёртая ступень (си-бекар)
# убирает мрачность — получается расслабленно и чуть джазово.
SONG_MENU = dict(
    bpm=96,
    scale={2, 4, 5, 7, 9, 11, 0},          # ре дорийский
    lead_duty=0.25, lead_vol=0.18,
    bass_vol=0.26, drum_vol=0.20,
    lead=(
        "D5 . F5 . . A5 . . G5 . F5 . . . . . "
        "B4 . D5 . . G5 . . F5 . D5 . . . . . "
        "A4 . C5 . . F5 . . E5 . D5 . . . . . "
        "C5 . E5 . . G5 . . A5 . G5 . E5 . . . "
    ),
    harm=(
        "A4 . . . . . . . F4 . . . . . . . "
        "G4 . . . . . . . B4 . . . . . . . "
        "F4 . . . . . . . A4 . . . . . . . "
        "E4 . . . . . . . C5 . . . . . . . "
    ),
    bass=(
        "D2 . . . A2 . . . D2 . . . F2 . E2 . "
        "G2 . . . D3 . . . G2 . . . B2 . A2 . "
        "D2 . . . A2 . . . D2 . . . C3 . A2 . "
        "C3 . . . G2 . . . C3 . . . E3 . A2 . "
    ),
    drum=(
        "KH - - H SH - - - KH - - H SH - - H "
        "KH - - H SH - - - KH - - H SH - - H "
        "KH - - H SH - - - KH - - H SH - - H "
        "KH - - H SH - - - KH - - H SH - S S "
    ),
)


def make_riff(notes, vol=0.26):
    """Короткий оригинальный мотив кассеты: восходящее арпеджио квадратом."""
    parts = []
    for i, name in enumerate(notes):
        f = midi_to_freq(note_to_midi(name))
        dur = 0.10 if i < len(notes) - 1 else 0.26
        n = int(dur * SR)
        wave = square(f, n, 0.25) * envelope(n, a=0.003, d=dur * 0.4,
                                            s=0.6, r=dur * 0.5) * vol
        parts.append(wave)
    return _to_sound(np.concatenate(parts))


# Титульный экран: ля гармонический минор, ход i-VI-III-V.
# Мажорная доминанта (соль-диез) даёт драматичный подъём — фанфара.
SONG_TITLE = dict(
    bpm=132,
    scale={9, 11, 0, 2, 4, 5, 7, 8},       # ля минор + соль-диез
    lead_duty=0.5, lead_vol=0.20, bass_vol=0.28, drum_vol=0.26,
    lead=(
        "A4 . . E5 . . A5 . C6 . . . B5 . . . "
        "F4 . . C5 . . F5 . A5 . . . G5 . . . "
        "G4 . . C5 . . E5 . G5 . . . E5 . . . "
        "E4 . . G#4 . . B4 . E5 . . . G#5 . B5 . "
    ),
    harm=(
        "C4 . . . . . . . E4 . . . . . . . "
        "A3 . . . . . . . C4 . . . . . . . "
        "E4 . . . . . . . G4 . . . . . . . "
        "B3 . . . . . . . G#4 . . . . . . . "
    ),
    bass=(
        "A2 . . . E2 . . . A2 . . . C3 . E3 . "
        "F2 . . . C3 . . . F2 . . . A2 . C3 . "
        "C3 . . . G2 . . . C3 . . . E3 . G3 . "
        "E2 . . . B2 . . . E3 . . . B2 . E2 . "
    ),
    drum=(
        "KH - H - SH - H - KH - H - SH - H - "
        "KH - H - SH - H - KH - H - SH - H - "
        "KH - H - SH - H - KH - H - SH - H - "
        "KH - H - SH - H - KH - H - SH - S S "
    ),
)

# Экран проигрыша: фа минор, очень медленно, тонким «плачущим» тембром.
# Бас спускается по полутонам (фа - ми-бемоль - ре-бемоль - до) — это
# старинная фигура плача, мелодия сходит следом ступенями. Барабанов почти нет.
SONG_OVER = dict(
    bpm=60,
    scale={5, 7, 8, 10, 0, 1, 3},          # фа минор
    lead_duty=0.125, lead_vol=0.19, bass_vol=0.24, drum_vol=0.12,
    lead=(
        "Ab5 . . . . . G5 . F5 . . . . . . . "
        "G5 . . . . . F5 . Eb5 . . . . . . . "
        "F5 . . . . . Eb5 . Db5 . . . . . . . "
        "Eb5 . . . . . Db5 . C5 . . . . . . . "
    ),
    harm=(
        "C5 . . . . . . . . . . . . . . . "
        "Bb4 . . . . . . . . . . . . . . . "
        "Ab4 . . . . . . . . . . . . . . . "
        "G4 . . . . . . . Ab4 . . . . . . . "
    ),
    bass=(
        "F2 . . . . . . . F2 . . . . . . . "
        "Eb2 . . . . . . . Eb2 . . . . . . . "
        "Db2 . . . . . . . Db2 . . . . . . . "
        "C2 . . . . . . . C2 . . . . . . . "
    ),
    drum=(
        "K - - - - - - - - - - - - - - - "
        "K - - - - - - - - - - - - - - - "
        "K - - - - - - - - - - - - - - - "
        "K - - - - - - - H - - - - - - - "
    ),
)

EXTERNAL_NAMES = {"game": "soundtrack", "menu": "soundtrack_menu",
                  "title": "soundtrack_title", "over": "soundtrack_over"}
EXTERNAL_EXTS = (".ogg", ".mp3", ".wav", ".flac")


def find_external(folder):
    """Найти пользовательские треки рядом с игрой.

    Если положить `soundtrack.ogg` (или .mp3/.wav/.flac) в папку с игрой,
    он будет играть вместо встроенного чиптюна во время забега;
    `soundtrack_menu.*` — в меню. Файлы игрок подкладывает сам.
    """
    found = {}
    if not folder or not os.path.isdir(folder):
        return found
    for slot, stem in EXTERNAL_NAMES.items():
        for ext in EXTERNAL_EXTS:
            path = os.path.join(folder, stem + ext)
            if os.path.isfile(path):
                found[slot] = path
                break
    return found


class Audio:
    """Загружает музыку/звуки и рулит каналами."""

    def __init__(self, enabled=True, music_dir=None):
        self.enabled = enabled
        self.music_channel = None
        self.sfx = {}
        self.songs = {}
        self.muted = False
        self.desired = None
        self.external = {}
        self.playing_external = False
        # эти поля нужны и при выключенном звуке: их читает load_tapes
        self.music_dir = music_dir
        self.fade_left = 0           # сколько кадров ещё нарастает громкость
        self.fade_len = 1
        self.tapes = []
        self.tape_channel = None
        if not enabled:
            return
        self.external = {} if WEB else find_external(music_dir)
        self.tape_channel = pygame.mixer.Channel(1)
        pygame.mixer.set_num_channels(12)
        self.music_channel = pygame.mixer.Channel(0)
        if WEB:
            self._load_baked()
            return
        self.songs["title"] = render_song(SONG_TITLE)
        self.songs["menu"] = render_song(SONG_MENU)
        self.songs["game"] = render_song(SONG_GAME)
        self.songs["over"] = render_song(SONG_OVER)
        self.sfx["jump"] = _to_sound(sweep(240, 700, 0.13, duty=0.5, vol=0.30))
        self.sfx["jump2"] = _to_sound(sweep(420, 980, 0.12, duty=0.25, vol=0.28))
        self.sfx["pickup"] = _to_sound(
            np.concatenate([sweep(900, 900, 0.05, duty=0.5, vol=0.26),
                            sweep(1350, 1350, 0.09, duty=0.5, vol=0.26)]))
        self.sfx["hit"] = _to_sound(mix(
            noise_burst(0.18, vol=0.35),
            sweep(420, 80, 0.22, kind="sine", vol=0.30)))
        self.sfx["move"] = _to_sound(sweep(620, 620, 0.045, duty=0.25, vol=0.18))
        self.sfx["ramp"] = _to_sound(sweep(260, 1180, 0.26, duty=0.25,
                                           vol=0.28, curve=0.7))
        self.sfx["life"] = _to_sound(np.concatenate([   # плюс жизнь
            sweep(523, 523, 0.07, duty=0.5, vol=0.26),
            sweep(784, 784, 0.07, duty=0.5, vol=0.26),
            sweep(1046, 1046, 0.16, duty=0.5, vol=0.26)]))
        self.sfx["pause"] = _to_sound(np.concatenate([  # короткий щелчок паузы
            sweep(880, 880, 0.05, duty=0.25, vol=0.22),
            sweep(440, 440, 0.10, duty=0.25, vol=0.22)]))
        self.sfx["zone"] = _to_sound(np.concatenate([   # смена окружения
            sweep(392, 392, 0.07, duty=0.5, vol=0.24),
            sweep(523, 523, 0.07, duty=0.5, vol=0.24),
            sweep(659, 659, 0.07, duty=0.5, vol=0.24),
            sweep(784, 1046, 0.20, duty=0.25, vol=0.24)]))
        self.sfx["trick"] = _to_sound(sweep(300, 900, 0.10, duty=0.125,
                                            vol=0.22))
        self.sfx["star"] = _to_sound(np.concatenate([      # фанфара звезды
            sweep(f, f, 0.06, duty=0.5, vol=0.28)
            for f in (523, 622, 784, 932, 1047, 1245)]))
        self.sfx["flip"] = _to_sound(np.concatenate([      # восходящее арпеджио
            sweep(f, f, 0.055, duty=0.25, vol=0.26)
            for f in (523, 659, 784, 1047, 1319)]))
        self.sfx["select"] = _to_sound(
            np.concatenate([sweep(620, 620, 0.05, duty=0.5, vol=0.24),
                            sweep(930, 930, 0.11, duty=0.5, vol=0.24)]))
        self.sfx["over"] = _to_sound(np.concatenate([
            sweep(520, 520, 0.16, duty=0.5, vol=0.28),
            sweep(415, 415, 0.16, duty=0.5, vol=0.28),
            sweep(330, 330, 0.16, duty=0.5, vol=0.28),
            sweep(262, 200, 0.45, duty=0.5, vol=0.28),
        ]))

    def _load_baked(self):
        """Готовые ogg из audio/: имена song_*, sfx_*, tape_*."""
        for name in os.listdir(BAKED_DIR):
            stem, ext = os.path.splitext(name)
            if ext != ".ogg":
                continue
            kind, _, key = stem.partition("_")
            if kind == "song":
                self.songs[key] = pygame.mixer.Sound(
                    os.path.join(BAKED_DIR, name))
            elif kind == "sfx":
                self.sfx[key] = pygame.mixer.Sound(
                    os.path.join(BAKED_DIR, name))

    def load_tapes(self, tapes):
        """Собрать звук для каждой кассеты: свой рифф или файл игрока."""
        self.tapes = []
        if not self.enabled:
            return
        if WEB:
            self.tapes = [pygame.mixer.Sound(os.path.join(
                BAKED_DIR, "tape_" + t["slug"] + ".ogg")) for t in tapes]
            return
        for tape in tapes:
            sound = None
            if self.music_dir and os.path.isdir(self.music_dir):
                for ext in EXTERNAL_EXTS:
                    path = os.path.join(self.music_dir,
                                        "tape_" + tape["slug"] + ext)
                    if os.path.isfile(path):
                        try:
                            sound = pygame.mixer.Sound(path)
                        except pygame.error:
                            sound = None      # формат не открылся — берём рифф
                        break
            self.tapes.append(sound or make_riff(tape["riff"]))

    def play_tape(self, index):
        """Проиграть мотив подобранной кассеты поверх фоновой музыки."""
        if not self.enabled or self.muted or not self.tapes:
            return
        self.tape_channel.stop()
        self.tape_channel.play(self.tapes[index % len(self.tapes)])

    def _set_music_volume(self, v):
        if not self.enabled:
            return
        self.music_channel.set_volume(v)
        pygame.mixer.music.set_volume(v)

    def fade_in(self, frames):
        """Трек стартует с тишины и плавно набирает громкость."""
        if not self.enabled:
            return
        self.fade_len = self.fade_left = max(1, int(frames))
        self._set_music_volume(0.0)

    def tick(self):
        """Раз в кадр: ведёт нарастание громкости (smoothstep)."""
        if self.fade_left > 0:
            self.fade_left -= 1
            k = 1.0 - self.fade_left / self.fade_len
            self._set_music_volume(k * k * (3.0 - 2.0 * k))

    def _start(self, name):
        """Запустить трек: сначала пробуем файл игрока, иначе чиптюн."""
        self.fade_left = 0
        self._set_music_volume(1.0)
        # снимаем возможную паузу: иначе новый трек ляжет в замороженный
        # канал и будет молчать (например, при выходе в меню из паузы)
        self.music_channel.unpause()
        pygame.mixer.music.unpause()
        self.music_channel.stop()
        pygame.mixer.music.stop()
        self.playing_external = False
        path = self.external.get(name)
        if path:
            try:
                pygame.mixer.music.load(path)
                pygame.mixer.music.play(-1)
                self.playing_external = True
                return
            except pygame.error:
                pass                     # формат не открылся — играем чиптюн
        self.music_channel.play(self.songs[name], loops=-1)

    def play_music(self, name):
        """Запомнить нужный трек и включить его, если звук не выключен."""
        if not self.enabled or self.desired == name:
            return
        self.desired = name
        if not self.muted:
            self._start(name)

    def pause_music(self):
        """Приглушить фон на паузе, не теряя место в треке."""
        if not self.enabled:
            return
        self.music_channel.pause()
        pygame.mixer.music.pause()

    def resume_music(self):
        if not self.enabled or self.muted:
            return
        self.music_channel.unpause()
        pygame.mixer.music.unpause()

    def stop_music(self):
        if self.enabled:
            self.desired = None
            self.music_channel.stop()
            pygame.mixer.music.stop()

    def play(self, name):
        if self.enabled and not self.muted and name in self.sfx:
            self.sfx[name].play()

    def toggle_mute(self):
        if not self.enabled:
            return False
        self.muted = not self.muted
        if self.muted:
            self.music_channel.stop()
            pygame.mixer.music.stop()
            self.playing_external = False
        elif self.desired:
            self._start(self.desired)
        return self.muted
