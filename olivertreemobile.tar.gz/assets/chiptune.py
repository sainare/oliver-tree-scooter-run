




   



import os

import sys



import pygame



import songs



if sys.platform != "emscripten":                                                   

    import numpy as np



                                                                        

                                    

WEB = sys.platform == "emscripten"

BAKED_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "audio")



SR = 44100                                             

TARGET_RMS = 0.185                                                       

_NOTE = {"C": 0, "D": 2, "E": 4, "F": 5, "G": 7, "A": 9, "B": 11}





                                                                         

def note_to_midi(token):

                                             

    semi = _NOTE[token[0].upper()]

    i = 1

    if len(token) > 1 and token[1] in "#b":

        semi += 1 if token[1] == "#" else -1

        i = 2

    return 12 * (int(token[i:]) + 1) + semi





def midi_to_freq(m):

    return 440.0 * 2.0 ** ((m - 69) / 12.0)





def parse_pattern(pattern):

    


       

    events = []

    for tok in pattern.split():

        if tok == ".":

            if events:

                events[-1][1] += 1

            else:

                events.append([None, 1])

        elif tok == "-":

            if events and events[-1][0] is None:

                events[-1][1] += 1

            else:

                events.append([None, 1])

        else:

            events.append([note_to_midi(tok), 1])

    return events





                                                                         

def square(freq, n, duty=0.5):

    phase = (np.arange(n) * (freq / SR)) % 1.0

    return np.where(phase < duty, 1.0, -1.0)





def triangle(freq, n):

    phase = (np.arange(n) * (freq / SR)) % 1.0

    return 4.0 * np.abs(phase - 0.5) - 1.0





def envelope(n, a=0.004, d=0.06, s=0.65, r=0.05):

                                                  

    env = np.ones(n)

    na = min(int(a * SR), n)

    nd = min(int(d * SR), n - na)

    nr = min(int(r * SR), max(0, n - na - nd))

    pos = 0

    if na:

        env[:na] = np.linspace(0.0, 1.0, na)

        pos = na

    if nd:

        env[pos:pos + nd] = np.linspace(1.0, s, nd)

        pos += nd

    hold = n - pos - nr

    if hold > 0:

        env[pos:pos + hold] = s

        pos += hold

    if n - pos > 0:

        env[pos:] = np.linspace(s, 0.0, n - pos)

    return env





                                                                         

def render_tone_channel(pattern, step_samples, total, kind="square",

                        duty=0.5, vol=0.22, octave=0, detune=0.0):

    buf = np.zeros(total)

    pos = 0

    for midi, steps in parse_pattern(pattern):

        length = steps * step_samples

        if midi is not None and pos < total:

            n = min(length, total - pos)

            freq = midi_to_freq(midi + 12 * octave) * (2.0 ** (detune / 1200.0))

            wave = square(freq, n, duty) if kind == "square" else triangle(freq, n)

            buf[pos:pos + n] += wave * envelope(n) * vol

        pos += length

    return buf





def _kick(n):

    freq = np.linspace(160.0, 45.0, n)

    phase = np.cumsum(freq) / SR

    env = np.exp(-np.linspace(0.0, 9.0, n))

    return np.sin(2 * np.pi * phase) * env





def _snare(n, rng):

    env = np.exp(-np.linspace(0.0, 14.0, n))

    tone = np.sin(2 * np.pi * np.arange(n) * 190.0 / SR) * 0.35

    return (rng.uniform(-1.0, 1.0, n) * 0.8 + tone) * env





def _hat(n, rng):

    env = np.exp(-np.linspace(0.0, 45.0, n))

    noise = rng.uniform(-1.0, 1.0, n)

    noise[1:] -= noise[:-1] * 0.7                                           

    return noise * env





def render_drum_channel(pattern, step_samples, total, vol=0.34, seed=7):

    


       

    rng = np.random.default_rng(seed)

    buf = np.zeros(total)

    length = {"K": 0.14, "S": 0.16, "H": 0.05}

    for i, tok in enumerate(pattern.split()):

        pos = i * step_samples

        if pos >= total:

            break

        for ch in tok:

            if ch not in length:

                continue

            n = min(int(length[ch] * SR), total - pos)

            if ch == "K":

                sound = _kick(n)

            elif ch == "S":

                sound = _snare(n, rng)

            else:

                sound = _hat(n, rng) * 0.45

            buf[pos:pos + n] += sound * vol

    return buf





def mix(*parts):

                                                                  

    n = max(len(p) for p in parts)

    out = np.zeros(n)

    for p in parts:

        out[:len(p)] += p

    return out





def _to_sound(mono, gain=0.85):

    mono = np.clip(mono, -1.0, 1.0) * gain

    data = (mono * 32767.0).astype(np.int16)

    stereo = np.ascontiguousarray(np.column_stack((data, data)))

    return pygame.sndarray.make_sound(stereo)





def render_song(song):

                                                          

    step_samples = int(SR * 60.0 / song["bpm"] / 4.0)                  

    steps = max(len(song[k].split()) for k in ("lead", "bass", "drum")

                if k in song)

    total = steps * step_samples



    mix = np.zeros(total)

    mix += render_tone_channel(song["lead"], step_samples, total,

                               duty=song.get("lead_duty", 0.5),

                               vol=song.get("lead_vol", 0.20))

    if song.get("harm"):

        mix += render_tone_channel(song["harm"], step_samples, total,

                                   duty=song.get("harm_duty", 0.25),

                                   vol=song.get("harm_vol", 0.12),

                                   detune=song.get("harm_detune", 6.0))

    mix += render_tone_channel(song["bass"], step_samples, total,

                               kind="tri", vol=song.get("bass_vol", 0.30))

    mix += render_drum_channel(song["drum"], step_samples, total,

                               vol=song.get("drum_vol", 0.32))

                                                                      

    rms = float(np.sqrt(np.mean(mix ** 2)))

    peak = float(np.max(np.abs(mix)))

    if rms > 0.0:

        mix = mix * min(TARGET_RMS / rms, 0.92 / peak)

    return _to_sound(mix)





def sweep(f0, f1, dur, kind="square", duty=0.5, vol=0.3, curve=1.0):

    n = int(dur * SR)

    t = np.linspace(0.0, 1.0, n) ** curve

    freq = f0 + (f1 - f0) * t

    phase = np.cumsum(freq) / SR

    if kind == "square":

        wave = np.where((phase % 1.0) < duty, 1.0, -1.0)

    else:

        wave = np.sin(2 * np.pi * phase)

    return wave * envelope(n, a=0.002, d=dur * 0.3, s=0.55, r=dur * 0.45) * vol





def noise_burst(dur, vol=0.3, decay=12.0, seed=3):

    n = int(dur * SR)

    rng = np.random.default_rng(seed)

    return rng.uniform(-1.0, 1.0, n) * np.exp(-np.linspace(0, decay, n)) * vol





                                                                         

                                                                    

                                                                     

                                                                         

                                                    

 

                                                                      

                                                            

SONG_GAME = dict(

    bpm=174,

    scale={0, 2, 3, 5, 7, 8, 10},                    

                                                                    

                                                            

                                                                          

                                                                          

    lead_duty=0.5, lead_vol=0.22, bass_vol=0.26,

                                                                  

                                                                   

                                                                          

    lead=(

        "C5 . C5 Eb5 F5 . G5 . Bb5 . G5 F5 Eb5 . C5 . "

        "C5 . C5 Eb5 F5 . G5 . C6 . Bb5 G5 F5 . Eb5 . "

        "F5 . F5 G5 Bb5 . C6 . Eb6 . C6 Bb5 G5 . F5 . "

        "G5 . Bb5 . C6 . Bb5 G5 F5 . Eb5 C5 D5 . Eb5 . "

    ),

    harm=(

        "G4 . . . Eb4 . . . G4 . . . Bb4 . . . "

        "G4 . . . Eb4 . . . C5 . . . Bb4 . . . "

        "C5 . . . Ab4 . . . C5 . . . Eb5 . . . "

        "Bb4 . . . G4 . . . Bb4 . . . G4 . . . "

    ),

    bass=(

        "C2 . C3 . C2 . Eb2 . F2 . C2 . G2 . Bb2 . "

        "C2 . C3 . C2 . Eb2 . F2 . C2 . G2 . Bb2 . "

        "F2 . F3 . F2 . Ab2 . Bb2 . F2 . C3 . Eb3 . "

        "G2 . G3 . G2 . Bb2 . C3 . G2 . F2 . Eb2 . "

    ),

                                                                   

                                                         

    drum=(

        "KH - H - SH - H - KH - KH - SH - H - "

        "KH - H - SH - H - KH - KH - SH - H - "

        "KH - H - SH - H - KH - KH - SH - H - "

        "KH - H - SH - H - KH - KH - SH - S S "

    ),

)



                                                                      

                                                             

SONG_MENU = dict(

    bpm=96,

    scale={2, 4, 5, 7, 9, 11, 0},                        

    lead_duty=0.25, lead_vol=0.18,

    bass_vol=0.26, drum_vol=0.20,

    lead=(

        "D5 . F5 . . A5 . . G5 . F5 . . . . . "

        "B4 . D5 . . G5 . . F5 . D5 . . . . . "

        "A4 . C5 . . F5 . . E5 . D5 . . . . . "

        "C5 . E5 . . G5 . . A5 . G5 . E5 . . . "

    ),

    harm=(

        "A4 . . . . . . . F4 . . . . . . . "

        "G4 . . . . . . . B4 . . . . . . . "

        "F4 . . . . . . . A4 . . . . . . . "

        "E4 . . . . . . . C5 . . . . . . . "

    ),

    bass=(

        "D2 . . . A2 . . . D2 . . . F2 . E2 . "

        "G2 . . . D3 . . . G2 . . . B2 . A2 . "

        "D2 . . . A2 . . . D2 . . . C3 . A2 . "

        "C3 . . . G2 . . . C3 . . . E3 . A2 . "

    ),

    drum=(

        "KH - - H SH - - - KH - - H SH - - H "

        "KH - - H SH - - - KH - - H SH - - H "

        "KH - - H SH - - - KH - - H SH - - H "

        "KH - - H SH - - - KH - - H SH - S S "

    ),

)





                                                                          

SONG_MAIN = dict(

    bpm=118,

    scale={4, 6, 7, 9, 11, 0, 2},                    

    lead_duty=0.5, lead_vol=0.19, bass_vol=0.27, drum_vol=0.22,

    lead=(

        "E5 . . G5 . . B5 . . A5 . G5 . . . . "

        "E5 . . G5 . . A5 . B5 . . . D6 . B5 . "

        "C5 . . E5 . . G5 . . F5 . E5 . . . . "

        "C5 . . E5 . . G5 . A5 . . . G5 . E5 . "

        "B4 . . D5 . . G5 . . F#5 . D5 . . . . "

        "B4 . . D5 . . G5 . A5 . . . B5 . G5 . "

        "A4 . . D5 . . F#5 . . E5 . D5 . . . . "

        "A4 . D5 . F#5 . A5 . - . B5 . A5 . F#5 . "

    ),

    harm=("E4 G4 B4 G4 " * 8 + "C4 E4 G4 E4 " * 8

          + "G3 B3 D4 B3 " * 8 + "D4 F#4 A4 F#4 " * 8),

    bass=(

        "E2 . . . E3 . E2 . . . E3 . E2 . G2 . "

        "E2 . . . E3 . E2 . . . E3 . E2 . B2 . "

        "C2 . . . C3 . C2 . . . C3 . C2 . E2 . "

        "C2 . . . C3 . C2 . . . C3 . C2 . G2 . "

        "G2 . . . G3 . G2 . . . G3 . G2 . B2 . "

        "G2 . . . G3 . G2 . . . G3 . G2 . D3 . "

        "D2 . . . D3 . D2 . . . D3 . D2 . F#2 . "

        "D2 . . . D3 . D2 . . . A2 . B2 . C#3 . "

    ),

    drum=("KH - H - SH - H - KH - H K SH - H - " * 7

          + "KH - H - SH - H - KH - H K SH - S S "),

)





def make_riff(notes, vol=0.26):

                                                                             

    parts = []

    for i, name in enumerate(notes):

        f = midi_to_freq(note_to_midi(name))

        dur = 0.10 if i < len(notes) - 1 else 0.26

        n = int(dur * SR)

        wave = square(f, n, 0.25) * envelope(n, a=0.003, d=dur * 0.4,

                                            s=0.6, r=dur * 0.5) * vol

        parts.append(wave)

    return _to_sound(np.concatenate(parts))





                                                          

                                                                   

SONG_TITLE = dict(

    bpm=132,

    scale={9, 11, 0, 2, 4, 5, 7, 8},                             

    lead_duty=0.5, lead_vol=0.20, bass_vol=0.28, drum_vol=0.26,

    lead=(

        "A4 . . E5 . . A5 . C6 . . . B5 . . . "

        "F4 . . C5 . . F5 . A5 . . . G5 . . . "

        "G4 . . C5 . . E5 . G5 . . . E5 . . . "

        "E4 . . G#4 . . B4 . E5 . . . G#5 . B5 . "

    ),

    harm=(

        "C4 . . . . . . . E4 . . . . . . . "

        "A3 . . . . . . . C4 . . . . . . . "

        "E4 . . . . . . . G4 . . . . . . . "

        "B3 . . . . . . . G#4 . . . . . . . "

    ),

    bass=(

        "A2 . . . E2 . . . A2 . . . C3 . E3 . "

        "F2 . . . C3 . . . F2 . . . A2 . C3 . "

        "C3 . . . G2 . . . C3 . . . E3 . G3 . "

        "E2 . . . B2 . . . E3 . . . B2 . E2 . "

    ),

    drum=(

        "KH - H - SH - H - KH - H - SH - H - "

        "KH - H - SH - H - KH - H - SH - H - "

        "KH - H - SH - H - KH - H - SH - H - "

        "KH - H - SH - H - KH - H - SH - S S "

    ),

)



                                                                       

                                                                     

                                                                               

SONG_OVER = dict(

    bpm=60,

    scale={5, 7, 8, 10, 0, 1, 3},                    

    lead_duty=0.125, lead_vol=0.19, bass_vol=0.24, drum_vol=0.12,

    lead=(

        "Ab5 . . . . . G5 . F5 . . . . . . . "

        "G5 . . . . . F5 . Eb5 . . . . . . . "

        "F5 . . . . . Eb5 . Db5 . . . . . . . "

        "Eb5 . . . . . Db5 . C5 . . . . . . . "

    ),

    harm=(

        "C5 . . . . . . . . . . . . . . . "

        "Bb4 . . . . . . . . . . . . . . . "

        "Ab4 . . . . . . . . . . . . . . . "

        "G4 . . . . . . . Ab4 . . . . . . . "

    ),

    bass=(

        "F2 . . . . . . . F2 . . . . . . . "

        "Eb2 . . . . . . . Eb2 . . . . . . . "

        "Db2 . . . . . . . Db2 . . . . . . . "

        "C2 . . . . . . . C2 . . . . . . . "

    ),

    drum=(

        "K - - - - - - - - - - - - - - - "

        "K - - - - - - - - - - - - - - - "

        "K - - - - - - - - - - - - - - - "

        "K - - - - - - - H - - - - - - - "

    ),

)



def song_spec(name):

                                                                                     

    if name == "title":

        return SONG_TITLE

    if name == "over":

        return SONG_OVER

    return songs.spec(name)



EXTERNAL_NAMES = {"game": "soundtrack", "menu": "soundtrack_menu",

                  "title": "soundtrack_title", "over": "soundtrack_over"}

EXTERNAL_EXTS = (".ogg", ".mp3", ".wav", ".flac")





def find_external(folder):

    




       

    found = {}

    if not folder or not os.path.isdir(folder):

        return found

    for slot, stem in EXTERNAL_NAMES.items():

        for ext in EXTERNAL_EXTS:

            path = os.path.join(folder, stem + ext)

            if os.path.isfile(path):

                found[slot] = path

                break

    return found





class Audio:

                                                  



    def __init__(self, enabled=True, music_dir=None):

        self.enabled = enabled

        self.music_channel = None

        self.sfx = {}

        self.songs = {}

        self.muted = False

        self.desired = None

        self.external = {}

        self.playing_external = False

                                                                      

        self.music_dir = music_dir

        self.fade_left = 0                                                   

        self.fade_len = 1

        self.js = None                                                              

        self.music_vol = 1.0                                                  

        self.sfx_vol = 1.0

        self.level = 1.0                                               

        self.tapes = []

        self.tape_channel = None

        if not enabled:

            return

        self.external = {} if WEB else find_external(music_dir)

        self.tape_channel = pygame.mixer.Channel(1)

        pygame.mixer.set_num_channels(12)

        self.music_channel = pygame.mixer.Channel(0)

        if WEB:

            self.js = self._find_js_player()

            self._load_baked()

            return

        self.sfx["jump"] = _to_sound(sweep(240, 700, 0.13, duty=0.5, vol=0.30))

        self.sfx["jump2"] = _to_sound(sweep(420, 980, 0.12, duty=0.25, vol=0.28))

        self.sfx["pickup"] = _to_sound(

            np.concatenate([sweep(900, 900, 0.05, duty=0.5, vol=0.26),

                            sweep(1350, 1350, 0.09, duty=0.5, vol=0.26)]))

        self.sfx["hit"] = _to_sound(mix(

            noise_burst(0.18, vol=0.35),

            sweep(420, 80, 0.22, kind="sine", vol=0.30)))

        self.sfx["move"] = _to_sound(sweep(620, 620, 0.045, duty=0.25, vol=0.18))

        self.sfx["ramp"] = _to_sound(sweep(260, 1180, 0.26, duty=0.25,

                                           vol=0.28, curve=0.7))

        self.sfx["life"] = _to_sound(np.concatenate([               

            sweep(523, 523, 0.07, duty=0.5, vol=0.26),

            sweep(784, 784, 0.07, duty=0.5, vol=0.26),

            sweep(1046, 1046, 0.16, duty=0.5, vol=0.26)]))

        self.sfx["pause"] = _to_sound(np.concatenate([                         

            sweep(880, 880, 0.05, duty=0.25, vol=0.22),

            sweep(440, 440, 0.10, duty=0.25, vol=0.22)]))

        self.sfx["zone"] = _to_sound(np.concatenate([                    

            sweep(392, 392, 0.07, duty=0.5, vol=0.24),

            sweep(523, 523, 0.07, duty=0.5, vol=0.24),

            sweep(659, 659, 0.07, duty=0.5, vol=0.24),

            sweep(784, 1046, 0.20, duty=0.25, vol=0.24)]))

        self.sfx["trick"] = _to_sound(sweep(300, 900, 0.10, duty=0.125,

                                            vol=0.22))

        self.sfx["star"] = _to_sound(np.concatenate([                      

            sweep(f, f, 0.06, duty=0.5, vol=0.28)

            for f in (523, 622, 784, 932, 1047, 1245)]))

        self.sfx["flip"] = _to_sound(np.concatenate([                           

            sweep(f, f, 0.055, duty=0.25, vol=0.26)

            for f in (523, 659, 784, 1047, 1319)]))

        self.sfx["select"] = _to_sound(

            np.concatenate([sweep(620, 620, 0.05, duty=0.5, vol=0.24),

                            sweep(930, 930, 0.11, duty=0.5, vol=0.24)]))

        self.sfx["over"] = _to_sound(np.concatenate([

            sweep(520, 520, 0.16, duty=0.5, vol=0.28),

            sweep(415, 415, 0.16, duty=0.5, vol=0.28),

            sweep(330, 330, 0.16, duty=0.5, vol=0.28),

            sweep(262, 200, 0.45, duty=0.5, vol=0.28),

        ]))



    @staticmethod

    def _find_js_player():

                                                                               

        try:

            import platform

            player = platform.window.otMusic

            return player if player else None

        except Exception:

            return None



    def bg_resume(self):

                                                                                  

        if self.js is not None:

            try:

                self.js.bgResume()

            except Exception:

                self._js_fail()



    def _js_fail(self):

        self.js = None                                                           



    def preload(self, name):

                                                                                     

        if self.js is not None:

            try:

                self.js.preload(name)

            except Exception:

                self._js_fail()



    def _load_baked(self):

                                                                 

        for name in os.listdir(BAKED_DIR):

            stem, ext = os.path.splitext(name)

            if ext != ".ogg":

                continue

            kind, _, key = stem.partition("_")

            if kind == "song":

                                                                                

                                                                       

                self.external[key] = os.path.join(BAKED_DIR, name)

            elif kind == "sfx":

                self.sfx[key] = pygame.mixer.Sound(

                    os.path.join(BAKED_DIR, name))



    def load_tapes(self, tapes):

                                                                         

        self.tapes = []

        if not self.enabled:

            return

        if WEB:

            self.tapes = [pygame.mixer.Sound(os.path.join(

                BAKED_DIR, "tape_" + t["slug"] + ".ogg")) for t in tapes]

            return

        for tape in tapes:

            sound = None

            if self.music_dir and os.path.isdir(self.music_dir):

                for ext in EXTERNAL_EXTS:

                    path = os.path.join(self.music_dir,

                                        "tape_" + tape["slug"] + ext)

                    if os.path.isfile(path):

                        try:

                            sound = pygame.mixer.Sound(path)

                        except pygame.error:

                            sound = None                                       

                        break

            self.tapes.append(sound or make_riff(tape["riff"]))



    def play_tape(self, index):

                                                                        

        if not self.enabled or self.muted or not self.tapes:

            return

        self.tape_channel.stop()

        snd = self.tapes[index % len(self.tapes)]

        snd.set_volume(self.sfx_vol)

        self.tape_channel.play(snd)



    def _set_music_volume(self, v):

        if not self.enabled:

            return

        self.level = v

        if self.js is not None:

            try:

                self.js.volume(v * self.music_vol)

            except Exception:

                self._js_fail()

            return

        self.music_channel.set_volume(v * self.music_vol)

        pygame.mixer.music.set_volume(v * self.music_vol)



    def set_levels(self, music, sfx):

                                                                                   

        self.music_vol = max(0.0, min(1.0, music))

        self.sfx_vol = max(0.0, min(1.0, sfx))

        self._set_music_volume(self.level)



    def fade_in(self, frames):

                                                                 

        if not self.enabled:

            return

        self.fade_len = self.fade_left = max(1, int(frames))

        self._set_music_volume(0.0)



    def tick(self):

                                                                  

        if self.fade_left > 0:

            self.fade_left -= 1

            k = 1.0 - self.fade_left / self.fade_len

            self._set_music_volume(k * k * (3.0 - 2.0 * k))



    def _start(self, name):

                                                                        

        self.fade_left = 0

        self._set_music_volume(1.0)

                                                                        

                                                                      

        self.music_channel.unpause()

        pygame.mixer.music.unpause()

        self.music_channel.stop()

        pygame.mixer.music.stop()

        self.playing_external = False

        if self.js is not None:                                                 

            try:

                                                                           

                                                                       

                self.js.resume()

                self.js.play(name)

                self.playing_external = True

                self._set_music_volume(self.level)

                return

            except Exception:

                self._js_fail()

        path = self.external.get(name)

        if path:

            try:

                pygame.mixer.music.load(path)

                pygame.mixer.music.play(-1)

                self.playing_external = True

                                                                       

                self._set_music_volume(self.level)

                return

            except pygame.error as e:

                pass                                                         

        snd = self._song(name)

        if snd is not None:

            self.music_channel.play(snd, loops=-1)



    def _song(self, name):

                                                                           

        snd = self.songs.get(name)

        if snd is None and not WEB:

            spec = song_spec(name)

            if spec is not None:

                snd = self.songs[name] = render_song(spec)

        return snd



    def play_music(self, name):

                                                                          

        if not self.enabled or self.desired == name:

            return

        self.desired = name

        if not self.muted:

            self._start(name)



    def pause_music(self):

                                                              

        if not self.enabled:

            return

        if self.js is not None:

            try:

                self.js.pause()

            except Exception:

                self._js_fail()

        self.music_channel.pause()

        pygame.mixer.music.pause()



    def resume_music(self):

        if not self.enabled or self.muted:

            return

        if self.js is not None:

            try:

                self.js.resume()

            except Exception:

                self._js_fail()

        self.music_channel.unpause()

        pygame.mixer.music.unpause()



    def stop_music(self):

        if self.enabled:

            self.desired = None

            if self.js is not None:

                try:

                    self.js.stop()

                except Exception:

                    self._js_fail()

            self.music_channel.stop()

            pygame.mixer.music.stop()



    def play(self, name):

        if self.enabled and not self.muted and name in self.sfx:

            snd = self.sfx[name]

            snd.set_volume(self.sfx_vol)

            snd.play()



    def toggle_mute(self):

        if not self.enabled:

            return False

        self.muted = not self.muted

        if self.muted:

            if self.js is not None:

                try:

                    self.js.stop()

                except Exception:

                    self._js_fail()

            self.music_channel.stop()

            pygame.mixer.music.stop()

            self.playing_external = False

        elif self.desired:

            self._start(self.desired)

        return self.muted

