



   

import os

import sys



os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))



import numpy as np

import pygame

import soundfile as sf



import chiptune as ch

from settings import TAPES



OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "audio")

                                                                             

MUSIC_OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..",

                         "OliverTreeMusic")





def raw(mono, gain=0.85):

    return (np.clip(mono, -1.0, 1.0) * gain).astype(np.float32)





def write_ogg(path, data):

    
                                                                       

    rng = np.random.default_rng(1)

    data = data + rng.uniform(-1e-4, 1e-4, len(data)).astype(np.float32)

    with sf.SoundFile(path, "w", ch.SR, 1, format="OGG",

                      subtype="VORBIS") as f:

        for i in range(0, len(data), 4096):

            f.write(data[i:i + 4096])





def main():

    pygame.mixer.pre_init(44100, -16, 2, 512)

    pygame.init()

    pygame.mixer.init()

    ch._to_sound = raw                                                        

    audio = ch.Audio(enabled=True, music_dir=None)

    audio.load_tapes(TAPES)

    os.makedirs(OUT, exist_ok=True)

                                                                           

    jobs = {}

    jobs.update({"sfx_" + k: v for k, v in audio.sfx.items()})

    jobs.update({"tape_" + t["slug"]: audio.tapes[i]

                 for i, t in enumerate(TAPES)})

    total = 0

    os.makedirs(MUSIC_OUT, exist_ok=True)

    for name, data in jobs.items():

        folder = MUSIC_OUT if name.startswith("song_") else OUT

        path = os.path.join(folder, name + ".ogg")

        write_ogg(path, data)

        total += os.path.getsize(path)

        print(f"{name:22s} {os.path.getsize(path) / 1024:7.0f} КБ")

    print(f"итого {total / 1024 / 1024:.1f} МБ")





if __name__ == "__main__":

    main()

