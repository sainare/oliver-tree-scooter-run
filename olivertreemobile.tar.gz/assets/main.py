"""OLIVER TREE — 8-BIT SCOOTER RUN.

Раннер на самокате в духе 8-битной консоли: выбираешь персонажа,
едешь по сцене концерта и прыгаешь через препятствия.

Управление:
    <- ->        выбор персонажа
    ENTER        подтвердить / рестарт
    ПРОБЕЛ / UP  прыжок (у Рикерсона — двойной)
    <- -> / DOWN трюки в воздухе
    P / ESC      пауза
    M            выключить звук
    F11          полный экран
"""

import asyncio
import json
import math
import os
import random
import sys

import pygame

import sprites as sp
import world as wd
from chiptune import Audio
from settings import (CANVAS_W, CANVAS_H, WIN_W, WIN_H, FPS,
                      RESUME_FRAMES,
                      CHARACTERS, GROUND_Y, C_WHITE, C_BLACK, C_YELLOW,
                      C_GREEN, C_RED, C_ROAD, C_ROAD_HI, C_STAR,
                      C_UI_BOX, C_UI_BOX_SEL, C_UI_EDGE, TAPES, BOOST_FRAMES, ZONES)

WEB = sys.platform == "emscripten"      # игра запущена в браузере (pygbag)
if WEB:
    import platform

MENU_COLS = 3
# плитки меню: одна геометрия и для отрисовки, и для касаний
TILE_W, TILE_H, TILE_GX, TILE_GY, TILE_Y0 = 36, 36, 12, 13, 20

# логический размер окна в браузере и кнопки на нём: (центр x, центр y, радиус)
WEB_SIZE = {"landscape": (640, 360), "portrait": (360, 640)}
BUTTONS = {
    "landscape": {"jump": (555, 282, 62), "trick": (92, 300, 46),
                  "super": (198, 306, 38), "pause": (610, 98, 22)},
    "portrait": {"jump": (262, 460, 84), "trick": (86, 430, 62),
                 "super": (110, 566, 46), "pause": (180, 246, 26)},
}
# кнопки-плашки на самом канвасе (координаты канваса 320x180)
MENU_START = pygame.Rect(96, 146, 128, 22)
PAUSE_RESUME = pygame.Rect(80, 88, 160, 22)
PAUSE_SOUND = pygame.Rect(80, 114, 160, 22)
PAUSE_MENU = pygame.Rect(80, 140, 160, 22)
OVER_AGAIN = pygame.Rect(40, 76, 108, 22)
OVER_MENU = pygame.Rect(172, 76, 108, 22)
BACKGROUND_EVENTS = tuple(getattr(pygame, n) for n in
                          ("WINDOWFOCUSLOST", "WINDOWMINIMIZED", "WINDOWHIDDEN")
                          if hasattr(pygame, n))
BUTTON_LABEL = {"jump": "ПРЫЖОК", "trick": "ТРЮК", "super": "СУПЕР",
                "pause": "II"}

# редкие звёзды на титульном экране — фиксированные, чтобы не мельтешили
_rng = random.Random(451)
TITLE_STARS = [(_rng.randrange(CANVAS_W), _rng.randrange(4, 96))
               for _ in range(34)]

# пепел на экране проигрыша: x, скорость, фаза, длина пути
ASHES = [(_rng.randrange(CANVAS_W), _rng.uniform(0.25, 0.75),
          _rng.randrange(200), _rng.randint(90, 150)) for _ in range(22)]

STATE_TITLE, STATE_MENU, STATE_PLAY, STATE_PAUSE, STATE_OVER = range(5)
JUMP_KEYS = (pygame.K_SPACE, pygame.K_UP, pygame.K_w)
DUCK_KEYS = (pygame.K_DOWN, pygame.K_s)
TRICK_KEYS = (pygame.K_LEFT, pygame.K_RIGHT, pygame.K_a, pygame.K_d)


def _phase(age, start, dur):
    """Насколько продвинулась фаза анимации: 0 до старта, 1 после.

    Внутри — с замедлением к концу, чтобы движение не обрывалось резко.
    """
    if age <= start:
        return 0.0
    if age >= start + dur:
        return 1.0
    t = (age - start) / dur
    return 1.0 - (1.0 - t) ** 2


def data_dir():
    """Куда класть файл рекордов (рядом с exe или со скриптом)."""
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


class App:
    def __init__(self, sound=True):
        self.canvas = pygame.Surface((CANVAS_W, CANVAS_H))
        self.screen = None
        self.fullscreen = False
        self.font_big = pygame.font.Font(None, 30)
        self.font = pygame.font.Font(None, 17)
        self.font_small = pygame.font.Font(None, 14)
        self.touch_ui = WEB                # экранные кнопки и подсказки
        self.orient = "landscape"
        self.pointers = {}                 # id касания -> (x, y) на экране
        self.finger_seen = False
        self.jump_ptr = None               # чем зажат прыжок
        self.btn_cache = {}
        self.view = (0.0, 0.0, 1.0)        # сдвиг x, y и масштаб канваса
        self.audio = Audio(enabled=sound, music_dir=data_dir())
        self.art = self._load_art()
        self.scores = self._load_scores()
        self.state = STATE_TITLE
        self.sel = 0
        self.world = None
        self.t = 0
        self.over_t = 0
        self.resume_t = 0
        self.running = True
        self.audio.play_music("title")

    # --- ресурсы ---
    def _load_art(self):
        zones = [wd.make_background(pal) for pal in ZONES]
        art = {
            "zones": zones,
            "menu_bg": wd.make_menu_backdrop(),
            "sky": zones[0]["sky"],          # для титульника
            "clouds": zones[0]["clouds"],
            "city": zones[0]["city"],
            "font": self.font_small,
            "riders": {c["key"]: sp.make_rider_set(c) for c in CHARACTERS},
            "portraits": {c["key"]: sp.make_portrait(c) for c in CHARACTERS},
            "faces": {c["key"]: sp.make_face(c) for c in CHARACTERS},
            "sitting": {c["key"]: sp.make_sitting(c) for c in CHARACTERS},
            "obstacles": {
                "cone": sp.make_cone(),
                "hydrant": sp.make_hydrant(),
                "pothole": sp.make_pothole(),
                "sign": sp.make_sign(),
                "dumpster": sp.make_dumpster(),
                "spikeball": sp.make_spikeball(),
                "van": sp.make_van(),
                "ramp": sp.make_ramp(),
            },
            "tapes": [sp.make_cassette(t["label"]) for t in TAPES],
            "star": sp.make_star(),
            "life": sp.scaled(sp.make_heart(True), 2),
            "balloons": sp.make_balloons(),
            "heart": sp.make_heart(True),
            "heart_off": sp.make_heart(False),
        }
        art["tape"] = art["tapes"][0]          # иконка для счётчика в HUD
        self.audio.load_tapes(TAPES)
        return art

    def _score_path(self):
        return os.path.join(data_dir(), "highscores.json")

    def _load_scores(self):
        try:
            if WEB:
                raw = platform.window.localStorage.getItem("oliver_scores")
                data = json.loads(str(raw)) if raw else {}
            else:
                with open(self._score_path(), encoding="utf-8") as f:
                    data = json.load(f)
            return {k: int(v) for k, v in data.items()}
        except Exception:
            return {}

    def _save_scores(self):
        try:
            if WEB:
                platform.window.localStorage.setItem(
                    "oliver_scores", json.dumps(self.scores))
                return
            with open(self._score_path(), "w", encoding="utf-8") as f:
                json.dump(self.scores, f, ensure_ascii=False, indent=1)
        except Exception:
            pass                     # рекорд не сохранился — не повод падать

    # --- текст ---
    def text(self, surf, msg, x, y, color=C_WHITE, font=None, center=False,
             shadow=True):
        """Текст с полной обводкой по контуру.

        Одной тени со смещением не хватало: на пёстром фоне буквы
        сливались с картинкой той стороной, где тени нет.
        """
        font = font or self.font
        img = font.render(msg, False, color)      # без сглаживания — пиксельно
        rect = img.get_rect()
        if center:
            rect.midtop = (x, y)
        else:
            rect.topleft = (x, y)
        if shadow:
            back = font.render(msg, False, C_BLACK)
            for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1),
                           (-1, -1), (1, -1), (-1, 1), (1, 1)):
                surf.blit(back, (rect.x + dx, rect.y + dy))
        surf.blit(img, rect)
        return rect

    def wrap(self, msg, font, width):
        """Разбить строку по словам так, чтобы влезала в заданную ширину."""
        words, lines, cur = msg.split(), [], ""
        for word in words:
            probe = (cur + " " + word).strip()
            if cur and font.size(probe)[0] > width:
                lines.append(cur)
                cur = word
            else:
                cur = probe
        if cur:
            lines.append(cur)
        return lines

    # --- действия: одни и те же для клавиш и касаний ---
    def act_jump(self):
        self.world.jump()

    def act_trick(self):
        rider = self.world.rider
        if rider.on_ground:                     # на земле — вращение
            rider.start_ground_trick(self.audio)
        else:
            rider.start_trick("tailwhip", self.audio)

    def act_super(self):
        self.world.rider.start_trick("superman", self.audio)

    def act_pause(self):
        self.state = STATE_PAUSE
        self.audio.play("pause")
        self.audio.pause_music()           # на паузе музыка молчит

    def act_resume(self):
        self.state = STATE_PLAY
        self.resume_t = RESUME_FRAMES        # обратный отсчёт
        self.audio.play("pause")
        self.audio.resume_music()

    def act_menu_pick(self, index):
        """Тап по плитке: сначала выбор, повторный тап — старт."""
        if index == self.sel:
            self.audio.play("select")
            self.start_game(self.sel)
        else:
            self.sel = index
            self.audio.play("move")

    # --- события ---
    def handle_event(self, ev):
        if ev.type == pygame.QUIT:
            self.running = False
            return
        if ev.type == pygame.VIDEORESIZE and not self.fullscreen and not WEB:
            self.screen = pygame.display.set_mode((max(ev.w, CANVAS_W),
                                                   max(ev.h, CANVAS_H)),
                                                  pygame.RESIZABLE)
            return
        if ev.type in BACKGROUND_EVENTS:
            self.on_background()               # звонок или свёрнутая вкладка
            return
        if self._pointer_event(ev):
            return
        if ev.type != pygame.KEYDOWN and ev.type != pygame.KEYUP:
            return

        if ev.type == pygame.KEYDOWN:
            if ev.key == pygame.K_F11 and not WEB:
                self.toggle_fullscreen()
                return
            if ev.key == pygame.K_m:
                self.audio.toggle_mute()
                return

        if self.state == STATE_TITLE:
            if ev.type == pygame.KEYDOWN:
                if ev.key == pygame.K_ESCAPE:
                    self.running = False
                else:                            # любая клавиша — это START
                    self.to_select()
        elif self.state == STATE_MENU:
            self._event_menu(ev)
        elif self.state == STATE_PLAY:
            self._event_play(ev)
        elif self.state == STATE_PAUSE:
            if ev.type == pygame.KEYDOWN and ev.key in (pygame.K_p,
                                                        pygame.K_ESCAPE):
                self.act_resume()
            elif ev.type == pygame.KEYDOWN and ev.key == pygame.K_q:
                self.to_menu()
        elif self.state == STATE_OVER:
            if ev.type == pygame.KEYDOWN:
                if ev.key in (pygame.K_RETURN, pygame.K_KP_ENTER,
                              pygame.K_SPACE):
                    self.start_game(self.sel)
                elif ev.key in (pygame.K_ESCAPE, pygame.K_q):
                    self.to_menu()

    def on_background(self):
        """Вкладку свернули — играющий забег встаёт на паузу."""
        if self.state == STATE_PLAY:
            self.act_pause()

    def to_select(self):
        self.audio.play("select")
        self.state = STATE_MENU
        self.audio.play_music("menu")

    def _event_menu(self, ev):
        if ev.type != pygame.KEYDOWN:
            return
        n = len(CHARACTERS)
        if ev.key in (pygame.K_LEFT, pygame.K_a):
            self.sel = (self.sel - 1) % n
            self.audio.play("move")
        elif ev.key in (pygame.K_RIGHT, pygame.K_d):
            self.sel = (self.sel + 1) % n
            self.audio.play("move")
        elif ev.key in (pygame.K_UP, pygame.K_w):
            self.sel = (self.sel - MENU_COLS) % n
            self.audio.play("move")
        elif ev.key in (pygame.K_DOWN, pygame.K_s):
            self.sel = (self.sel + MENU_COLS) % n
            self.audio.play("move")
        elif ev.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
            self.audio.play("select")
            self.start_game(self.sel)
        elif ev.key == pygame.K_ESCAPE:
            self.running = False

    def _event_play(self, ev):
        rider = self.world.rider
        if ev.type == pygame.KEYDOWN:
            if ev.key in JUMP_KEYS:
                self.act_jump()
            elif ev.key in TRICK_KEYS:
                self.act_trick()
            elif ev.key in DUCK_KEYS:            # трюк, приседания больше нет
                self.act_super()
            elif ev.key in (pygame.K_p, pygame.K_ESCAPE):
                self.act_pause()
        elif ev.key in JUMP_KEYS:
            rider.release_jump()

    # --- касания и мышь ---
    def _pointer_event(self, ev):
        """Свести палец и мышь к «нажал / отпустил». True — событие съедено."""
        t = ev.type
        if t in (pygame.FINGERDOWN, pygame.FINGERUP):
            self.finger_seen = True
            self.touch_ui = True
            sw, sh = self.screen.get_size()
            pos = (ev.x * sw, ev.y * sh)
            pid = ("f", ev.finger_id)
        elif t in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP):
            if ev.button != 1:
                return False
            # браузер дублирует касание мышью: пальцы уже учтены отдельно
            if self.finger_seen and getattr(ev, "touch", False):
                return True
            pos = ev.pos
            pid = "m"
        elif t == pygame.FINGERMOTION:
            return True
        else:
            return False
        if t in (pygame.FINGERDOWN, pygame.MOUSEBUTTONDOWN):
            self.pointers[pid] = pos
            self.on_press(pid, pos)
        else:
            self.pointers.pop(pid, None)
            self.on_release(pid, pos)
        return True

    def to_canvas(self, pos):
        ox, oy, k = self.view
        return ((pos[0] - ox) / k, (pos[1] - oy) / k)

    def button_at(self, pos):
        if not self.touch_ui:
            return None
        best, best_d = None, 1e9
        for name, (cx, cy, r) in BUTTONS[self.orient].items():
            d = math.hypot(pos[0] - cx, pos[1] - cy)
            if d <= r + 14 and d < best_d:            # с запасом под палец
                best, best_d = name, d
        return best

    def on_press(self, pid, pos):
        cx, cy = self.to_canvas(pos)
        if self.state == STATE_TITLE:
            self.to_select()
        elif self.state == STATE_MENU:
            for i, box in enumerate(self.menu_tiles()):
                if box.inflate(6, 6).collidepoint(cx, cy):
                    self.act_menu_pick(i)
                    return
            if MENU_START.collidepoint(cx, cy):
                self.audio.play("select")
                self.start_game(self.sel)
        elif self.state == STATE_PLAY:
            if self.resume_t > 0:
                return
            name = self.button_at(pos)
            if name == "jump":
                self.jump_ptr = pid
                self.act_jump()
            elif name == "trick":
                self.act_trick()
            elif name == "super":
                self.act_super()
            elif name == "pause":
                self.act_pause()
        elif self.state == STATE_PAUSE:
            if PAUSE_RESUME.collidepoint(cx, cy):
                self.act_resume()
            elif PAUSE_SOUND.collidepoint(cx, cy):
                self.audio.toggle_mute()
            elif PAUSE_MENU.collidepoint(cx, cy):
                self.to_menu()
        elif self.state == STATE_OVER:
            if self.over_t > 194:
                if OVER_AGAIN.collidepoint(cx, cy):
                    self.start_game(self.sel)
                elif OVER_MENU.collidepoint(cx, cy):
                    self.to_menu()

    def on_release(self, pid, pos):
        if pid == self.jump_ptr:
            self.jump_ptr = None
            if self.state == STATE_PLAY and self.world:
                self.world.rider.release_jump()

    def menu_tiles(self):
        cols = MENU_COLS
        x0 = (CANVAS_W - (cols * TILE_W + (cols - 1) * TILE_GX)) // 2
        return [pygame.Rect(x0 + (i % cols) * (TILE_W + TILE_GX),
                            TILE_Y0 + (i // cols) * (TILE_H + TILE_GY),
                            TILE_W, TILE_H)
                for i in range(len(CHARACTERS))]

    # --- переходы ---
    def start_game(self, index):
        char = CHARACTERS[index]
        best = self.scores.get(char["key"], 0)
        self.world = wd.World(char, self.art, self.audio, best=best)
        self.state = STATE_PLAY
        self.resume_t = 0
        self.jump_ptr = None
        self.audio.play_music("game")

    def to_menu(self):
        self.state = STATE_MENU
        self.world = None
        self.resume_t = 0          # иначе новый забег стартует замороженным
        self.jump_ptr = None
        self.audio.play_music("menu")

    def toggle_fullscreen(self):
        self.fullscreen = not self.fullscreen
        if self.fullscreen:
            self.screen = pygame.display.set_mode(
                (0, 0), pygame.FULLSCREEN | pygame.SCALED)
        else:
            self.screen = pygame.display.set_mode(
                (WIN_W, WIN_H), pygame.RESIZABLE)

    # --- логика ---
    def update(self):
        self.t += 1
        if self.state == STATE_OVER:
            self.over_t += 1
        if self.state != STATE_PLAY:
            return
        if self.resume_t > 0:            # после паузы даём собраться
            self.resume_t -= 1
            return
        w = self.world
        w.update()
        if w.rider.dead and w.speed <= 0.01:
            key = w.rider.char["key"]
            if w.score > self.scores.get(key, 0):
                self.scores[key] = w.score
                self._save_scores()
            self.state = STATE_OVER
            self.over_t = 0
            self.audio.play_music("over")        # печальный трек на проигрыш

    # --- отрисовка ---
    def draw(self):
        c = self.canvas
        if self.state == STATE_TITLE:
            self._draw_title(c)
        elif self.state == STATE_MENU:
            self._draw_menu(c)
        else:
            self.world.draw(c)
            self._draw_hud(c)
            if self.state == STATE_PAUSE:
                self._draw_pause(c)
            elif self.state == STATE_OVER:
                self._draw_over(c)
            elif self.resume_t > 0:
                self._draw_resume(c)

    def _dim(self, surf, alpha=170):
        veil = pygame.Surface((CANVAS_W, CANVAS_H), pygame.SRCALPHA)
        veil.fill((10, 5, 18, alpha))
        surf.blit(veil, (0, 0))

    def _draw_title(self, c):
        """Титульный экран: логотип, огонь по низу и мигающее PRESS START."""
        for y in range(CANVAS_H):                 # тёмное небо с градиентом
            t = y / CANVAS_H
            c.fill((int(18 + 40 * t), int(10 + 14 * t), int(38 + 30 * t)),
                   pygame.Rect(0, y, CANVAS_W, 1))
        for i, (sx, sy) in enumerate(TITLE_STARS):
            if (self.t // 10 + i) % 5:
                c.fill(C_WHITE, pygame.Rect(sx, sy, 1, 1))

        wobble = int(math.sin(self.t * 0.07) * 2)
        self.text(c, "OLIVER TREE", CANVAS_W // 2, 22 + wobble, C_YELLOW,
                  self.font_big, center=True)
        self.text(c, "8-BIT SCOOTER RUN", CANVAS_W // 2, 46, C_STAR,
                  self.font, center=True)

        rider = self.art["riders"][CHARACTERS[self.sel]["key"]]["run"]
        img = rider[(self.t // 6) % 4]
        rx = (self.t * 1.6) % (CANVAS_W + 60) - 40
        c.blit(img, (int(rx), 104 - img.get_height() + 4))

        wd.draw_flames(c, self.t, CANVAS_H - 6, 34)

        if (self.t // 18) % 2 == 0:
            self.text(c, "PRESS START", CANVAS_W // 2, 78, C_WHITE,
                      self.font_big, center=True)
        hint = ("КОСНИСЬ ЭКРАНА" if self.touch_ui
                else "ЛЮБАЯ КЛАВИША   ESC - ВЫХОД")
        self.text(c, hint, CANVAS_W // 2, 122,
                  C_WHITE, self.font_small, center=True)

    def _draw_menu(self, c):
        """Экран выбора: сетка плиток с лицами, как на экране шоу."""
        c.blit(self.art["menu_bg"], (0, 0))
        wd.draw_spotlights(c, self.t)

        self.text(c, "ВЫБЕРИ ПЕРСОНАЖА", CANVAS_W // 2, 1, C_WHITE,
                  self.font_big, center=True)

        cols = MENU_COLS
        bw, bh = 36, 36
        gx, gy = 12, 13                       # по вертикали — место под имя
        x0 = (CANVAS_W - (cols * bw + (cols - 1) * gx)) // 2
        y0 = 20

        for i, ch in enumerate(CHARACTERS):
            bx = x0 + (i % cols) * (bw + gx)
            by = y0 + (i // cols) * (bh + gy)
            picked = (i == self.sel)
            box = pygame.Rect(bx, by, bw, bh)
            c.fill(C_UI_EDGE, box.inflate(4, 4))
            c.fill(C_UI_BOX_SEL if picked else C_UI_BOX, box)
            face = self.art["faces"][ch["key"]]
            c.blit(face, (bx + (bw - face.get_width()) // 2, by + 5))
            if picked and (self.t // 8) % 2 == 0:
                pygame.draw.rect(c, C_YELLOW, box.inflate(8, 8), 2)
            self.text(c, ch.get("short", ch["name"]), bx + bw // 2,
                      by + bh + 2, C_YELLOW if picked else C_WHITE,
                      self.font_small, center=True)

        # ниже сетки места мало, поэтому имя и рекорд идут одной строкой
        ch = CHARACTERS[self.sel]
        y = 120
        for line in self.wrap(ch["note"], self.font_small, CANVAS_W - 16):
            self.text(c, line, CANVAS_W // 2, y, C_WHITE,
                      self.font_small, center=True)
            y += 11
        best = self.scores.get(ch["key"], 0)
        self.text(c, f'{ch["name"]}   РЕКОРД {best}', CANVAS_W // 2, y + 2,
                  C_STAR, self.font_small, center=True)
        if self.touch_ui:
            self.plate(c, MENU_START, "СТАРТ", C_YELLOW)
            self.text(c, "ТАП ПО ПЕРСОНАЖУ - ВЫБОР, ЕЩЁ ТАП - СТАРТ",
                      CANVAS_W // 2, 170, C_WHITE, self.font_small,
                      center=True)
        else:
            if (self.t // 20) % 2 == 0:
                self.text(c, "PRESS START", CANVAS_W // 2, 154, C_WHITE,
                          self.font, center=True)
            self.text(c, "СТРЕЛКИ - ВЫБОР    ENTER - СТАРТ",
                      CANVAS_W // 2, 168, C_WHITE, self.font_small,
                      center=True)

    def _draw_resume(self, c):
        """Обратный отсчёт после паузы, чтобы не влететь в препятствие."""
        left = self.resume_t // FPS + 1
        self._dim(c, 90)
        step = self.resume_t % FPS                 # цифра «вдыхает» каждую сек.
        color = C_STAR if step > FPS // 2 else C_WHITE
        self.text(c, str(left), CANVAS_W // 2, 56, color,
                  self.font_big, center=True)
        self.text(c, "ПРИГОТОВЬСЯ", CANVAS_W // 2, 88, C_WHITE,
                  self.font, center=True)

    def _draw_hud(self, c):
        w = self.world
        for i in range(3):
            img = self.art["heart"] if i < w.rider.lives else self.art["heart_off"]
            c.blit(img, (6 + i * 12, 6))
        self.text(c, f"{w.score:06d}", CANVAS_W - 6 - 44, 5, C_WHITE)
        c.blit(self.art["tape"], (CANVAS_W // 2 - 18, 5))
        self.text(c, f"x{w.tapes}", CANVAS_W // 2 - 2, 6, C_YELLOW)
        if w.best:
            self.text(c, f"BEST {w.best}", CANVAS_W - 6 - 44, 18,
                      (188, 176, 210), self.font_small)
        if w.rider.boost > 0:                 # обратный отсчёт неуязвимости
            left = w.rider.boost / BOOST_FRAMES
            c.blit(self.art["star"], (6, 18))
            c.fill(C_BLACK, pygame.Rect(18, 21, 42, 5))
            c.fill(C_STAR, pygame.Rect(19, 22, int(40 * left), 3))
            self.text(c, f"{w.rider.boost // 60 + 1}", 63, 18, C_STAR,
                      self.font_small)
        elif self.audio.muted:
            self.text(c, "MUTE", 6, 20, (200, 120, 120), self.font_small)

    def _draw_pause(self, c):
        self._dim(c)
        self.text(c, "ПАУЗА", CANVAS_W // 2, 56 if self.touch_ui else 66,
                  C_YELLOW, self.font_big, center=True)
        if self.touch_ui:
            self.plate(c, PAUSE_RESUME, "ПРОДОЛЖИТЬ", C_YELLOW)
            self.plate(c, PAUSE_SOUND,
                       "ЗВУК: ВЫКЛ" if self.audio.muted else "ЗВУК: ВКЛ",
                       C_WHITE)
            self.plate(c, PAUSE_MENU, "В МЕНЮ", C_WHITE)
            return
        self.text(c, "P - ПРОДОЛЖИТЬ", CANVAS_W // 2, 98, C_WHITE,
                  self.font, center=True)
        self.text(c, "Q - В МЕНЮ", CANVAS_W // 2, 114, (190, 180, 210),
                  self.font_small, center=True)

    def _draw_over(self, c):
        """Финал ставится по фазам, а не проявляется целиком из черноты.

        Огонь расходится от центра -> проступает силуэт -> по одной падают
        буквы -> накручивается счёт -> всплывают итоги и шары.
        """
        w = self.world
        age = self.over_t
        cx = CANVAS_W // 2
        ground = 174
        c.fill((6, 5, 10))

        # 1. огонь занимается в центре и расходится к краям
        lit = _phase(age, 0, 52)
        if lit > 0:
            half = int((cx + 26) * lit)
            wd.draw_fire_glow(c, self.t, cx, CANVAS_H - 40)
            keep = c.get_clip()
            c.set_clip(pygame.Rect(cx - half, 0, half * 2, CANVAS_H))
            dying = max(0.55, 1.0 - max(0, age - 200) / 1100.0)
            wd.draw_flames(c, self.t, CANVAS_H - 2, int(72 * dying * lit))
            c.set_clip(keep)

        # 2. пепел — только когда уже разгорелось
        if age > 46:
            for ax0, speed, phase, span in ASHES:
                life = (self.t * speed + phase) % span
                ay = CANVAS_H - 6 - life
                if ay < 30:
                    continue
                drift = math.sin((life + phase) * 0.06) * 6
                fade = 1.0 - life / span
                shade = int(250 * fade * fade)
                if shade < 25:
                    continue
                c.fill((shade, int(shade * 0.55), int(shade * 0.2)),
                       pygame.Rect(int(ax0 + drift) % CANVAS_W, int(ay), 1, 1))

        # 3. силуэт проступает из темноты
        BACKLIT = (150, 138, 156)
        K = 2
        seen = _phase(age, 28, 46)
        sx = cx - (sp.SIT_W + 2) * K // 2
        sy = ground - (sp.SIT_H + 2) * K
        if seen > 0:
            sit = sp.scaled(self.art["sitting"][w.rider.char["key"]], K).copy()
            tint = tuple(int(v * seen) for v in BACKLIT)
            sit.fill(tint, special_flags=pygame.BLEND_RGB_MULT)
            bow = min(3, max(0, age - 200) // 90)      # плечи оседают позже
            c.blit(sit, (sx, sy + bow))

        # 4. шары всплывают снизу и переходят в медленное парение
        rise = _phase(age, 62, 50)
        if rise > 0:
            bal = sp.scaled(self.art["balloons"], K).copy()
            tint = tuple(int(v * rise) for v in BACKLIT)
            bal.fill(tint, special_flags=pygame.BLEND_RGB_MULT)
            # всплыли к кулаку и застыли: дальше связка не шевелится
            lift = (1.0 - rise) * 34
            hand_x = sx + sp.SIT_HAND[0] * K
            hand_y = sy + sp.SIT_HAND[1] * K
            c.blit(bal, (hand_x - sp.BALLOON_ANCHOR[0] * K,
                         int(hand_y - sp.BALLOON_ANCHOR[1] * K + lift)))

        # 5. буквы GAME OVER падают сверху по одной и отскакивают
        title = "GAME OVER"
        widths = [self.font_big.size(t)[0] for t in title]
        tx = cx - sum(widths) // 2
        landed_now = False
        for i, glyph in enumerate(title):
            start = 56 + i * 4
            p = _phase(age, start, 18)
            if p > 0:
                dy = int(-52 * (1.0 - p) ** 2)
                if 0.80 < p < 1.0:                    # короткий отскок
                    dy += int(math.sin((p - 0.80) / 0.20 * math.pi) * 3)
                if age - (start + 18) in (0, 1):
                    landed_now = True
                self.text(c, glyph, tx, 6 + dy, C_RED, self.font_big)
            tx += widths[i]

        # от удара последней буквы сцену коротко встряхивает
        if landed_now:
            c.scroll(0, 1)

        # 6. счёт накручивается, следом проступают итоги
        cnt = _phase(age, 108, 46)
        if cnt > 0:
            self.text(c, f"СЧЁТ  {int(w.score * cnt)}", cx, 30,
                      C_WHITE, self.font, center=True)
        if _phase(age, 156, 1) > 0:
            self.text(c, f"КАССЕТ {w.tapes}   САЛЬТО {w.flips}   "
                         f"ТРЮКОВ {w.tricks}   ЗВЁЗД {w.stars}",
                      cx, 45, C_STAR, self.font_small, center=True)
        if _phase(age, 174, 1) > 0:
            best = self.scores.get(w.rider.char["key"], 0)
            if w.score >= best and w.score > 0:
                blink = C_GREEN if (self.t // 12) % 2 else C_YELLOW
                self.text(c, "НОВЫЙ РЕКОРД!", cx, 57, blink,
                          self.font_small, center=True)
            else:
                self.text(c, f"РЕКОРД {best}", cx, 57, (150, 142, 160),
                          self.font_small, center=True)
        if age > 194 and self.touch_ui:
            self.plate(c, OVER_AGAIN, "ЕЩЁ РАЗ", C_YELLOW)
            self.plate(c, OVER_MENU, "В МЕНЮ", C_WHITE)
        elif age > 194 and (self.t // 18) % 2 == 0:
            self.text(c, "ENTER - ЕЩЁ РАЗ    ESC - В МЕНЮ", cx, 70,
                      C_WHITE, self.font_small, center=True)

    def plate(self, c, rect, label, color):
        """Кнопка-плашка для касаний на самом канвасе."""
        c.fill(C_UI_EDGE, rect.inflate(2, 2))
        c.fill((30, 20, 48), rect)
        c.fill(color, pygame.Rect(rect.x, rect.y, rect.w, 1))
        self.text(c, label, rect.centerx, rect.y + 6, color,
                  self.font_small, center=True)

    def button_image(self, name, pressed):
        """Полупрозрачная круглая кнопка; собирается один раз и кэшируется."""
        key = (name, self.orient, pressed)
        img = self.btn_cache.get(key)
        if img is None:
            r = BUTTONS[self.orient][name][2]
            img = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
            base = (252, 214, 60) if name == "jump" else (250, 250, 252)
            alpha = 150 if pressed else 78
            pygame.draw.circle(img, (*base, alpha), (r, r), r)
            pygame.draw.circle(img, (*base, 210), (r, r), r, 3)
            if name == "pause":
                for dx in (-5, 3):
                    pygame.draw.rect(img, (250, 250, 252, 230),
                                     (r + dx, r - 8, 4, 16))
            else:
                font = pygame.font.Font(None, max(20, int(r * 0.5)))
                txt = font.render(BUTTON_LABEL[name], True, (250, 250, 252))
                shade = font.render(BUTTON_LABEL[name], True, (18, 14, 28))
                pos = txt.get_rect(center=(r, r))
                img.blit(shade, pos.move(1, 2))
                img.blit(txt, pos)
            self.btn_cache[key] = img
        return img

    def draw_buttons(self):
        """Экранные кнопки поверх картинки: только пока идёт забег."""
        if not self.touch_ui or self.state != STATE_PLAY or self.resume_t > 0:
            return
        held = {self.button_at(p) for p in self.pointers.values()}
        for name, (cx, cy, r) in BUTTONS[self.orient].items():
            img = self.button_image(name, name in held)
            self.screen.blit(img, (cx - r, cy - r))

    def present(self):
        """Растянуть канвас и отцентровать с полями.

        На компьютере масштаб целый — пиксели остаются чёткими. В браузере
        на телефоне экран мал, там канвас тянется во всю ширину (или
        в портрете прижат к верху, а снизу остаётся место под кнопки)."""
        sw, sh = self.screen.get_size()
        if WEB and self.orient == "portrait":
            k = sw / CANVAS_W
            w, h = sw, int(CANVAS_H * k)
            self.view = (0.0, 0.0, k)
            self.screen.fill((10, 5, 18))
            self.screen.blit(pygame.transform.scale(self.canvas, (w, h)),
                             (0, 0))
        else:
            k = max(1, min(sw // CANVAS_W, sh // CANVAS_H))
            w, h = CANVAS_W * k, CANVAS_H * k
            ox, oy = (sw - w) // 2, (sh - h) // 2
            self.view = (float(ox), float(oy), float(k))
            if (w, h) != (sw, sh):
                self.screen.fill((0, 0, 0))
            self.screen.blit(pygame.transform.scale(self.canvas, (w, h)),
                             (ox, oy))
        self.draw_buttons()
        pygame.display.flip()

    # --- окно ---
    def web_orient(self):
        win = platform.window
        return "portrait" if win.innerHeight > win.innerWidth else "landscape"

    def make_display(self):
        if WEB:
            self.orient = self.web_orient()
            return pygame.display.set_mode(WEB_SIZE[self.orient])
        return pygame.display.set_mode((WIN_W, WIN_H), pygame.RESIZABLE)

    def check_orientation(self):
        """Телефон повернули — пересобрать окно под новую ориентацию."""
        if self.web_orient() != self.orient:
            self.screen = self.make_display()
            self.pointers.clear()
            self.jump_ptr = None

    # --- цикл ---
    async def run(self):
        self.screen = self.make_display()
        pygame.display.set_caption("Oliver Tree — 8-bit Scooter Run")
        clock = pygame.time.Clock()
        step = 1000.0 / FPS
        acc, last, frame = 0.0, pygame.time.get_ticks(), 0
        while self.running:
            for ev in pygame.event.get():
                self.handle_event(ev)
            # шаг физики фиксирован: если кадр вышел долгим (слабый
            # телефон), игра догоняет несколькими апдейтами подряд
            now = pygame.time.get_ticks()
            acc += min(now - last, 100)
            last = now
            n = 0
            while acc >= step and n < 3:
                self.update()
                acc -= step
                n += 1
            if n == 3:
                acc = 0.0
            self.draw()
            self.present()
            frame += 1
            if WEB and frame % 30 == 0:
                self.check_orientation()
            clock.tick(FPS)
            await asyncio.sleep(0)
        pygame.quit()


async def main():
    pygame.mixer.pre_init(44100, -16, 2, 512)
    pygame.init()
    try:
        pygame.mixer.init()
        sound = True
    except pygame.error:
        sound = False                # без звуковой карты игра всё равно идёт
    await App(sound=sound).run()


if __name__ == "__main__":
    asyncio.run(main())
