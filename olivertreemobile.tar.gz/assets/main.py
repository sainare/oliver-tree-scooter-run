            

                  

                

   

     














   



import asyncio

import json

import math

import os

import random

import sys

import time

import urllib.parse



import pygame



import looks

import sprites as sp

import world as wd

from chiptune import Audio

from songs import CAT_KEYS, CAT_ORDER, CAT_LABELS, TITLES, DEFAULT_PICKS

from settings import (CANVAS_W, CANVAS_H, WIN_W, WIN_H, FPS,

                      RESUME_FRAMES, OBST_LEVELS, START_LEVELS, OBJ_SCALE,

                      CHARACTERS, BASE_CHAR_COUNT, TRICK_COOLDOWN, GROUND_Y,

                      C_WHITE, C_BLACK, C_YELLOW,

                      C_GREEN, C_RED, C_CYAN, C_ROAD, C_ROAD_HI, C_ROAD_LINE, C_STAR,

                      C_UI_BOX, C_UI_BOX_SEL, C_UI_EDGE, TAPES, BOOST_FRAMES, ZONES,

                      SHOP_ITEMS, PREP_ITEMS, OBST_SCALE)



WEB = sys.platform == "emscripten"                                         

if WEB:

    import platform



MENU_COLS = 3

CHARS_PER_PAGE = 6



                                                                          

TRANS_FRAMES = 24

TRANS_CELL = 12

_trng = random.Random(11)

_cols = -(-CANVAS_W // TRANS_CELL)

_rows = -(-CANVAS_H // TRANS_CELL)

                                                                                  

TRANS_CELLS = [(pygame.Rect(cx * TRANS_CELL, cy * TRANS_CELL, TRANS_CELL, TRANS_CELL),

                (cx / _cols) * 0.62 + _trng.random() * 0.38)

               for cy in range(_rows) for cx in range(_cols)]

                                                            

TILE_W, TILE_H, TILE_GX, TILE_GY, TILE_Y0 = 36, 36, 12, 13, 20



                                                                               

WEB_SIZE = {"landscape": (640, 360), "portrait": (360, 640)}

def button_layout(orient, width, safe_l=0, safe_r=0, scale=1.0, lefty=False):

    

                                                                             

    if orient == "landscape":                                              

        g = {"jump": (width - 85 - safe_r, 282, 62 * scale),

             "trick": (74 + safe_l, 296, 46 * scale),

             "super": (64 + safe_l, 184, 36 * scale),

             "pause": (width - 30 - safe_r, 98, 22)}

        if lefty:                                                    

            g["jump"] = (85 + safe_l, 282, 62 * scale)

            g["trick"] = (width - 74 - safe_r, 296, 46 * scale)

            g["super"] = (width - 64 - safe_r, 184, 36 * scale)

    else:

        g = {"jump": (262, 460, 84 * scale), "trick": (86, 430, 62 * scale),

             "super": (110, 566, 46 * scale), "pause": (180, 246, 26)}

        if lefty:

            g["jump"] = (98, 460, 84 * scale)

            g["trick"] = (274, 430, 62 * scale)

            g["super"] = (250, 566, 46 * scale)

    return {k: (int(x), int(y), int(r)) for k, (x, y, r) in g.items()}





def web_window():

    


                                                                     

    win = platform.window

    iw, ih = max(1, int(win.innerWidth)), max(1, int(win.innerHeight))

    if ih > iw:

        return "portrait", WEB_SIZE["portrait"]

    return "landscape", (CANVAS_W * 2, 360)



                                                             

_MID = CANVAS_W // 2

MENU_START = pygame.Rect(_MID - 64, 146, 128, 22)

PAUSE_RESUME = pygame.Rect(_MID - 80, 68, 160, 21)

PAUSE_MUSIC = pygame.Rect(_MID - 80, 92, 160, 21)

PAUSE_SOUND = pygame.Rect(_MID - 80, 116, 160, 21)

PAUSE_MENU = pygame.Rect(_MID - 80, 140, 160, 21)

OVER_AGAIN = pygame.Rect(_MID - 120, 76, 108, 22)

OVER_MENU = pygame.Rect(_MID + 12, 76, 108, 22)

                                                

HOME_PLAY = pygame.Rect(_MID - 62, 62, 124, 22)

HOME_MUSIC = pygame.Rect(_MID - 62, 88, 124, 22)

HOME_SETTINGS = pygame.Rect(_MID - 62, 114, 124, 22)

                                                                                            

HOME_BOARD = pygame.Rect(_MID - 62, 140, 60, 22)

HOME_SHOP2 = pygame.Rect(_MID + 2, 140, 60, 22)

HOME_SHOP1 = pygame.Rect(_MID - 62, 140, 124, 22)

BOARD_BACK = pygame.Rect(_MID - 50, 156, 100, 18)

BOARD_BACK2 = pygame.Rect(_MID + 6, 156, 100, 18)                                        

BOARD_ACT = pygame.Rect(_MID - 106, 156, 100, 18)                               

BOARD_TAB_Y, BOARD_TAB_H, BOARD_ROW_Y, BOARD_ROW_H = 14, 13, 31, 13

BOARD_TABS = ("ЛИДЕРЫ", "ДРУЗЬЯ", "ЗАЯВКИ", "ПРОФИЛЬ", "ОНЛАЙН")

SHOP_TABS = ("ТОВАРЫ", "КОСМЕТИКА")

SHOP_ROW_Y, SHOP_ROW_H = 32, 31

PREP_ROW_Y, PREP_ROW_H = 30, 23

DIFF_NAMES = ("ЛЕГКО", "ОБЫЧНО", "СЛОЖНО")                                                           

DIFF_ROW = pygame.Rect(_MID - 120, 140, 240, 13)

PREP_GO = pygame.Rect(_MID - 106, 160, 100, 17)

PREP_BACK = pygame.Rect(_MID + 6, 160, 100, 17)

SEL_MUSIC = pygame.Rect(CANVAS_W - 54, 3, 50, 14)

MENU_BACK = pygame.Rect(4, 3, 54, 14)

MENU_PREV = pygame.Rect(4, 78, 20, 18)

MENU_NEXT = pygame.Rect(CANVAS_W - 24, 78, 20, 18)

SET_ROWS = (("music", "МУЗЫКА"), ("sfx", "ЗВУКИ"),

            ("pick", "ВЫБОР МУЗЫКИ"), ("obst", "ПРЕПЯТСТВИЯ"), ("start", "СКОРОСТЬ СТАРТА"),

            ("vibrate", "ВИБРАЦИЯ"),

            ("shake", "ТРЯСКА ЭКРАНА"), ("btn", "РАЗМЕР КНОПОК"),

            ("lefty", "РЕЖИМ ЛЕВШИ"), ("reset", "СБРОС РЕКОРДОВ"))

SET_X, SET_Y0, SET_W, SET_H, SET_STEP = _MID - 124, 16, 248, 13, 13

SET_BACK = pygame.Rect(_MID - 50, 161, 100, 16)

                                                                         

STYLE_LEFT_W = 132

STYLE_CHAR = pygame.Rect(6, 17, STYLE_LEFT_W - 6, 14)

STYLE_VIEW = pygame.Rect(6, 34, STYLE_LEFT_W - 6, 108)

STYLE_ROW_X, STYLE_ROW_Y0, STYLE_ROW_STEP = STYLE_LEFT_W + 8, 17, 18

STYLE_LABEL_W = 66                                                                     

STYLE_RESET = pygame.Rect(_MID - 106, 152, 100, 18)

STYLE_DONE = pygame.Rect(_MID + 6, 152, 100, 18)

SEL_STYLE = pygame.Rect(_MID + 70, 146, 58, 22)                                  

                                                                                     

MUS_TAB_Y, MUS_TAB_H = 14, 13

MUS_LIST_Y, MUS_ROW_H, MUS_PER_COL = 31, 13, 9

MUS_BACK = pygame.Rect(_MID - 50, 152, 100, 18)

                                                                     

UPD_ICON = pygame.Rect(CANVAS_W - 74, 4, 70, 16)

UPD_BOX = pygame.Rect(_MID - 114, 32, 228, 112)

UPD_OK = pygame.Rect(_MID - 104, 116, 96, 20)

UPD_LATER = pygame.Rect(_MID + 8, 116, 96, 20)

UPD_HIDE = pygame.Rect(_MID - 48, 116, 96, 20)

                                                                  

ACC_BTN = pygame.Rect(4, 4, 84, 16)

OUT_BTN = pygame.Rect(92, 4, 44, 16)                                         

ADMIN_BTN = pygame.Rect(4, 24, 84, 14)                                           

BTN_SIZES = (0.85, 1.0, 1.2)

BTN_SIZE_NAMES = ("МАЛЫЕ", "СРЕДНИЕ", "БОЛЬШИЕ")

CFG_VER = 2

                                                                            

                                                                 

OLD_DEFAULT_PICKS = {"menu": 0, "select": 0, "game": 2, "load": 0}

DEFAULT_CFG = {"ver": CFG_VER, "music": 8, "sfx": 8,

                                                                                   

               "mus_menu": DEFAULT_PICKS["menu"], "mus_select": DEFAULT_PICKS["select"],

               "mus_game": DEFAULT_PICKS["game"], "mus_load": DEFAULT_PICKS["load"],

                                                                                                   

               "own_menu": False, "own_select": False, "own_game": False, "own_load": False,

               "vibrate": True,

               "shake": True, "btn": 1, "lefty": False,

               "obst": 1,                                                                 

               "start": 1,                                                                    

               "looks": {}}                                                             

UPD_SNOOZE = 5 * 24 * 3600                                                     

WALLET_KEY = "oliver_wallet"                                                                 

SOON_ITEMS = ()                                                              

SCORE_KEY = "oliver_scores"                                                  

BACKGROUND_EVENTS = tuple(getattr(pygame, n) for n in

                          ("WINDOWFOCUSLOST", "WINDOWMINIMIZED", "WINDOWHIDDEN")

                          if hasattr(pygame, n))

BUTTON_LABEL = {"jump": "ПРЫЖОК", "trick": "ТРЮК", "super": "СУПЕР",

                "pause": "II"}



                                                                        

_rng = random.Random(451)

TITLE_STARS = [(_rng.randrange(CANVAS_W), _rng.randrange(4, 96))

               for _ in range(34)]



                                                          

ASHES = [(_rng.randrange(CANVAS_W), _rng.uniform(0.25, 0.75),

          _rng.randrange(200), _rng.randint(90, 150)) for _ in range(22)]



(STATE_TITLE, STATE_MENU, STATE_PLAY, STATE_PAUSE, STATE_OVER, STATE_SETTINGS,

 STATE_MUSIC, STATE_STYLE, STATE_BOARD, STATE_SHOP, STATE_PREP) = range(11)

JUMP_KEYS = (pygame.K_SPACE, pygame.K_UP, pygame.K_w)

DUCK_KEYS = (pygame.K_DOWN, pygame.K_s)

TRICK_KEYS = (pygame.K_LEFT, pygame.K_RIGHT, pygame.K_a, pygame.K_d)





def _phase(age, start, dur):

    


       

    if age <= start:

        return 0.0

    if age >= start + dur:

        return 1.0

    t = (age - start) / dur

    return 1.0 - (1.0 - t) ** 2





def data_dir():

                                                                  

    if getattr(sys, "frozen", False):

        return os.path.dirname(sys.executable)

    return os.path.dirname(os.path.abspath(__file__))





class App:

    def __init__(self, sound=True):

        self.canvas = pygame.Surface((CANVAS_W, CANVAS_H))

        self.screen = None

        self.fullscreen = False

        self.font_big = pygame.font.Font(None, 30)

        self.font = pygame.font.Font(None, 17)

        self.font_small = pygame.font.Font(None, 14)

        self.trans = None                                                         

        self.touch_ui = WEB                                             

        self.orient = "landscape"

        self.win_size = WEB_SIZE["landscape"]

        self.safe_l = self.safe_r = 0                                                 

        self.btn_geom = button_layout("landscape", self.win_size[0])

        self.pointers = {}                                                 

        self.finger_seen = False

        self.jump_ptr = None                                 

        self.btn_cache = {}

        self.view = (0.0, 0.0, 1.0)                                      

        self.audio = Audio(enabled=sound, music_dir=data_dir())

        self.art = self._load_art()

        self.scores = self._load_scores()

        self.cfg_dirty = False

                                                                                                 

        self.tapes_total, self.spent, self.perm = self._load_wallet()

        self.shop_tab, self.shop_sel, self.shop_msg = 0, -1, ["", 0]

        self.prep_idx, self.prep_sel = 0, []                                                   

        self.cfg = self._load_cfg()

        if self.cfg_dirty:                                                       

            self._save_cfg()

        for key in self.cfg["looks"]:                                            

            self.apply_look(key)

        self.style_char = 0                                                 

        self.style_row = 0                                                   

        self.style_back = STATE_MENU                       

                                                                               

                                                                        

        self.upd = None                                                          

        self.upd_prompt = False                                     

        self.upd_prompted = False                                        

                                                                              

        self.acc = None                                                                    

        self.acc_rev = 0                                                     

        self.remote_picks = {}                                                   

        self.acc_dp = -1

        self.board = {"state": "idle", "rows": [], "me": None}                    

        self.social = {"in": False, "friends": {"state": "idle", "rows": []},

                       "requests": {"state": "idle", "rows": []}, "me": {}}

        self.board_tab = 0                                                

        self.board_scroll = 0                                          

        self.menu_page = 0                                            

        self.acc_reset = None                                                                              

        self.acc_cfg = 0                                                           

        self.acc_cheat = 0                                                                       

        self.toast = ["", 0]                                                                                     

        self.set_sel = 0                                                           

        self.playlist = [CAT_KEYS["game"][0]]                          

        self.mus_tab = 0                                                 

        self.mus_cur = 0                                                     

        self.mus_back = STATE_TITLE                        

        self.session_pick = {}                                                         

        self.track_i = 0

        self.last_first = None

        self.now_playing = None                                          

        self.reset_armed = 0                                                        

        self.state = STATE_TITLE

        self.sel = 0

        self.world = None

        self.t = 0

        self.over_t = 0

        self.resume_t = 0

        self.running = True

        self.apply_cfg()

        self.audio.play_music(self.cat_key("menu"))

        self.audio.preload(self.cat_key("select"))                                       



                     

    @staticmethod

    def _make_helis():

        right = sp.make_helicopter()

        right = [sp.grow(f, OBJ_SCALE) for f in right]

        left = [pygame.transform.flip(f, True, False) for f in right]

        return {"right": right, "left": left}



    def _load_art(self):

        zones = [wd.make_background(pal) for pal in ZONES]

        art = {

            "zones": zones,

            "menu_bg": wd.make_menu_backdrop(),

            "sky": zones[0]["sky"],                          

            "clouds": zones[0]["clouds"],

            "city": zones[0]["city"],

            "font": self.font_small,

            "riders": {c["key"]: sp.make_rider_set(c) for c in CHARACTERS},

            "portraits": {c["key"]: sp.make_portrait(c) for c in CHARACTERS},

            "faces": {c["key"]: sp.make_face(c) for c in CHARACTERS},

            "sitting": {c["key"]: sp.make_sitting(c) for c in CHARACTERS},

            "launch_ramp": sp.make_launch_ramp(),

            "helis": self._make_helis(),

            "obstacles": {

                                                                                   

                                                                                         

                                                                                   

                "cone": sp.scaled(sp.make_cone(), OBST_SCALE),

                "hydrant": sp.scaled(sp.make_hydrant(), OBST_SCALE),

                "pothole": sp.scaled(sp.make_pothole(), OBST_SCALE),

                "sign": sp.scaled(sp.make_sign(), OBST_SCALE),

                "dumpster": sp.scaled(sp.make_dumpster(), OBST_SCALE),

                "spikeball": sp.scaled(sp.make_spikeball(), OBST_SCALE),

                "van": sp.scaled(sp.make_van(), OBST_SCALE),

                "ramp": sp.make_ramp(),

            },

                                                                            

            "tapes": [sp.make_tape_pickup(t["label"]) for t in TAPES],

            "star": sp.make_star(),

            "star_pickup": sp.make_star(21),

            "life": sp.scaled(sp.make_heart(True), 2),

            "balloons": sp.make_balloons(),

            "heart": sp.make_heart(True),

            "heart_off": sp.make_heart(False),

        }

        g = lambda im: sp.grow(im, OBJ_SCALE)                                      

        art["tapes"] = [g(t) for t in art["tapes"]]

        art["star_pickup"] = g(art["star_pickup"])

        art["life"] = g(art["life"])

        art["tape"] = sp.make_cassette(TAPES[0]["label"])                          

        self.audio.load_tapes(TAPES)

        return art



    def _score_path(self):

        return os.path.join(data_dir(), "highscores.json")



    def _load_scores(self):

        if WEB:

                                                                          

                                                                         

                                                           

            merged = {}

            for raw in (self._local_get(SCORE_KEY), self._cookie_get(SCORE_KEY)):

                try:

                    for k, v in (json.loads(raw) if raw else {}).items():

                        merged[k] = max(merged.get(k, 0), int(v))

                except Exception:

                    pass

            self.scores = merged

            self._save_scores()

            return merged

        try:

            with open(self._score_path(), encoding="utf-8") as f:

                data = json.load(f)

            return {k: int(v) for k, v in data.items()}

        except Exception:

            return {}



    def _save_scores(self):

        try:

            if WEB:

                data = json.dumps(self.scores, separators=(",", ":"))

                platform.window.localStorage.setItem(SCORE_KEY, data)

                self._cookie_set(SCORE_KEY, data)

                try:                                                              

                    platform.window.otAccount.pushScores(data)

                except Exception:

                    pass

                return

            with open(self._score_path(), "w", encoding="utf-8") as f:

                json.dump(self.scores, f, ensure_ascii=False, indent=1)

        except Exception:

            pass                                                             



                                                     

    @staticmethod

    def _local_get(name):

        try:

            raw = platform.window.localStorage.getItem(name)

            return str(raw) if raw else None

        except Exception:

            return None



    @staticmethod

    def _cookie_get(name):

        try:

            for part in str(platform.window.document.cookie).split(";"):

                k, _, v = part.strip().partition("=")

                if k == name:

                    return urllib.parse.unquote(v)

        except Exception:

            pass

        return None



    @staticmethod

    def _cookie_set(name, value):

        
                                                   

        try:

            path = str(platform.window.location.pathname)

            path = path[:path.rfind("/") + 1] or "/"

            platform.window.document.cookie = (

                "%s=%s; max-age=%d; path=%s; SameSite=Lax; Secure"

                % (name, urllib.parse.quote(value, safe=""), 400 * 86400, path))

        except Exception:

            pass



                                                                        

    def _load_wallet(self):

        data = {}

        try:

            if WEB:

                raw = self._local_get(WALLET_KEY)

                data = json.loads(raw) if raw else {}

            else:

                with open(os.path.join(data_dir(), "tapes.json"), encoding="utf-8") as f:

                    data = json.load(f)

        except Exception:

            data = {}

        perm = {}

        for k, v in (data.get("perm") or {}).items():

            if isinstance(v, (int, float)) and v > 0:

                perm[str(k)] = int(v)

        return (max(0, int(data.get("tapes", 0) or 0)),

                max(0, int(data.get("spent", 0) or 0)), perm)



    def _save_wallet(self):

        data = {"tapes": self.tapes_total, "spent": self.spent, "perm": self.perm}

        try:

            if WEB:

                raw = json.dumps(data, separators=(",", ":"))

                platform.window.localStorage.setItem(WALLET_KEY, raw)

                try:

                    platform.window.otAccount.pushWallet(raw)

                except Exception:

                    pass

                return

            with open(os.path.join(data_dir(), "tapes.json"), "w", encoding="utf-8") as f:

                json.dump(data, f)

        except Exception:

            pass



    def balance(self):

        return max(0, self.tapes_total - self.spent)



    def on_tape(self):

        self.tapes_total += 1

        self._save_wallet()



    def _draw_wallet(self, c, x, y, big=False):

                                                

        c.blit(self.art["tape"], (x, y))

        self.text(c, "x%d" % self.balance(), x + 20, y + (1 if not big else 0), C_YELLOW,

                  self.font if big else self.font_small)



    def say_shop(self, msg, good=False):

        self.shop_msg = [msg, 150, good]



    def say(self, msg, frames=210):

                                                                              

        self.toast = [msg, frames]



                       

    def _load_cfg(self):

        cfg = dict(DEFAULT_CFG)

        ver = 1

        try:

            if WEB:

                raw = platform.window.localStorage.getItem("oliver_cfg")

                data = json.loads(str(raw)) if raw else {}

            else:

                with open(os.path.join(data_dir(), "settings.json"),

                          encoding="utf-8") as f:

                    data = json.load(f)

            ver = data.get("ver", 1) if isinstance(data.get("ver"), int) else 1

            for k, v in data.items():

                if k in cfg and type(v) is type(cfg[k]):

                    cfg[k] = v

        except Exception:

            pass

        if ver < CFG_VER:                                                         

            for cat in CAT_ORDER:

                if cfg["mus_" + cat] == OLD_DEFAULT_PICKS[cat]:

                    cfg["mus_" + cat] = DEFAULT_PICKS[cat]

            cfg["ver"] = CFG_VER

            self.cfg_dirty = True

        cfg["music"] = max(0, min(10, cfg["music"]))

        cfg["sfx"] = max(0, min(10, cfg["sfx"]))

        cfg["btn"] = max(0, min(2, cfg["btn"]))

        cfg["obst"] = max(0, min(len(OBST_LEVELS) - 1, cfg["obst"]))

        cfg["start"] = max(0, min(len(START_LEVELS) - 1, cfg["start"]))

        cfg["looks"] = looks.clean(cfg["looks"])

        for cat in CAT_ORDER:

            cfg["mus_" + cat] = max(0, min(16, cfg["mus_" + cat]))

        return cfg



    def _save_cfg(self):

        try:

            if WEB:

                raw = json.dumps(self.cfg)

                platform.window.localStorage.setItem("oliver_cfg", raw)

                try:                                                                          

                    platform.window.otAccount.pushSettings(raw)

                except Exception:

                    pass

                return

            with open(os.path.join(data_dir(), "settings.json"), "w",

                      encoding="utf-8") as f:

                json.dump(self.cfg, f, ensure_ascii=False, indent=1)

        except Exception:

            pass



    def apply_cfg(self):

        self.audio.set_levels(self.cfg["music"] / 10.0, self.cfg["sfx"] / 10.0)

        self.rebuild_buttons()

        if self.world:

            self.world.shake_on = self.cfg["shake"]



    def rebuild_buttons(self):

        self.btn_geom = button_layout(

            self.orient, self.win_size[0],

            self.safe_l * 2, self.safe_r * 2,

            BTN_SIZES[self.cfg["btn"]], self.cfg["lefty"])

        self.btn_cache.clear()



    def vibrate(self, ms):

                                                                           

        if not (WEB and self.cfg["vibrate"]):

            return

        win = platform.window

        try:

            win.OTNative.vibrate(int(ms))

        except Exception:

            try:

                win.navigator.vibrate(int(ms))

            except Exception:

                pass



    def set_row_rect(self, i):

        return pygame.Rect(SET_X, SET_Y0 + i * SET_STEP, SET_W, SET_H - 2)



    def change_setting(self, i, delta=0, absolute=None):

                                                                        

        cfg = self.cfg

        key = SET_ROWS[i][0]

        if key in ("music", "sfx"):

            v = absolute if absolute is not None else cfg[key] + delta

            cfg[key] = max(0, min(10, v))

        elif key == "pick":                                                             

            self.open_music(0, STATE_SETTINGS)

            return

        elif key == "vibrate":

            cfg["vibrate"] = not cfg["vibrate"]

        elif key == "shake":

            cfg["shake"] = not cfg["shake"]

        elif key == "btn":

            cfg["btn"] = (cfg["btn"] + (delta or 1)) % 3

        elif key == "obst":

            cfg["obst"] = (cfg["obst"] + (delta or 1)) % len(OBST_LEVELS)

        elif key == "start":

            cfg["start"] = (cfg["start"] + (delta or 1)) % len(START_LEVELS)

        elif key == "style":

            return

        elif key == "lefty":

            cfg["lefty"] = not cfg["lefty"]

        elif key == "reset":

            if self.reset_armed > 0:                                             

                self.scores = {}

                self._save_scores()

                self.reset_armed = -90                                    

                self.audio.play("over")

                return

            self.reset_armed = 180                                             

            return

        self.apply_cfg()

        self._save_cfg()

        self.audio.play("move")

        if key == "vibrate":

            self.vibrate(60)



                                                        

    def poll_update(self):

                                                                           

        try:

            raw = platform.window.otUpd

            data = json.loads(str(raw)) if raw else None

        except Exception:

            data = None

        if not data or not data.get("ver"):

            return

        self.upd = data

                                                                             

                                                                    

        if (self.state == STATE_TITLE and not self.upd_prompted and not self.trans

                and data.get("state") in ("available", "ready")

                and not self.upd_snoozed()):

            self.upd_prompted = True

            self.upd_prompt = True

            self.audio.play("select")



    def upd_snoozed(self):

                                                                         

        try:

            raw = platform.window.localStorage.getItem("oliver_upd_snooze")

            d = json.loads(str(raw)) if raw else {}

            return (d.get("ver") == self.upd["ver"]

                    and time.time() < float(d.get("until", 0)))

        except Exception:

            return False



    def upd_later(self):

        self.upd_prompt = False

        self.audio.play("move")

        try:

            platform.window.localStorage.setItem("oliver_upd_snooze", json.dumps(

                {"ver": self.upd["ver"], "until": time.time() + UPD_SNOOZE}))

        except Exception:

            pass



    def upd_start(self):

                                                                                 

        self.upd_prompt = True

        self.audio.play("select")

        try:

            platform.window.OTNative.updateStart()

        except Exception:

            pass



    def _press_update(self, cx, cy):

        if self.upd.get("state") == "downloading":

            if UPD_HIDE.collidepoint(cx, cy):                                      

                self.upd_prompt = False

                self.audio.play("move")

            return

        if UPD_OK.collidepoint(cx, cy):

            self.upd_start()

        elif UPD_LATER.collidepoint(cx, cy):

            self.upd_later()



                                                                

    def poll_account(self):

                                                                               

        try:

            a = json.loads(str(platform.window.otAccount.state()))

        except Exception:

            return

        self.acc = a if a.get("available") else None

        if self.acc and a.get("dp", 0) != self.acc_dp:                                              

            self.acc_dp = a.get("dp", 0)

            try:

                rp = json.loads(str(platform.window.otAccount.defaults()))

                self.remote_picks = {k: v for k, v in rp.items() if k in CAT_ORDER and isinstance(v, int)}

            except Exception:

                pass

        if self.acc and a.get("reset", 0) != self.acc_reset:                               

                                                                                           

                                                                                            

                                                                                            

            if self.acc_reset is not None:

                self.say("РЕКОРДЫ СБРОШЕНЫ: ОБНАРУЖЕНА ПОДДЕЛКА", 240)

            self.acc_reset = a.get("reset", 0)

            self.scores = {}

            self.tapes_total, self.spent, self.perm = self._load_wallet()

        if not self.acc or a.get("rev", 0) == self.acc_rev:

            return

        self.acc_rev = a.get("rev", 0)

        if a.get("cheat", 0) != self.acc_cheat:                                                 

            self.acc_cheat = a.get("cheat", 0)

            self.say("РЕКОРД НЕ ПРИНЯТ: ПОХОЖ НА ПОДДЕЛКУ", 240)

        if a.get("cfg", 0) != self.acc_cfg:                                             

            self.acc_cfg = a.get("cfg", 0)

            self.apply_cloud_cfg()

        self.scores = self._load_scores()

                                                                                        

                                                                                           

                                                                                           

                                                                                          

                                                                         

        self.tapes_total, self.spent, self.perm = self._load_wallet()

        try:

            raw = self._local_get("oliver_cfg")

            stored = looks.clean(json.loads(raw).get("looks", {})) if raw else {}

        except Exception:

            stored = self.cfg["looks"]

        if stored != self.cfg["looks"]:

            self.cfg["looks"] = stored

            for ch in CHARACTERS:

                self.apply_look(ch["key"])



    def apply_cloud_cfg(self):

                                                                                 

        fresh = self._load_cfg()

        old = self.cfg

        self.cfg = fresh

        self.apply_cfg()

        if fresh["looks"] != old["looks"]:

            for ch in CHARACTERS:

                self.apply_look(ch["key"])

        if self.state in (STATE_TITLE, STATE_SETTINGS, STATE_BOARD, STATE_SHOP):

            self.audio.play_music(self.cat_key("menu"))                                          



    def acc_open(self):

                                                                                  

        if not (WEB and self.acc):

            return False

        try:

            return bool(platform.window.otAccount.isOpen())

        except Exception:

            return False



                                      

    def open_board(self):

        self.start_transition()

        self.audio.play("select")

        self.state = STATE_BOARD

        self.board_tab = 0

        self.board = {"state": "loading", "rows": [], "me": None}

        try:

            platform.window.otAccount.fetchTop()

        except Exception:

            self.board["state"] = "error"



    def board_tab_to(self, tab):

        if tab == self.board_tab:

            return

        self.board_tab = tab

        self.board_scroll = 0

        self.audio.play("move")

        try:

            if tab == 0:

                platform.window.otAccount.fetchTop()

            elif tab == 1:

                platform.window.otAccount.fetchFriends()

            elif tab == 2:

                platform.window.otAccount.fetchRequests()

        except Exception:

            pass



    def board_tab_rect(self, i):

        tw = (CANVAS_W - 12) // len(BOARD_TABS)

        return pygame.Rect(6 + i * tw, BOARD_TAB_Y, tw - 2, BOARD_TAB_H)



    def _press_board(self, cx, cy):

        signed = bool(self.social.get("in"))

        tab = self.board_tab

        admin = bool(self.acc and self.acc.get("admin"))

        wide = (tab == 0 and not admin) or (tab == 2 and signed) or tab == 4                                             

        if wide and BOARD_BACK.collidepoint(cx, cy):

            self.close_board()

            return

        if not wide and BOARD_BACK2.collidepoint(cx, cy):

            self.close_board()

            return

        for i in range(len(BOARD_TABS)):

            if self.board_tab_rect(i).inflate(2, 4).collidepoint(cx, cy):

                self.board_tab_to(i)

                return

        if tab == 0:

            if self.board.get("state") == "error":

                self.open_board()

            elif admin and BOARD_ACT.collidepoint(cx, cy):

                self._acc_mode("adminpanel")

            else:

                rows = self.board.get("rows") or []

                vis = 8

                if len(rows) > vis:

                    if cy < BOARD_ROW_Y + 4 and self.board_scroll > 0:

                        self.board_scroll -= vis

                        if self.board_scroll < 0:

                            self.board_scroll = 0

                        return

                    if cy > BOARD_ROW_Y + vis * BOARD_ROW_H - 8 and self.board_scroll + vis < len(rows):

                        self.board_scroll += vis

                        if self.board_scroll + vis > len(rows):

                            self.board_scroll = max(0, len(rows) - vis)

                        return

                if admin:

                    sc0 = self.board_scroll

                    for k, r in enumerate(rows[sc0:sc0 + vis]):

                        if r.get("uid") and pygame.Rect(_MID - 120, BOARD_ROW_Y + k * BOARD_ROW_H, 240, 12).collidepoint(cx, cy):

                            self._acc_mode("adminrow", r["uid"])

                            return

            return

        if tab == 4:                                                                              

            return

        if not signed:                                                                            

            if BOARD_ACT.collidepoint(cx, cy):

                self.acc_show()

            return

        if tab in (1, 3) and BOARD_ACT.collidepoint(cx, cy):

            try:

                platform.window.otAccount.openMode("addfriend" if tab == 1 else "profile")

            except Exception:

                pass

            return

        if tab in (1, 2):

            key = "friends" if tab == 1 else "requests"

            rows = (self.social.get(key) or {}).get("rows") or []

            for i, r in enumerate(rows[:8]):

                if pygame.Rect(_MID - 120, BOARD_ROW_Y + i * BOARD_ROW_H, 240, 12).collidepoint(cx, cy):

                    try:

                        platform.window.otAccount.openMode("friend" if tab == 1 else "request", r["uid"])

                    except Exception:

                        pass

                    return



    def close_board(self):

        self.start_transition()

        self.audio.play("move")

        self.state = STATE_TITLE



    def shop_rect(self):

        return HOME_SHOP2 if self.acc else HOME_SHOP1



    def open_shop(self):

        self.start_transition()

        self.audio.play("select")

        self.state = STATE_SHOP

        self.shop_tab, self.shop_sel, self.shop_msg = 0, -1, ["", 0, False]

        self.skin_page = 0



    def shop_price(self, item):

                                                                        

        level = self.perm.get(item[0], 0)

        return item[3][level] if level < len(item[3]) else None



    def shop_tap(self, i):

                                                                 

        item = SHOP_ITEMS[i]

        if item[0] in SOON_ITEMS:                                       

            self.shop_sel = -1

            self.audio.play("move")

            self.say_shop("СКОРО...", True)

            return

        price = self.shop_price(item)

        if price is None:

            self.say_shop("УЖЕ КУПЛЕНО")

            return

        if self.shop_sel != i:

            self.shop_sel = i

            self.audio.play("move")

            self.say_shop("ТАП ЕЩЁ РАЗ - КУПИТЬ ЗА %d" % price, True)

            return

        if self.balance() < price:

            self.audio.play("hit")

            self.say_shop("НЕ ХВАТАЕТ %d КАССЕТ" % (price - self.balance()))

            return

        self.spent += price

        self.perm[item[0]] = self.perm.get(item[0], 0) + 1

        self._save_wallet()

        self.audio.play("life")

        self.shop_sel = -1

        self.say_shop("КУПЛЕНО!", True)



    def shop_row_rect(self, i):

        return pygame.Rect(_MID - 120, SHOP_ROW_Y + i * SHOP_ROW_H, 240, SHOP_ROW_H - 3)



    def shop_tab_rect(self, i):

        tw = (CANVAS_W - 12) // len(SHOP_TABS)

        return pygame.Rect(6 + i * tw, BOARD_TAB_Y, tw - 2, BOARD_TAB_H)





    def _press_shop(self, cx, cy):

        if BOARD_BACK.collidepoint(cx, cy):

            self.close_shop()

            return

        for i in range(len(SHOP_TABS)):

            if self.shop_tab_rect(i).inflate(2, 4).collidepoint(cx, cy):

                if i != self.shop_tab:

                    self.shop_tab, self.shop_sel = i, -1

                    self.shop_msg = ["", 0, False]

                    self.audio.play("move")

                return

        if self.shop_tab == 0:

            for i in range(len(SHOP_ITEMS)):

                if self.shop_row_rect(i).collidepoint(cx, cy):

                    self.shop_tap(i)

                    return



                                                          



    def request_start(self, index):

                                                       

        if not self.char_unlocked(index):

            return

        self.start_transition()

        self.audio.play("select")

        self.prep_idx, self.prep_sel = index, []

        self.prep_diff = 1                                                   

        self.shop_msg = ["", 0, False]

        self.state = STATE_PREP



    def prep_toggle(self, i):

        pid, _n, _d, price, _s = PREP_ITEMS[i]

        if pid in self.prep_sel:                                                      

            self.prep_sel.remove(pid)

            self.spent -= price

            self.audio.play("move")

        elif self.balance() >= price:

            self.prep_sel.append(pid)

            self.spent += price

            self.audio.play("select")

        else:

            self.audio.play("hit")

            self.say_shop("НЕ ХВАТАЕТ КАССЕТ")

            return

        self._save_wallet()



    def prep_cancel(self):

        for pid, _n, _d, price, _s in PREP_ITEMS:                            

            if pid in self.prep_sel:

                self.spent -= price

        self.prep_sel = []

        self._save_wallet()

        self.start_transition()

        self.audio.play("move")

        self.state = STATE_MENU if self.world is None else STATE_OVER



    def prep_row_rect(self, i):

        return pygame.Rect(_MID - 120, PREP_ROW_Y + i * PREP_ROW_H, 240, PREP_ROW_H - 3)



    def _press_prep(self, cx, cy):

        if DIFF_ROW.collidepoint(cx, cy):

            w = DIFF_ROW.w // len(DIFF_NAMES)

            self.prep_diff = max(0, min(len(DIFF_NAMES) - 1, (cx - DIFF_ROW.x) // w))

            self.audio.play("move")

            return

        if PREP_GO.collidepoint(cx, cy):

            self.audio.play("select")

            self.start_game(self.prep_idx)

            return

        if PREP_BACK.collidepoint(cx, cy):

            self.prep_cancel()

            return

        for i in range(len(PREP_ITEMS)):

            if self.prep_row_rect(i).collidepoint(cx, cy):

                self.prep_toggle(i)

                return



    def close_shop(self):

        self.start_transition()

        self.audio.play("move")

        self.state = STATE_TITLE



    def poll_board(self):

        try:

            self.board = json.loads(str(platform.window.otAccount.board()))

            self.social = json.loads(str(platform.window.otAccount.social()))

        except Exception:

            pass



    def _acc_mode(self, mode, arg=None):

        try:

            platform.window.otAccount.openMode(mode, arg) if arg else platform.window.otAccount.openMode(mode)

        except Exception:

            pass



    def acc_show(self):

        self.audio.play("select")

        try:

            platform.window.otAccount.open()

        except Exception:

            pass



    def acc_push_looks(self):

        if WEB and self.acc and self.acc.get("in"):

            try:

                platform.window.otAccount.pushLooks(json.dumps(self.cfg["looks"]))

            except Exception:

                pass



                          

    def pick(self, cat):

                                                                                                         

        v = self.cfg["mus_" + cat]

        if self.cfg.get("own_" + cat) or v != DEFAULT_PICKS[cat]:

            return v

        r = self.remote_picks.get(cat)

        return r if isinstance(r, int) and 0 <= r <= 16 else v



    def cat_key(self, cat):

                                                                                      

        keys = CAT_KEYS[cat]

        v = self.pick(cat)

        if 0 < v <= len(keys):

            return keys[v - 1]

        key = self.session_pick.get(cat)

        if key is None:

            key = self.session_pick[cat] = random.choice(keys)

        return key



    def _make_playlist(self):

                                                                          

        keys = CAT_KEYS["game"]

        v = self.pick("game")

        if 0 < v <= len(keys):

            return [keys[v - 1]]

        keys = list(keys)

        random.shuffle(keys)

                                                                               

                                                                 

        avoid = (self.last_first, self.audio.desired)

        for _ in range(len(avoid)):

            if keys[0] in avoid:

                keys.append(keys.pop(0))

        self.last_first = keys[0]

        return keys



    def play_track(self, fade):

        key = self.playlist[self.track_i % len(self.playlist)]

        self.audio.play_music(key)

        self.audio.fade_in(fade)                                              

        if len(self.playlist) > 1:                                                

            self.audio.preload(self.playlist[(self.track_i + 1) % len(self.playlist)])

        self.now_playing = [TITLES[key], 240]



    def next_track(self):

                                                               

        if len(self.playlist) > 1:

            self.track_i += 1

            self.play_track(50)



                   

    def text(self, surf, msg, x, y, color=C_WHITE, font=None, center=False,

             shadow=True):

        



           

        font = font or self.font

        img = font.render(msg, False, color)                                   

        rect = img.get_rect()

        if center:

            rect.midtop = (x, y)

        else:

            rect.topleft = (x, y)

        if shadow:

            back = font.render(msg, False, C_BLACK)

            for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1),

                           (-1, -1), (1, -1), (-1, 1), (1, 1)):

                surf.blit(back, (rect.x + dx, rect.y + dy))

        surf.blit(img, rect)

        return rect



    def wrap(self, msg, font, width):

                                                                            

        words, lines, cur = msg.split(), [], ""

        for word in words:

            probe = (cur + " " + word).strip()

            if cur and font.size(probe)[0] > width:

                lines.append(cur)

                cur = word

            else:

                cur = probe

        if cur:

            lines.append(cur)

        return lines



                                                         

    def act_jump(self):

        self.world.jump()



    def act_trick(self):

        self.world.skip_intro()

        rider = self.world.rider

        if rider.on_ground:                                          

            rider.start_ground_trick(self.audio)

        else:

            rider.start_trick("tailwhip", self.audio)



    def act_super(self):

        self.world.skip_intro()

        self.world.rider.start_trick("superman", self.audio)



    def act_pause(self):

        self.state = STATE_PAUSE

        self.audio.play("pause")

        self.audio.pause_music()                                   



    def act_resume(self):

        self.state = STATE_PLAY

        self.resume_t = RESUME_FRAMES                         

        self.audio.play("pause")

        self.audio.resume_music()



    def act_menu_pick(self, index):

                                                                              

        real = self.menu_page * CHARS_PER_PAGE + index

        if real >= len(CHARACTERS):

            return

        if not self.char_unlocked(real):

            ch = CHARACTERS[real]

            price = ch["price"]

            if self.sel == real:

                if self.balance() < price:

                    self.audio.play("hit")

                    return

                self.spent += price

                self.perm[ch["perm_key"]] = 1

                self._save_wallet()

                self.audio.play("life")

                return

            self.sel = real

            self.audio.play("move")

            return

        if real == self.sel:

            self.audio.play("select")

            self.request_start(self.sel)

        else:

            self.sel = real

            self.audio.play("move")



                     

    def handle_event(self, ev):

        if ev.type == pygame.QUIT:

            self.running = False

            return

        if ev.type == pygame.VIDEORESIZE and not self.fullscreen and not WEB:

            self.screen = pygame.display.set_mode((max(ev.w, CANVAS_W),

                                                   max(ev.h, CANVAS_H)),

                                                  pygame.RESIZABLE)

            return

        if ev.type in BACKGROUND_EVENTS:

            self.on_background()                                             

            return

        if self.acc_open():                                                      

            self.pointers.clear()

            return

        if self._pointer_event(ev):

            return

        if ev.type != pygame.KEYDOWN and ev.type != pygame.KEYUP:

            return



        if ev.type == pygame.KEYDOWN:

            if ev.key == pygame.K_F11 and not WEB:

                self.toggle_fullscreen()

                return

            if ev.key == pygame.K_m:

                self.audio.toggle_mute()

                return



        if self.state == STATE_TITLE:

            if self.upd_prompt and self.upd:

                if ev.type == pygame.KEYDOWN and ev.key == pygame.K_ESCAPE:

                    self.upd_later()

                return

            if ev.type == pygame.KEYDOWN:

                if ev.key == pygame.K_ESCAPE:

                    self.running = False

                elif ev.key == pygame.K_s:

                    self.to_settings()

                elif ev.key == pygame.K_t:

                    self.open_music(0, STATE_TITLE)

                elif ev.key == pygame.K_l and self.acc:

                    self.open_board()

                elif ev.key == pygame.K_m:

                    self.open_shop()

                else:                                                           

                    self.to_select()

        elif self.state == STATE_SETTINGS:

            self._event_settings(ev)

        elif self.state == STATE_MUSIC:

            self._event_music(ev)

        elif self.state == STATE_STYLE:

            self._event_style(ev)

        elif self.state == STATE_PREP:

            if ev.type == pygame.KEYDOWN:

                if ev.key in (pygame.K_ESCAPE, pygame.K_q):

                    self.prep_cancel()

                elif ev.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):

                    self.audio.play("select")

                    self.start_game(self.prep_idx)

                elif ev.key in (pygame.K_1, pygame.K_2, pygame.K_3):

                    self.prep_toggle(ev.key - pygame.K_1)

        elif self.state == STATE_SHOP:

            if ev.type == pygame.KEYDOWN and ev.key in (pygame.K_ESCAPE, pygame.K_q):

                self.close_shop()

            elif ev.type == pygame.KEYDOWN and ev.key in (pygame.K_LEFT, pygame.K_RIGHT, pygame.K_a, pygame.K_d):

                self.shop_tab, self.shop_sel = 1 - self.shop_tab, -1

                self.shop_msg = ["", 0, False]

            elif ev.type == pygame.KEYDOWN and self.shop_tab == 0 and ev.key in (pygame.K_1, pygame.K_2, pygame.K_3):

                self.shop_tap(ev.key - pygame.K_1)

            elif ev.type == pygame.KEYDOWN and ev.key in (pygame.K_RETURN, pygame.K_SPACE) and self.shop_sel >= 0:

                self.shop_tap(self.shop_sel)

        elif self.state == STATE_BOARD:

            if ev.type == pygame.KEYDOWN and ev.key in (pygame.K_ESCAPE, pygame.K_q, pygame.K_RETURN, pygame.K_SPACE):

                self.close_board()

            elif ev.type == pygame.KEYDOWN and ev.key == pygame.K_r:

                self.open_board()

            elif ev.type == pygame.KEYDOWN and ev.key in (pygame.K_LEFT, pygame.K_a):

                self.board_tab_to((self.board_tab - 1) % len(BOARD_TABS))

            elif ev.type == pygame.KEYDOWN and ev.key in (pygame.K_RIGHT, pygame.K_d):

                self.board_tab_to((self.board_tab + 1) % len(BOARD_TABS))

        elif self.state == STATE_MENU:

            self._event_menu(ev)

        elif self.state == STATE_PLAY:

            self._event_play(ev)

        elif self.state == STATE_PAUSE:

            if ev.type == pygame.KEYDOWN and ev.key in (pygame.K_p,

                                                        pygame.K_ESCAPE):

                self.act_resume()

            elif ev.type == pygame.KEYDOWN and ev.key == pygame.K_q:

                self.to_menu()

            elif ev.type == pygame.KEYDOWN and ev.key == pygame.K_t:

                self.open_music(2, STATE_PAUSE)

        elif self.state == STATE_OVER:

            if ev.type == pygame.KEYDOWN:

                if ev.key in (pygame.K_RETURN, pygame.K_KP_ENTER,

                              pygame.K_SPACE):

                    self.request_start(self.sel)

                elif ev.key in (pygame.K_ESCAPE, pygame.K_q):

                    self.to_menu()



    def on_background(self):

                                                                

        if self.state == STATE_PLAY:

            self.act_pause()

        self.pointers.clear()

        self.jump_ptr = None



    def poll_shell(self):

                                                                                 

        try:

            win = platform.window

            if win.otBgFlag:

                win.otBgFlag = False

                platform.window.console.log("OT_BG")

                self.on_background()

                self.audio.bg_resume()                                                 

        except Exception:

            pass



    def start_transition(self):

                                                                          

        if self.screen is not None:

            self.trans = [self.canvas.copy(), 0]



    def to_select(self):

        self.start_transition()

        self.audio.play("select")

        self.state = STATE_MENU

        self.audio.play_music(self.cat_key("select"))



    def to_title(self):

                                                          

        self.start_transition()

        self.audio.play("move")

        self.state = STATE_TITLE

        self.audio.play_music(self.cat_key("menu"))



    def to_settings(self):

        self.start_transition()

        self.audio.play("select")

        self.state = STATE_SETTINGS

        self.reset_armed = 0

        self.audio.play_music(self.cat_key("menu"))



                                 

    def open_music(self, tab, back):

                                                                                    

        self.start_transition()

        self.audio.play("select")

        self.mus_tab = tab

        self.mus_back = back

        self.mus_cur = self.pick(CAT_ORDER[tab])

        self.state = STATE_MUSIC

        if back == STATE_PAUSE:

            self.audio.resume_music()                                                              



    def close_music(self):

        self.start_transition()

        self.audio.play("move")

        back = self.mus_back

        self.state = back

        if back == STATE_PAUSE:                                                

            self.audio.play_music(self.playlist[self.track_i % len(self.playlist)])

            self.audio.pause_music()

        elif back == STATE_MENU:

            self.audio.play_music(self.cat_key("select"))

        else:

            self.audio.play_music(self.cat_key("menu"))



    def preview_key(self, cat):

                                                                                 

        keys = CAT_KEYS[cat]

        v = self.pick(cat)

        if 0 < v <= len(keys):

            return keys[v - 1]

        if cat in ("menu", "select"):

            return self.cat_key(cat)

        return random.choice(keys)



    def music_tab(self, tab):

                                                                  

        self.mus_tab = tab % len(CAT_ORDER)

        self.mus_cur = self.pick(CAT_ORDER[self.mus_tab])

        self.audio.play("move")

        self.audio.play_music(self.preview_key(CAT_ORDER[self.mus_tab]))

        self.audio.fade_in(20)



    def music_pick(self, value):

                                                                            

        cat = CAT_ORDER[self.mus_tab]

        self.cfg["mus_" + cat] = max(0, min(16, value))

        self.cfg["own_" + cat] = True

        self._save_cfg()

        self.mus_cur = self.cfg["mus_" + cat]

        if cat in ("menu", "select"):

            self.session_pick.pop(cat, None)                                 

        self.audio.play("select")

        if cat == "game" and self.world is not None:                                     

            self.playlist = self._make_playlist()

            self.track_i = 0

            self.play_track(25)

        else:

            self.audio.play_music(self.preview_key(cat))

            self.audio.fade_in(25)



    def _event_music(self, ev):

        if ev.type != pygame.KEYDOWN:

            return

        if ev.key in (pygame.K_ESCAPE, pygame.K_q):

            self.close_music()

        elif ev.key in (pygame.K_LEFT, pygame.K_a):

            self.music_tab(self.mus_tab - 1)

        elif ev.key in (pygame.K_RIGHT, pygame.K_d):

            self.music_tab(self.mus_tab + 1)

        elif ev.key in (pygame.K_UP, pygame.K_w):

            self.mus_cur = (self.mus_cur - 1) % 17

        elif ev.key in (pygame.K_DOWN, pygame.K_s):

            self.mus_cur = (self.mus_cur + 1) % 17

        elif ev.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):

            self.music_pick(self.mus_cur)



    def music_tab_rect(self, i):

        tw = (CANVAS_W - 12) // len(CAT_ORDER)

        return pygame.Rect(6 + i * tw, MUS_TAB_Y, tw - 2, MUS_TAB_H)



    def music_row_rect(self, idx):

        cw = (CANVAS_W - 14) // 2

        col, row = divmod(idx, MUS_PER_COL)

        return pygame.Rect(6 + col * (cw + 2), MUS_LIST_Y + row * MUS_ROW_H,

                           cw, MUS_ROW_H - 1)



    def _press_music(self, cx, cy):

        if MUS_BACK.collidepoint(cx, cy):

            self.close_music()

            return

        for i in range(len(CAT_ORDER)):

            if self.music_tab_rect(i).inflate(2, 4).collidepoint(cx, cy):

                if i != self.mus_tab:

                    self.music_tab(i)

                return

        for idx in range(17):

            if self.music_row_rect(idx).inflate(2, 1).collidepoint(cx, cy):

                self.mus_cur = idx

                self.music_pick(idx)

                return



                                                                    

    def apply_look(self, key):

                                                                          

        base = next((c for c in CHARACTERS if c["key"] == key), None)

        if base is None:

            return

        ch = looks.styled(base, self.cfg["looks"].get(key, {}))

        self.art["riders"][key] = sp.make_rider_set(ch)

        self.art["portraits"][key] = sp.make_portrait(ch)

        self.art["faces"][key] = sp.make_face(ch)

        self.art["sitting"][key] = sp.make_sitting(ch)



    def open_style(self, back):

        self.start_transition()

        self.audio.play("select")

        self.style_back = back

        self.style_char = self.sel

        self.style_row = 0

        self.state = STATE_STYLE



    def close_style(self):

        self.start_transition()

        self.audio.play("move")

        self._save_cfg()

        self.sel = self.style_char                                         

        self.state = self.style_back



    def style_switch(self, delta):

        self.style_char = (self.style_char + delta) % len(CHARACTERS)

        self.audio.play("move")



    def style_change(self, row, delta):

                                                                                   

        key = CHARACTERS[self.style_char]["key"]

        look = dict(self.cfg["looks"].get(key, {}))

        i = (look.get(row, 0) + delta) % looks.count(row)

        if i:

            look[row] = i

        else:

            look.pop(row, None)

        if look:

            self.cfg["looks"][key] = look

        else:

            self.cfg["looks"].pop(key, None)

        self.apply_look(key)

        self._save_cfg()

        self.acc_push_looks()

        self.audio.play("move")



    def style_reset(self):

        key = CHARACTERS[self.style_char]["key"]

        self.cfg["looks"].pop(key, None)

        self.apply_look(key)

        self._save_cfg()

        self.acc_push_looks()

        self.audio.play("select")



    def style_row_rect(self, i):

        return pygame.Rect(STYLE_ROW_X, STYLE_ROW_Y0 + i * STYLE_ROW_STEP,

                           CANVAS_W - STYLE_ROW_X - 6, STYLE_ROW_STEP - 3)



    def _press_style(self, cx, cy):

        if STYLE_DONE.collidepoint(cx, cy):

            self.close_style()

            return

        if STYLE_RESET.collidepoint(cx, cy):

            self.style_reset()

            return

        if STYLE_CHAR.inflate(0, 4).collidepoint(cx, cy):

            self.style_switch(-1 if cx < STYLE_CHAR.centerx else 1)

            return

        for i, (row, _, _) in enumerate(looks.ROWS):

            r = self.style_row_rect(i)

            if r.inflate(0, 3).collidepoint(cx, cy):

                self.style_row = i

                fx = r.x + STYLE_LABEL_W                                       

                self.style_change(row, -1 if fx <= cx < fx + 24 else 1)                       

                return



    def _event_style(self, ev):

        if ev.type != pygame.KEYDOWN:

            return

        n = len(looks.ROWS)

        if ev.key in (pygame.K_ESCAPE, pygame.K_q, pygame.K_RETURN, pygame.K_KP_ENTER):

            self.close_style()

        elif ev.key in (pygame.K_UP, pygame.K_w):

            self.style_row = (self.style_row - 1) % n

        elif ev.key in (pygame.K_DOWN, pygame.K_s):

            self.style_row = (self.style_row + 1) % n

        elif ev.key in (pygame.K_LEFT, pygame.K_a):

            self.style_change(looks.ROWS[self.style_row][0], -1)

        elif ev.key in (pygame.K_RIGHT, pygame.K_d, pygame.K_SPACE):

            self.style_change(looks.ROWS[self.style_row][0], 1)

        elif ev.key == pygame.K_TAB:

            self.style_switch(1)

        elif ev.key == pygame.K_r:

            self.style_reset()



    def _event_settings(self, ev):

        if ev.type != pygame.KEYDOWN:

            return

        n = len(SET_ROWS)

        if ev.key in (pygame.K_ESCAPE, pygame.K_q):

            self.to_title()

        elif ev.key in (pygame.K_UP, pygame.K_w):

            self.set_sel = (self.set_sel - 1) % n

        elif ev.key in (pygame.K_DOWN, pygame.K_s):

            self.set_sel = (self.set_sel + 1) % n

        elif ev.key in (pygame.K_LEFT, pygame.K_a):

            self.change_setting(self.set_sel, -1)

        elif ev.key in (pygame.K_RIGHT, pygame.K_d):

            self.change_setting(self.set_sel, 1)

        elif ev.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):

            self.change_setting(self.set_sel, 1)



    def _event_menu(self, ev):

        if ev.type != pygame.KEYDOWN:

            return

        n = len(CHARACTERS)

        if ev.key in (pygame.K_LEFT, pygame.K_a):

            self.sel = (self.sel - 1) % n

            self.menu_page = self.sel // CHARS_PER_PAGE

            self.audio.play("move")

        elif ev.key in (pygame.K_RIGHT, pygame.K_d):

            self.sel = (self.sel + 1) % n

            self.menu_page = self.sel // CHARS_PER_PAGE

            self.audio.play("move")

        elif ev.key in (pygame.K_UP, pygame.K_w):

            self.sel = (self.sel - MENU_COLS) % n

            self.menu_page = self.sel // CHARS_PER_PAGE

            self.audio.play("move")

        elif ev.key in (pygame.K_DOWN, pygame.K_s):

            self.sel = (self.sel + MENU_COLS) % n

            self.menu_page = self.sel // CHARS_PER_PAGE

            self.audio.play("move")

        elif ev.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):

            if self.char_unlocked(self.sel):

                self.audio.play("select")

                self.request_start(self.sel)

        elif ev.key == pygame.K_TAB:

            self.open_music(1, STATE_MENU)

        elif ev.key == pygame.K_c:

            pass

        elif ev.key == pygame.K_ESCAPE:

            self.to_title()



    def _event_play(self, ev):

        rider = self.world.rider

        if ev.type == pygame.KEYDOWN:

            if ev.key in JUMP_KEYS:

                self.act_jump()

            elif ev.key in TRICK_KEYS:

                self.act_trick()

            elif ev.key in DUCK_KEYS:                                         

                self.act_super()

            elif ev.key in (pygame.K_p, pygame.K_ESCAPE):

                self.act_pause()

        elif ev.key in JUMP_KEYS:

            rider.release_jump()



                            

    def _pointer_event(self, ev):

                                                                               

        t = ev.type

        if t in (pygame.FINGERDOWN, pygame.FINGERUP):

            self.finger_seen = True

            self.touch_ui = True

            sw, sh = self.screen.get_size()

            pos = (ev.x * sw, ev.y * sh)

            pid = ("f", ev.finger_id)

        elif t in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP):

            if ev.button != 1:

                return False

                                                                              

                                                                       

            if getattr(ev, "touch", False):

                return True

            pos = ev.pos

            pid = "m"

        elif t == pygame.FINGERMOTION:

            return True

        else:

            return False

        if t in (pygame.FINGERDOWN, pygame.MOUSEBUTTONDOWN):

            self.pointers[pid] = pos

            self.on_press(pid, pos)

        else:

            self.pointers.pop(pid, None)

            self.on_release(pid, pos)

        return True



    def to_canvas(self, pos):

        ox, oy, k = self.view

        return ((pos[0] - ox) / k, (pos[1] - oy) / k)



    def button_at(self, pos):

        if not self.touch_ui:

            return None

        best, best_d = None, 1e9

        for name, (cx, cy, r) in self.btn_geom.items():

            d = math.hypot(pos[0] - cx, pos[1] - cy)

            if d <= r + 14 and d < best_d:                                 

                best, best_d = name, d

        return best



    def on_press(self, pid, pos):

        cx, cy = self.to_canvas(pos)

        if self.state == STATE_TITLE:

            if self.upd_prompt and self.upd:                                   

                self._press_update(cx, cy)

                return

            if self.upd and UPD_ICON.inflate(4, 6).collidepoint(cx, cy):

                if self.upd.get("state") == "downloading":

                    self.upd_prompt = True                                       

                else:

                    self.upd_start()

                return

            if self.acc and self.acc.get("in") and OUT_BTN.inflate(4, 6).collidepoint(cx, cy):

                self.audio.play("select")

                self._acc_mode("logout")                                       

                return

            if self.acc and self.acc.get("admin") and ADMIN_BTN.inflate(4, 4).collidepoint(cx, cy):

                self.audio.play("select")

                self._acc_mode("adminpanel")

                return

            if self.acc and ACC_BTN.inflate(4, 6).collidepoint(cx, cy):

                if self.acc.get("in"):                                                      

                    self.audio.play("select")

                    try:

                        platform.window.otAccount.openMode("profile")

                    except Exception:

                        pass

                else:

                    self.acc_show()

                return

            if HOME_PLAY.collidepoint(cx, cy):

                self.to_select()

            elif HOME_MUSIC.collidepoint(cx, cy):

                self.open_music(0, STATE_TITLE)

            elif HOME_SETTINGS.collidepoint(cx, cy):

                self.to_settings()

            elif self.acc and HOME_BOARD.collidepoint(cx, cy):

                self.open_board()

            elif self.shop_rect().collidepoint(cx, cy):

                self.open_shop()

        elif self.state == STATE_SETTINGS:

            self._press_settings(cx, cy)

        elif self.state == STATE_MUSIC:

            self._press_music(cx, cy)

        elif self.state == STATE_STYLE:

            self._press_style(cx, cy)

        elif self.state == STATE_SHOP:

            self._press_shop(cx, cy)

        elif self.state == STATE_PREP:

            self._press_prep(cx, cy)

        elif self.state == STATE_BOARD:

            self._press_board(cx, cy)

        elif self.state == STATE_MENU:

            if MENU_BACK.collidepoint(cx, cy):

                self.to_title()

                return

            if SEL_MUSIC.collidepoint(cx, cy):

                self.open_music(1, STATE_MENU)

                return

            pass               

            if self.menu_pages() > 1:

                if MENU_PREV.collidepoint(cx, cy):

                    self.menu_page = (self.menu_page - 1) % self.menu_pages()

                    self.audio.play("move")

                    return

                if MENU_NEXT.collidepoint(cx, cy):

                    self.menu_page = (self.menu_page + 1) % self.menu_pages()

                    self.audio.play("move")

                    return

            for i, box in enumerate(self.menu_tiles()):

                if box.inflate(6, 6).collidepoint(cx, cy):

                    self.act_menu_pick(i)

                    return

            if MENU_START.collidepoint(cx, cy):

                if self.char_unlocked(self.sel):

                    self.audio.play("select")

                    self.request_start(self.sel)

                else:

                    ch = CHARACTERS[self.sel]

                    if self.balance() >= ch["price"]:

                        self.spent += ch["price"]

                        self.perm[ch["perm_key"]] = 1

                        self._save_wallet()

                        self.audio.play("life")

                    else:

                        self.audio.play("hit")

        elif self.state == STATE_PLAY:

            if self.resume_t > 0:

                return

            name = self.button_at(pos)

            if name == "jump":

                self.jump_ptr = pid

                self.act_jump()

            elif name == "trick":

                self.act_trick()

            elif name == "super":

                self.act_super()

            elif name == "pause":

                self.act_pause()

        elif self.state == STATE_PAUSE:

            if PAUSE_RESUME.collidepoint(cx, cy):

                self.act_resume()

            elif PAUSE_MUSIC.collidepoint(cx, cy):

                self.open_music(2, STATE_PAUSE)

            elif PAUSE_SOUND.collidepoint(cx, cy):

                self.audio.toggle_mute()

            elif PAUSE_MENU.collidepoint(cx, cy):

                self.to_menu()

        elif self.state == STATE_OVER:

            if self.over_t > 194:

                if OVER_AGAIN.collidepoint(cx, cy):

                    self.request_start(self.sel)

                elif OVER_MENU.collidepoint(cx, cy):

                    self.to_menu()



    def _press_settings(self, cx, cy):

        if SET_BACK.collidepoint(cx, cy):

            self.to_title()

            return

        for i in range(len(SET_ROWS)):

            r = self.set_row_rect(i)

            if not r.inflate(4, 2).collidepoint(cx, cy):

                continue

            self.set_sel = i

            if SET_ROWS[i][0] in ("music", "sfx"):

                bar_x = r.right - 84

                if cx < r.right - 108:                                                 

                    return

                if cx < bar_x - 2:                                               

                    self.change_setting(i, -1)

                elif cx > bar_x + 62:                                   

                    self.change_setting(i, 1)

                else:                                                        

                    self.change_setting(i, absolute=int((cx - bar_x) // 6) + 1)

            else:

                self.change_setting(i, 1)

            return



    def on_release(self, pid, pos):

        if pid == self.jump_ptr:

            self.jump_ptr = None

            if self.state == STATE_PLAY and self.world:

                self.world.rider.release_jump()



    def char_unlocked(self, i):

        ch = CHARACTERS[i]

        if not ch.get("price"):

            return True

        return self.perm.get(ch["perm_key"], 0) > 0



    def menu_pages(self):

        return max(1, (len(CHARACTERS) + CHARS_PER_PAGE - 1) // CHARS_PER_PAGE)



    def menu_page_chars(self):

        start = self.menu_page * CHARS_PER_PAGE

        end = min(start + CHARS_PER_PAGE, len(CHARACTERS))

        return start, end



    def menu_tiles(self):

        cols = MENU_COLS

        start, end = self.menu_page_chars()

        count = end - start

        x0 = (CANVAS_W - (cols * TILE_W + (cols - 1) * TILE_GX)) // 2

        return [pygame.Rect(x0 + (i % cols) * (TILE_W + TILE_GX),

                            TILE_Y0 + (i // cols) * (TILE_H + TILE_GY),

                            TILE_W, TILE_H)

                for i in range(count)]



                      

    def start_game(self, index):

        self.start_transition()

        char = CHARACTERS[index]

        best = self.scores.get(char["key"], 0)

        self.world = wd.World(char, self.art, self.audio, best=best)

        self.world.haptic = self.vibrate

        self.world.shake_on = self.cfg["shake"]

        diff = getattr(self, "prep_diff", 1)                                                       

        self.world.obst = max(0, min(len(OBST_LEVELS) - 1, self.cfg["obst"] + (diff - 1)))

        start_i = max(0, min(len(START_LEVELS) - 1, self.cfg["start"] + (diff - 1)))

        self.world.start_speed = self.world.speed = self.world.base_speed = START_LEVELS[start_i][1]

        self.world.on_zone = self.next_track

        self.world.on_tape = self.on_tape

        self.world.pre = tuple(self.prep_sel)                                               

        self.prep_sel = []

        r = self.world.rider

        r.double_owned = self.perm.get("djump", 0) > 0

        r.lives += min(3, self.perm.get("hp", 0))                      

        self.playlist = self._make_playlist()

        self.track_i = 0

        self.state = STATE_PLAY

        self.resume_t = 0

        self.jump_ptr = None

        self.play_track(wd.INTRO_DARK)                                            



    def to_menu(self):

        self.start_transition()

        self.state = STATE_MENU

        self.world = None

        self.resume_t = 0                                                   

        self.jump_ptr = None

        self.audio.play_music(self.cat_key("select"))



    def toggle_fullscreen(self):

        self.fullscreen = not self.fullscreen

        if self.fullscreen:

            self.screen = pygame.display.set_mode(

                (0, 0), pygame.FULLSCREEN | pygame.SCALED)

        else:

            self.screen = pygame.display.set_mode(

                (WIN_W, WIN_H), pygame.RESIZABLE)



                    

    def update(self):

        self.t += 1

        self.audio.tick()

        if self.toast[1] > 0:

            self.toast[1] -= 1

        if self.reset_armed > 0:

            self.reset_armed -= 1

        elif self.reset_armed < 0:

            self.reset_armed += 1

        if self.trans:

            self.trans[1] += 1

            if self.trans[1] >= TRANS_FRAMES:

                self.trans = None

        if self.state == STATE_OVER:

            self.over_t += 1

        if self.state != STATE_PLAY:

            return

        if self.resume_t > 0:                                        

            self.resume_t -= 1

            return

        w = self.world

        if self.now_playing and self.now_playing[1] > 0:

            self.now_playing[1] -= 1

        w.update()

        if w.rider.dead and w.speed <= 0.01:

            key = w.rider.char["key"]

            if w.score > self.scores.get(key, 0):

                self.scores[key] = w.score

                self._save_scores()

            self.state = STATE_OVER

            self.over_t = 0

            self.audio.play_music("over")                                    



                       

    def draw(self):

        c = self.canvas

        if self.state == STATE_TITLE:

            self._draw_title(c)

            if self.upd_prompt and self.upd:

                self._draw_update(c)

        elif self.state == STATE_SETTINGS:

            self._draw_settings(c)

        elif self.state == STATE_MUSIC:

            self._draw_music(c)

        elif self.state == STATE_STYLE:

            self._draw_style(c)

        elif self.state == STATE_BOARD:

            self._draw_board(c)

        elif self.state == STATE_SHOP:

            self._draw_shop(c)

        elif self.state == STATE_PREP:

            self._draw_prep(c)

        elif self.state == STATE_MENU:

            self._draw_menu(c)

        else:

            self.world.draw(c)

            self._draw_hud(c)

            if self.state == STATE_PAUSE:

                self._draw_pause(c)

            elif self.state == STATE_OVER:

                self._draw_over(c)

            elif self.resume_t > 0:

                self._draw_resume(c)

        if self.trans:

            self._draw_transition(c)

        if self.toast[1] > 0:

            self._draw_toast(c)



    def _draw_toast(self, c):

        msg = self.toast[0]

        w = self.font_small.size(msg)[0] + 12

        rect = pygame.Rect(CANVAS_W // 2 - w // 2, 3, w, 13)

        pane = pygame.Surface((rect.w, rect.h), pygame.SRCALPHA)

        pane.fill((20, 14, 36, 225))

        c.blit(pane, rect.topleft)

        pygame.draw.rect(c, C_YELLOW, rect, 1)

        self.text(c, msg, CANVAS_W // 2, rect.y + 2, C_YELLOW, self.font_small, center=True)



    def _draw_transition(self, c):

                                                                               

        snap, t = self.trans

        p = t / float(TRANS_FRAMES)

        edge = []

        for rect, th in TRANS_CELLS:

            if th > p:

                c.blit(snap, rect.topleft, rect)

            elif th > p - 0.06:                                                        

                edge.append(rect)

        for rect in edge:

            c.fill((255, 232, 150), pygame.Rect(rect.x + 3, rect.y + 3, 6, 6))



    def _dim(self, surf, alpha=170):

        veil = pygame.Surface((CANVAS_W, CANVAS_H), pygame.SRCALPHA)

        veil.fill((10, 5, 18, alpha))

        surf.blit(veil, (0, 0))



    def _draw_title(self, c, prompt=True):

                                                                             

        for y in range(CANVAS_H):                                           

            t = y / CANVAS_H

            c.fill((int(18 + 40 * t), int(10 + 14 * t), int(38 + 30 * t)),

                   pygame.Rect(0, y, CANVAS_W, 1))

        for i, (sx, sy) in enumerate(TITLE_STARS):

            if (self.t // 10 + i) % 5:

                c.fill(C_WHITE, pygame.Rect(sx, sy, 1, 1))



        wobble = int(math.sin(self.t * 0.07) * 2)

        self.text(c, "OLIVER TREE", CANVAS_W // 2, 22 + wobble, C_YELLOW,

                  self.font_big, center=True)

        self.text(c, "8-BIT SCOOTER RUN", CANVAS_W // 2, 46, C_STAR,

                  self.font, center=True)



        rider = self.art["riders"][CHARACTERS[self.sel]["key"]]["run"]

        img = rider[(self.t // 6) % 4]

        rx = (self.t * 1.6) % (CANVAS_W + 60) - 40

        c.blit(img, (int(rx), 104 - img.get_height() + 4))



        wd.draw_flames(c, self.t, CANVAS_H - 6, 34)



        if not prompt:                                                    

            return

        self.plate(c, HOME_PLAY, "ИГРАТЬ", C_YELLOW)

        self.plate(c, HOME_MUSIC, "МУЗЫКА", C_WHITE)

        self.plate(c, HOME_SETTINGS, "НАСТРОЙКИ", C_WHITE)

        if self.acc:

            self.plate(c, HOME_BOARD, "ЛИДЕРЫ", C_STAR)

            nreq = int(self.acc.get("req", 0) or 0)

            if nreq:                                                          

                bx = HOME_BOARD.right - 12

                c.fill(C_BLACK, pygame.Rect(bx - 1, HOME_BOARD.y - 5, 14, 12))

                c.fill(C_RED, pygame.Rect(bx, HOME_BOARD.y - 4, 12, 10))

                self.text(c, str(min(nreq, 9)), bx + 3, HOME_BOARD.y - 4, C_WHITE, self.font_small, shadow=False)

        self.plate(c, self.shop_rect(), "МАГАЗИН", C_WHITE)

        if not self.touch_ui:

            self.text(c, "ENTER-ИГРАТЬ T-МУЗЫКА S-НАСТРОЙКИ", CANVAS_W // 2, 164, C_WHITE,

                      self.font_small, center=True)

            self.text(c, "M-МАГАЗИН" + ("  L-ЛИДЕРЫ" if self.acc else "") + "  ESC-ВЫХОД",

                      CANVAS_W // 2, 174, C_WHITE, self.font_small, center=True)

        if self.acc and not self.acc.get("in") and (self.t // 30) % 2 == 0:

            self.text(c, "ВОЙДИ ИЛИ СОЗДАЙ АККАУНТ!", CANVAS_W // 2, 62,

                      C_RED, self.font_small, center=True)

        if self.upd:

            self._draw_upd_icon(c)

        if self.acc:

            self._draw_acc_btn(c)

        self._draw_wallet(c, CANVAS_W // 2 - 20, 3)



    def _draw_acc_btn(self, c):

                                                                

        r, signed = ACC_BTN, self.acc.get("in")

        col = C_STAR if signed else C_WHITE

        c.fill(col, r.inflate(2, 2))

        c.fill((30, 20, 48), r)

        ix, iy = r.x + 5, r.y + 3                                         

        c.fill(col, pygame.Rect(ix + 1, iy, 3, 3))

        c.fill(col, pygame.Rect(ix, iy + 4, 5, 6))

        label = (self.acc.get("nick") or "")[:11] if signed else "ВОЙТИ"

        self.text(c, label, r.x + 14, r.y + 3, col, self.font_small)

        if signed:                                                                      

            o = OUT_BTN

            c.fill(C_RED, o.inflate(2, 2))

            c.fill((30, 20, 48), o)

            self.text(c, "ВЫЙТИ", o.centerx, o.y + 3, C_RED, self.font_small, center=True)

        if self.acc.get("admin"):                                                         

            a = ADMIN_BTN

            c.fill(C_RED, a.inflate(2, 2))

            c.fill((30, 20, 48), a)

            self.text(c, "АДМИН-ПАНЕЛЬ", a.centerx, a.y + 3, C_RED, self.font_small, center=True)



    def _draw_upd_icon(self, c):

                                                               

        u, r = self.upd, UPD_ICON

        st = u.get("state")

        blink = (self.t // 24) % 2 == 0

        c.fill(C_GREEN if blink or st == "downloading" else C_YELLOW, r.inflate(2, 2))

        c.fill((22, 44, 32), r)

        ax, ay = r.x + 6, r.y + 3                                            

        c.fill(C_WHITE, pygame.Rect(ax + 2, ay, 3, 5))

        for k in range(4):

            c.fill(C_WHITE, pygame.Rect(ax - 1 + k, ay + 5 + k, 9 - 2 * k, 1))

        c.fill(C_WHITE, pygame.Rect(ax - 2, ay + 10, 11, 1))

        if st == "downloading":

            label = "%d%%" % int(100 * float(u.get("progress", 0) or 0))

        else:

            label = "ОБНОВИТЬ"

        self.text(c, label, r.x + 16, r.y + 3, C_GREEN, self.font_small)



    def _draw_update(self, c):

                                                   

        u, box = self.upd, UPD_BOX

        st = u.get("state")

        self._dim(c, 200)

        c.fill(C_YELLOW, box.inflate(4, 4))

        c.fill((30, 20, 48), box)

        self.text(c, "ДОСТУПНА ВЕРСИЯ %s" % u.get("ver", "?"), box.centerx,

                  box.y + 8, C_YELLOW, self.font, center=True)

        mb = float(u.get("size", 0) or 0) / 1e6

        lines = {

            "available": ("Скачать с GitHub (%.1f МБ)" % mb,

                          "и установить поверх этой?"),

            "downloading": ("Скачиваю с GitHub...", ""),

            "ready": ("Файл скачан.", "Нажми УСТАНОВИТЬ и подтверди."),

            "permission": ("Разреши установку из этого", "приложения в настройках."),

            "error": ("Не получилось скачать.", "Проверь интернет."),

        }.get(st, ("", ""))

        y = box.y + 32

        for line in lines:

            if line:

                self.text(c, line, box.centerx, y, C_WHITE, self.font_small,

                          center=True)

            y += 13

        if st == "downloading":

            p = max(0.0, min(1.0, float(u.get("progress", 0) or 0)))

            bar = pygame.Rect(box.x + 18, box.y + 62, box.w - 36, 8)

            c.fill(C_BLACK, bar.inflate(2, 2))

            c.fill(C_GREEN, pygame.Rect(bar.x, bar.y, int(bar.w * p), bar.h))

            self.text(c, "%d%%" % int(p * 100), box.centerx, box.y + 72,

                      C_WHITE, self.font_small, center=True)

            self.plate(c, UPD_HIDE, "СКРЫТЬ", C_WHITE)

        else:

            self.plate(c, UPD_OK, "ЕЩЁ РАЗ" if st == "error" else "УСТАНОВИТЬ",

                       C_YELLOW)

            self.plate(c, UPD_LATER, "ПОЗЖЕ", C_WHITE)



    def _draw_settings(self, c):

                                                                          

        for y in range(CANVAS_H):

            t = y / CANVAS_H

            c.fill((int(18 + 40 * t), int(10 + 14 * t), int(38 + 30 * t)),

                   pygame.Rect(0, y, CANVAS_W, 1))

        for i, (sx, sy) in enumerate(TITLE_STARS):

            if (self.t // 10 + i) % 5:

                c.fill(C_WHITE, pygame.Rect(sx, sy, 1, 1))

        self.text(c, "НАСТРОЙКИ", CANVAS_W // 2, 2, C_YELLOW, self.font,

                  center=True)

        cfg = self.cfg

        for i, (key, label) in enumerate(SET_ROWS):

            r = self.set_row_rect(i)

            sel = (i == self.set_sel and not self.touch_ui)

            c.fill(C_YELLOW if sel else (78, 62, 108), r.inflate(2, 2))

            c.fill((30, 20, 48), r)

            self.text(c, label, r.x + 6, r.y + 2,

                      C_YELLOW if sel else C_WHITE, self.font_small)

            if key in ("music", "sfx"):                                           

                val = cfg[key]

                for bx, txt in ((r.right - 102, "-"), (r.right - 18, "+")):

                    box = pygame.Rect(bx, r.y + 1, 14, r.h - 2)

                    c.fill((70, 56, 98), box)

                    self.text(c, txt, box.centerx - 2, box.y + 1, C_WHITE,

                              self.font_small, shadow=False)

                bar_x = r.right - 84

                for k in range(10):

                    c.fill(C_STAR if k < val else (60, 48, 84),

                           pygame.Rect(bar_x + k * 6, r.y + 3, 5, r.h - 6))

                continue

            on_off = ("ВКЛ", C_GREEN), ("ВЫКЛ", C_RED)

            if key in ("vibrate", "shake", "lefty"):

                txt, col = on_off[0 if cfg[key] else 1]

            elif key == "btn":

                txt, col = BTN_SIZE_NAMES[cfg["btn"]], C_STAR

            elif key == "obst":

                txt = OBST_LEVELS[cfg["obst"]][0]

                col = (C_GREEN, C_STAR, C_RED)[cfg["obst"]]

            elif key == "start":

                txt = START_LEVELS[cfg["start"]][0]

                col = (C_GREEN, C_STAR, C_YELLOW, C_RED)[cfg["start"]]

            elif key in ("pick", "style"):

                txt, col = "ОТКРЫТЬ >", C_STAR

            else:                                                         

                if self.reset_armed > 0:

                    txt, col = "ТОЧНО? ЕЩЁ ТАП", C_RED

                elif self.reset_armed < 0:

                    txt, col = "ГОТОВО", C_GREEN

                else:

                    txt, col = "ТАП", (200, 190, 220)

            w = self.font_small.size(txt)[0]

            self.text(c, txt, r.right - 8 - w, r.y + 2, col, self.font_small)

        self.plate(c, SET_BACK, "НАЗАД", C_YELLOW)



    def _draw_music(self, c):

                                                                               

        for y in range(CANVAS_H):

            t = y / CANVAS_H

            c.fill((int(18 + 40 * t), int(10 + 14 * t), int(38 + 30 * t)),

                   pygame.Rect(0, y, CANVAS_W, 1))

        for i, (sx, sy) in enumerate(TITLE_STARS):

            if (self.t // 10 + i) % 5:

                c.fill(C_WHITE, pygame.Rect(sx, sy, 1, 1))

        self.text(c, "ВЫБОР МУЗЫКИ", CANVAS_W // 2, 2, C_YELLOW, self.font,

                  center=True)

        for i, cat in enumerate(CAT_ORDER):

            r = self.music_tab_rect(i)

            on = i == self.mus_tab

            c.fill(C_YELLOW if on else (78, 62, 108), r.inflate(2, 2))

            c.fill((86, 60, 24) if on else (30, 20, 48), r)

            self.text(c, CAT_LABELS[cat], r.centerx, r.y + 2,

                      C_YELLOW if on else C_WHITE, self.font_small, center=True)

        cat = CAT_ORDER[self.mus_tab]

        keys = CAT_KEYS[cat]

        chosen = self.pick(cat)

        for idx in range(17):

            r = self.music_row_rect(idx)

            kb = idx == self.mus_cur and not self.touch_ui

            c.fill(C_YELLOW if kb else (78, 62, 108), r.inflate(2, 2))

            c.fill((34, 84, 48) if idx == chosen else (30, 20, 48), r)

            label = "СЛУЧАЙНО" if idx == 0 else "%d. %s" % (idx, TITLES[keys[idx - 1]])

            if idx == chosen:

                label = "> " + label

            self.text(c, label, r.x + 4, r.y + 2,

                      C_GREEN if idx == chosen else C_WHITE, self.font_small)

        self.plate(c, MUS_BACK, "НАЗАД", C_YELLOW)



    def _bg(self, c):

        for y in range(CANVAS_H):

            t = y / CANVAS_H

            c.fill((int(18 + 40 * t), int(10 + 14 * t), int(38 + 30 * t)),

                   pygame.Rect(0, y, CANVAS_W, 1))

        for i, (sx, sy) in enumerate(TITLE_STARS):

            if (self.t // 10 + i) % 5:

                c.fill(C_WHITE, pygame.Rect(sx, sy, 1, 1))



    def _draw_shop(self, c):

                                                              

        self._bg(c)

        self.text(c, "МАГАЗИН", CANVAS_W // 2, 2, C_YELLOW, self.font, center=True)

        self._draw_wallet(c, CANVAS_W - 62, 2)

        for i, name in enumerate(SHOP_TABS):

            r = self.shop_tab_rect(i)

            on = i == self.shop_tab

            c.fill(C_YELLOW if on else (78, 62, 108), r.inflate(2, 2))

            c.fill((86, 60, 24) if on else (30, 20, 48), r)

            self.text(c, name, r.centerx, r.y + 2,

                      C_YELLOW if on else C_WHITE, self.font_small, center=True)

        if self.shop_tab == 1:

            self.text(c, "СКОРО...", CANVAS_W // 2, 90, C_STAR, self.font, center=True)

        else:

            for i, (iid, name, desc, prices) in enumerate(SHOP_ITEMS):

                r = self.shop_row_rect(i)

                level = self.perm.get(iid, 0)

                price = prices[level] if level < len(prices) else None

                sel = i == self.shop_sel

                can = price is not None and self.balance() >= price

                c.fill(C_YELLOW if sel else (78, 62, 108), r.inflate(2, 2))

                c.fill((46, 32, 70) if sel else (30, 20, 48), r)

                self.text(c, name, r.x + 6, r.y + 3, C_YELLOW if sel else C_WHITE, self.font_small)

                self.text(c, desc, r.x + 6, r.y + 15, (180, 170, 204), self.font_small)

                if iid in SOON_ITEMS:

                    label, col = "СКОРО...", C_STAR

                elif price is None:

                    label, col = "КУПЛЕНО", C_GREEN

                else:

                    label = ("%d/%d  " % (level, len(prices)) if len(prices) > 1 else "") + "%d" % price

                    col = C_STAR if can else (200, 110, 120)

                self.text(c, label, r.right - 6 - self.font_small.size(label)[0], r.y + 3, col, self.font_small)

        msg = self.shop_msg

        if msg[1] > 0:

            msg[1] -= 1

            self.text(c, msg[0], CANVAS_W // 2, 135, C_GREEN if msg[2] else C_RED, self.font_small, center=True)

        self.plate(c, BOARD_BACK, "НАЗАД", C_YELLOW)



    def _draw_prep(self, c):

                                                          

        self._bg(c)

        self.text(c, "ПЕРЕД МАТЧЕМ", CANVAS_W // 2, 2, C_YELLOW, self.font, center=True)

        self._draw_wallet(c, CANVAS_W // 2 - 20, 16)

        self.text(c, "СЛОЖНОСТЬ", CANVAS_W // 2, 129, (190, 180, 214), self.font_small, center=True)

        diff = getattr(self, "prep_diff", 1)

        dw = DIFF_ROW.w // len(DIFF_NAMES)

        for i, name in enumerate(DIFF_NAMES):

            r = pygame.Rect(DIFF_ROW.x + i * dw, DIFF_ROW.y, dw - 2, DIFF_ROW.h)

            on = i == diff

            col = (C_GREEN, C_STAR, C_RED)[i]

            c.fill(col if on else (78, 62, 108), r.inflate(2, 2))

            c.fill((34, 84, 48) if on else (30, 20, 48), r)

            self.text(c, name, r.centerx, r.y + 2, col, self.font_small, center=True)

        for i, (pid, name, desc, price, secs) in enumerate(PREP_ITEMS):

            r = self.prep_row_rect(i)

            on = pid in self.prep_sel

            can = self.balance() >= price

            c.fill(C_GREEN if on else (78, 62, 108), r.inflate(2, 2))

            c.fill((34, 84, 48) if on else (30, 20, 48), r)

            self.text(c, "%d. %s" % (i + 1, name), r.x + 6, r.y + 3, C_GREEN if on else C_WHITE, self.font_small)

            self.text(c, desc, r.x + 6, r.y + 14, (180, 170, 204), self.font_small)

            label = "ВЗЯТО" if on else "%d" % price

            col = C_GREEN if on else (C_STAR if can else (200, 110, 120))

            self.text(c, label, r.right - 6 - self.font_small.size(label)[0], r.y + 8, col, self.font_small)

        msg = self.shop_msg

        if msg[1] > 0:

            msg[1] -= 1

            self.text(c, msg[0], CANVAS_W // 2, 150, C_RED, self.font_small, center=True)

        self.plate(c, PREP_GO, "СТАРТ", C_YELLOW)

        self.plate(c, PREP_BACK, "НАЗАД", C_WHITE)



    def _draw_board(self, c):

                                                                  

        for y in range(CANVAS_H):

            t = y / CANVAS_H

            c.fill((int(18 + 40 * t), int(10 + 14 * t), int(38 + 30 * t)),

                   pygame.Rect(0, y, CANVAS_W, 1))

        self.text(c, "ЛИДЕРЫ И ДРУЗЬЯ", CANVAS_W // 2, 2, C_YELLOW, self.font, center=True)

        for i, name in enumerate(BOARD_TABS):

            r = self.board_tab_rect(i)

            on = i == self.board_tab

            c.fill(C_YELLOW if on else (78, 62, 108), r.inflate(2, 2))

            c.fill((86, 60, 24) if on else (30, 20, 48), r)

            label = name

            nreq = len((self.social.get("requests") or {}).get("rows") or [])

            if i == 2 and nreq:

                label = "ЗАЯВКИ %d" % nreq

            self.text(c, label, r.centerx, r.y + 2, C_YELLOW if on else (C_RED if (i == 2 and nreq) else C_WHITE),

                      self.font_small, center=True)

        signed = bool(self.social.get("in"))

        me_nick = ((self.social.get("me") or {}).get("nick") or "").lower()

        if self.board_tab == 0:

            self._draw_rows(c, self.board, me_nick, "ПОКА ПУСТО - БУДЬ ПЕРВЫМ!")

            if self.acc and self.acc.get("admin"):

                self.text(c, "АДМИН: ТАП ПО ИГРОКУ - ПРАВКА", CANVAS_W // 2, 144, C_STAR, self.font_small, center=True)

                self.plate(c, BOARD_ACT, "АДМИН", C_STAR)

                self.plate(c, BOARD_BACK2, "НАЗАД", C_YELLOW)

            else:

                self.plate(c, BOARD_BACK, "НАЗАД", C_YELLOW)

            return

        if self.board_tab == 4:

            self.text(c, "СКОРО...", CANVAS_W // 2, 70, C_WHITE, self.font, center=True)

            self.plate(c, BOARD_BACK, "НАЗАД", C_YELLOW)

            return

        if not signed:

            self.text(c, "ДРУЗЬЯ, ЗАПРОСЫ И ПРОФИЛЬ - ПОСЛЕ ВХОДА", CANVAS_W // 2, 70, C_WHITE,

                      self.font_small, center=True)

            self.plate(c, BOARD_ACT, "ВОЙТИ", C_YELLOW)

            self.plate(c, BOARD_BACK2, "НАЗАД", C_WHITE)

            return

        if self.board_tab == 1:

            fr = self.social.get("friends") or {}

            if fr.get("state") in (None, "idle"):

                fr = {"state": "loading", "rows": []}

            self._draw_rows(c, fr, me_nick, "ДРУЗЕЙ ПОКА НЕТ - ОТПРАВЬ ЗАПРОС ПО ID", tap=True)

            if (fr.get("rows")):

                self.text(c, "ТАП ПО ДРУГУ - ЧАТ", CANVAS_W // 2, 144, (190, 180, 214), self.font_small, center=True)

            self.plate(c, BOARD_ACT, "ДОБАВИТЬ", C_STAR)

        elif self.board_tab == 2:

            rq = self.social.get("requests") or {}

            if rq.get("state") in (None, "idle"):

                rq = {"state": "loading", "rows": []}

            self._draw_rows(c, rq, me_nick, "ЗАПРОСОВ НЕТ", tap=True)

            if rq.get("rows"):

                self.text(c, "ТАП ПО ИГРОКУ - ПРИНЯТЬ ИЛИ ОТКЛОНИТЬ", CANVAS_W // 2, 144,

                          (190, 180, 214), self.font_small, center=True)

            self.plate(c, BOARD_BACK, "НАЗАД", C_WHITE)

            return

        else:

            me = self.social.get("me") or {}

            cx = CANVAS_W // 2

            self.text(c, me.get("nick") or "?", cx, 40, C_YELLOW, self.font_big, center=True)

            self.text(c, ("\"%s\"" % me["status"]) if me.get("status") else "СТАТУС НЕ ЗАДАН",

                      cx, 62, C_WHITE if me.get("status") else (150, 140, 170), self.font_small, center=True)

            self.text(c, "ЛУЧШИЙ РЕКОРД: %d" % int(me.get("best") or 0), cx, 84, C_STAR,

                      self.font_small, center=True)

            self.text(c, "КАССЕТ: %d" % self.balance(), cx, 98, C_STAR, self.font_small, center=True)

            self.text(c, "ТВОЙ ID ДЛЯ ДРУЗЕЙ:", cx, 118, C_WHITE, self.font_small, center=True)

            self.text(c, me.get("code") or "...", cx, 130, C_GREEN, self.font_big, center=True)

            self.plate(c, BOARD_ACT, "ИЗМЕНИТЬ", C_STAR)

        self.plate(c, BOARD_BACK2, "НАЗАД", C_WHITE)



    def _draw_rows(self, c, data, me, empty_msg, tap=False):

        st = data.get("state")

        rows = data.get("rows") or []

        if st == "loading":

            self.text(c, "ЗАГРУЗКА" + "." * (1 + (self.t // 15) % 3), CANVAS_W // 2, 80, C_WHITE,

                      self.font, center=True)

        elif st == "error":

            self.text(c, "НЕТ СВЯЗИ С ИНТЕРНЕТОМ", CANVAS_W // 2, 72, C_RED, self.font, center=True)

            self.text(c, "ТАП - ПОПРОБОВАТЬ ЕЩЁ", CANVAS_W // 2, 90, C_WHITE, self.font_small, center=True)

        elif not rows:

            self.text(c, empty_msg, CANVAS_W // 2, 80, C_WHITE, self.font_small, center=True)

        else:

            x0, w = _MID - 120, 240

            vis = 8

            sc0 = self.board_scroll

            page = rows[sc0:sc0 + vis]

            for k, r in enumerate(page):

                rank = sc0 + k

                y = BOARD_ROW_Y + k * BOARD_ROW_H

                mine = r["nick"].lower() == me and not tap

                c.fill(C_GREEN if mine else (78, 62, 108), pygame.Rect(x0 - 1, y - 1, w + 2, 13))

                c.fill((34, 84, 48) if mine else (30, 20, 48), pygame.Rect(x0, y, w, 11))

                col = (C_STAR, (210, 210, 224), (226, 156, 98))[rank] if (rank < 3 and not tap) else C_WHITE

                if not tap:

                    self.text(c, "%d." % (rank + 1), x0 + 4, y + 1, col, self.font_small)

                name_x = x0 + (26 if not tap else 6)

                if r.get("admin"):

                    self.text(c, "★", name_x, y + 1, C_STAR, self.font_small)

                    name_x += 10

                self.text(c, r["nick"][:16], name_x, y + 1, C_GREEN if mine else col, self.font_small)

                sc = str(int(r["best"]))

                self.text(c, sc, x0 + w - 6 - self.font_small.size(sc)[0], y + 1, col, self.font_small)

                if r.get("status"):

                    self.text(c, r["status"][:14], name_x + 82, y + 1, (170, 160, 196), self.font_small)

            if len(rows) > vis:

                info = "%d-%d / %d" % (sc0 + 1, min(sc0 + vis, len(rows)), len(rows))

                self.text(c, info, CANVAS_W // 2, 136, (190, 180, 214), self.font_small, center=True)



    def _draw_style(self, c):

                                                                 

        for y in range(CANVAS_H):

            t = y / CANVAS_H

            c.fill((int(18 + 40 * t), int(10 + 14 * t), int(38 + 30 * t)),

                   pygame.Rect(0, y, CANVAS_W, 1))

        self.text(c, "СТИЛЬ ПЕРСОНАЖА", CANVAS_W // 2, 2, C_YELLOW, self.font,

                  center=True)

        ch = CHARACTERS[self.style_char]

        key = ch["key"]

        r = STYLE_CHAR                                                          

        c.fill((78, 62, 108), r.inflate(2, 2))

        c.fill((30, 20, 48), r)

        self.text(c, "<", r.x + 4, r.y + 2, C_YELLOW, self.font_small)

        self.text(c, ">", r.right - 9, r.y + 2, C_YELLOW, self.font_small)

        self.text(c, ch["name"], r.centerx, r.y + 2, C_WHITE, self.font_small,

                  center=True)

        v = STYLE_VIEW                                                              

        c.fill(C_UI_EDGE, v.inflate(2, 2))

        for y in range(v.h):

            t = y / v.h

            c.fill((int(52 + 84 * t), int(146 + 62 * t), int(226 + 16 * t)),

                   pygame.Rect(v.x, v.y + y, v.w, 1))

        road_y = v.bottom - 12

        c.fill(C_ROAD_HI, pygame.Rect(v.x, road_y - 2, v.w, 2))

        c.fill(C_ROAD, pygame.Rect(v.x, road_y, v.w, v.bottom - road_y))

        for x in range(-24, v.w + 24, 24):                                    

            lx = v.x + x - (self.t * 2) % 24

            if v.x <= lx and lx + 10 <= v.right:

                c.fill(C_ROAD_LINE, pygame.Rect(lx, road_y + 5, 10, 2))

        img = self.art["riders"][key]["run"][(self.t // 6) % 4]

        big = pygame.transform.scale(img, (img.get_width() * 2, img.get_height() * 2))

        c.blit(big, (v.centerx - big.get_width() // 2,

                     road_y - (sp.WHEEL_BACK[1] + sp.WHEEL_R + 1) * 2))

        look = self.cfg["looks"].get(key, {})

        for i, (row, title, _) in enumerate(looks.ROWS):

            r = self.style_row_rect(i)

            sel = i == self.style_row and not self.touch_ui

            c.fill(C_YELLOW if sel else (78, 62, 108), r.inflate(2, 2))

            c.fill((30, 20, 48), r)

            self.text(c, title, r.x + 4, r.y + 3, C_YELLOW if sel else C_WHITE,

                      self.font_small)

            idx = look.get(row, 0)

            box = pygame.Rect(r.x + STYLE_LABEL_W, r.y + 1, r.w - STYLE_LABEL_W - 1, r.h - 2)

            c.fill((52, 40, 76), box)

            self.text(c, "<", box.x + 3, r.y + 3, C_STAR, self.font_small, shadow=False)

            self.text(c, ">", box.right - 8, r.y + 3, C_STAR, self.font_small, shadow=False)

            self.text(c, looks.label(row, idx), box.centerx + 1, r.y + 3,

                      C_GREEN if idx else (200, 190, 220), self.font_small, center=True)

        self.plate(c, STYLE_RESET, "СБРОС", C_WHITE)

        self.plate(c, STYLE_DONE, "ГОТОВО", C_YELLOW)

        if not self.touch_ui:

            self.text(c, "СТРЕЛКИ - ВЫБОР   TAB - ПЕРСОНАЖ   R - СБРОС",

                      CANVAS_W // 2, 171, C_WHITE, self.font_small, center=True)



    def _draw_menu(self, c):

                                                                          

        c.blit(self.art["menu_bg"], (0, 0))

        wd.draw_spotlights(c, self.t)



        self.text(c, "ВЫБЕРИ ПЕРСОНАЖА", CANVAS_W // 2,

                  1 if CANVAS_W >= 380 else 4, C_WHITE,

                  self.font_big if CANVAS_W >= 380 else self.font, center=True)

        if self.touch_ui:

            self.plate(c, MENU_BACK, "< НАЗАД", C_WHITE)

        self.plate(c, SEL_MUSIC, "ПЕСНИ", C_WHITE)



        start, end = self.menu_page_chars()

        tiles = self.menu_tiles()

        for k, box in enumerate(tiles):

            i = start + k

            ch = CHARACTERS[i]

            picked = (i == self.sel)

            locked = not self.char_unlocked(i)

            c.fill(C_UI_EDGE, box.inflate(4, 4))

            c.fill(C_UI_BOX_SEL if picked else C_UI_BOX, box)

            face = self.art["faces"][ch["key"]]

            c.blit(face, (box.x + (box.w - face.get_width()) // 2, box.y + 5))

            if locked:

                dim = pygame.Surface((box.w, box.h))

                dim.fill((0, 0, 0))

                dim.set_alpha(140)

                c.blit(dim, box.topleft)

                self.text(c, "%d" % ch["price"], box.centerx, box.y + 13,

                          C_STAR, self.font_small, center=True)

            if picked and (self.t // 8) % 2 == 0:

                pygame.draw.rect(c, C_YELLOW, box.inflate(8, 8), 2)

            self.text(c, ch.get("short", ch["name"]), box.x + box.w // 2,

                      box.y + box.h + 2,

                      C_YELLOW if picked else ((160, 150, 180) if locked else C_WHITE),

                      self.font_small, center=True)



        pages = self.menu_pages()

        if pages > 1:

            for d, sym, rect in ((-1, "<", MENU_PREV), (1, ">", MENU_NEXT)):

                c.fill(C_WHITE, rect.inflate(2, 2))

                c.fill((30, 20, 48), rect)

                self.text(c, sym, rect.centerx, rect.y + 3, C_WHITE,

                          self.font_small, center=True)

            self.text(c, "%d/%d" % (self.menu_page + 1, pages),

                      CANVAS_W // 2, 108, (190, 180, 214),

                      self.font_small, center=True)



        ch = CHARACTERS[self.sel]

        locked_sel = not self.char_unlocked(self.sel)

        y = 120

        for line in self.wrap(ch["note"], self.font_small, CANVAS_W - 16):

            self.text(c, line, CANVAS_W // 2, y, C_WHITE,

                      self.font_small, center=True)

            y += 11

        if locked_sel:

            self.text(c, "%s   ЦЕНА: %d" % (ch["name"], ch["price"]),

                      CANVAS_W // 2, y + 2, C_RED, self.font_small, center=True)

        else:

            best = self.scores.get(ch["key"], 0)

            self.text(c, f'{ch["name"]}   РЕКОРД {best}', CANVAS_W // 2, y + 2,

                      C_STAR, self.font_small, center=True)

        if self.touch_ui:

            if locked_sel:

                self.plate(c, MENU_START, "КУПИТЬ", C_RED)

            else:

                self.plate(c, MENU_START, "СТАРТ", C_YELLOW)

            pass

            self.text(c, "ТАП ПО ПЕРСОНАЖУ - ВЫБОР, ЕЩЁ ТАП - СТАРТ",

                      CANVAS_W // 2, 170, C_WHITE, self.font_small,

                      center=True)

        else:

            if (self.t // 20) % 2 == 0:

                self.text(c, "PRESS START", CANVAS_W // 2, 154, C_WHITE,

                          self.font, center=True)

            self.text(c, "СТРЕЛКИ - ВЫБОР    ENTER - СТАРТ    C - СТИЛЬ",

                      CANVAS_W // 2, 168, C_WHITE, self.font_small,

                      center=True)



    def _draw_resume(self, c):

                                                                          

        left = self.resume_t // FPS + 1

        self._dim(c, 90)

        step = self.resume_t % FPS                                              

        color = C_STAR if step > FPS // 2 else C_WHITE

        self.text(c, str(left), CANVAS_W // 2, 56, color,

                  self.font_big, center=True)

        self.text(c, "ПРИГОТОВЬСЯ", CANVAS_W // 2, 88, C_WHITE,

                  self.font, center=True)



    def _draw_hud(self, c):

        w = self.world

        sl, sr = self.safe_l, self.safe_r

        for i in range(max(3, w.rider.lives)):

            img = self.art["heart"] if i < w.rider.lives else self.art["heart_off"]

            c.blit(img, (6 + sl + i * 12, 6))

        score = f"{w.score:06d}"

        self.text(c, score, CANVAS_W - 6 - sr - self.font.size(score)[0], 5,

                  C_WHITE)

        c.blit(self.art["tape"], (CANVAS_W // 2 - 18, 5))

        self.text(c, f"x{w.tapes}", CANVAS_W // 2 - 2, 6, C_YELLOW)

        if w.best:

            best = f"BEST {w.best}"

            self.text(c, best, CANVAS_W - 6 - sr

                      - self.font_small.size(best)[0], 18,

                      (188, 176, 210), self.font_small)

        if self.now_playing and self.now_playing[1] > 0:

            self.text(c, "ТРЕК: " + self.now_playing[0], CANVAS_W // 2, 19,

                      (255, 190, 226), self.font_small, center=True)

        rows = []                                                                                        

        if w.rider.boost > 0:

            rows.append(("star", w.rider.boost, max(1, w.rider.boost_max), C_STAR))

        if w.rider.fly_t > 0:

            rows.append(("ПОЛЁТ", w.rider.fly_t, 600, C_CYAN))

        if w.speed_lock > 0:

            rows.append(("СКОРОСТЬ", w.speed_lock, 900, (255, 150, 90)))

        if rows:

            for k, (icon, left, total, col) in enumerate(rows):

                y = 18 + k * 12

                if icon == "star":

                    c.blit(self.art["star"], (6 + sl, y))

                    bx = 18 + sl

                else:

                    self.text(c, icon, 6 + sl, y, col, self.font_small)

                    bx = 6 + sl + self.font_small.size(icon)[0] + 3

                c.fill(C_BLACK, pygame.Rect(bx, y + 3, 42, 5))

                c.fill(col, pygame.Rect(bx + 1, y + 4, int(40 * left / float(total)), 3))

                self.text(c, "%d" % (left // 60 + 1), bx + 45, y, col, self.font_small)

        if not rows and self.audio.muted:

            self.text(c, "MUTE", 6 + sl, 20, (200, 120, 120), self.font_small)



    def _draw_pause(self, c):

        self._dim(c)

        self.text(c, "ПАУЗА", CANVAS_W // 2, 44 if self.touch_ui else 66,

                  C_YELLOW, self.font_big, center=True)

        if self.touch_ui:

            self.plate(c, PAUSE_RESUME, "ПРОДОЛЖИТЬ", C_YELLOW)

            self.plate(c, PAUSE_MUSIC, "МУЗЫКА", C_WHITE)

            self.plate(c, PAUSE_SOUND,

                       "ЗВУК: ВЫКЛ" if self.audio.muted else "ЗВУК: ВКЛ",

                       C_WHITE)

            self.plate(c, PAUSE_MENU, "В МЕНЮ", C_WHITE)

            return

        self.text(c, "P - ПРОДОЛЖИТЬ", CANVAS_W // 2, 98, C_WHITE,

                  self.font, center=True)

        self.text(c, "T - МУЗЫКА", CANVAS_W // 2, 114, (190, 180, 210),

                  self.font_small, center=True)

        self.text(c, "Q - В МЕНЮ", CANVAS_W // 2, 128, (190, 180, 210),

                  self.font_small, center=True)



    def _draw_over(self, c):

        



           

        w = self.world

        age = self.over_t

        cx = CANVAS_W // 2

        ground = 174

        c.fill((6, 5, 10))



                                                           

        lit = _phase(age, 0, 52)

        if lit > 0:

            half = int((cx + 26) * lit)

            wd.draw_fire_glow(c, self.t, cx, CANVAS_H - 40)

            keep = c.get_clip()

            c.set_clip(pygame.Rect(cx - half, 0, half * 2, CANVAS_H))

            dying = max(0.55, 1.0 - max(0, age - 200) / 1100.0)

            wd.draw_flames(c, self.t, CANVAS_H - 2, int(72 * dying * lit))

            c.set_clip(keep)



                                                 

        if age > 46:

            for ax0, speed, phase, span in ASHES:

                life = (self.t * speed + phase) % span

                ay = CANVAS_H - 6 - life

                if ay < 30:

                    continue

                drift = math.sin((life + phase) * 0.06) * 6

                fade = 1.0 - life / span

                shade = int(250 * fade * fade)

                if shade < 25:

                    continue

                c.fill((shade, int(shade * 0.55), int(shade * 0.2)),

                       pygame.Rect(int(ax0 + drift) % CANVAS_W, int(ay), 1, 1))



                                         

        BACKLIT = (150, 138, 156)

        K = 2

        seen = _phase(age, 28, 46)

        sx = cx - (sp.SIT_W + 2) * K // 2

        sy = ground - (sp.SIT_H + 2) * K

        if seen > 0:

            sit = sp.scaled(self.art["sitting"][w.rider.char["key"]], K).copy()

            tint = tuple(int(v * seen) for v in BACKLIT)

            sit.fill(tint, special_flags=pygame.BLEND_RGB_MULT)

            bow = min(3, max(0, age - 200) // 90)                           

            c.blit(sit, (sx, sy + bow))



                                                                 

        rise = _phase(age, 62, 50)

        if rise > 0:

            bal = sp.scaled(self.art["balloons"], K).copy()

            tint = tuple(int(v * rise) for v in BACKLIT)

            bal.fill(tint, special_flags=pygame.BLEND_RGB_MULT)

                                                                    

            lift = (1.0 - rise) * 34

            hand_x = sx + sp.SIT_HAND[0] * K

            hand_y = sy + sp.SIT_HAND[1] * K

            c.blit(bal, (hand_x - sp.BALLOON_ANCHOR[0] * K,

                         int(hand_y - sp.BALLOON_ANCHOR[1] * K + lift)))



                                                                 

        title = "GAME OVER"

        widths = [self.font_big.size(t)[0] for t in title]

        tx = cx - sum(widths) // 2

        landed_now = False

        for i, glyph in enumerate(title):

            start = 56 + i * 4

            p = _phase(age, start, 18)

            if p > 0:

                dy = int(-52 * (1.0 - p) ** 2)

                if 0.80 < p < 1.0:                                     

                    dy += int(math.sin((p - 0.80) / 0.20 * math.pi) * 3)

                if age - (start + 18) in (0, 1):

                    landed_now = True

                self.text(c, glyph, tx, 6 + dy, C_RED, self.font_big)

            tx += widths[i]



                                                            

        if landed_now:

            c.scroll(0, 1)



                                                        

        cnt = _phase(age, 108, 46)

        if cnt > 0:

            self.text(c, f"СЧЁТ  {int(w.score * cnt)}", cx, 30,

                      C_WHITE, self.font, center=True)

        if _phase(age, 156, 1) > 0:

            self.text(c, f"КАССЕТ {w.tapes}   САЛЬТО {w.flips}   "

                         f"ТРЮКОВ {w.tricks}   ЗВЁЗД {w.stars}",

                      cx, 45, C_STAR, self.font_small, center=True)

        if _phase(age, 174, 1) > 0:

            best = self.scores.get(w.rider.char["key"], 0)

            if w.score >= best and w.score > 0:

                blink = C_GREEN if (self.t // 12) % 2 else C_YELLOW

                self.text(c, "НОВЫЙ РЕКОРД!", cx, 57, blink,

                          self.font_small, center=True)

            else:

                self.text(c, f"РЕКОРД {best}", cx, 57, (150, 142, 160),

                          self.font_small, center=True)

        if age > 194 and self.touch_ui:

            self.plate(c, OVER_AGAIN, "ЕЩЁ РАЗ", C_YELLOW)

            self.plate(c, OVER_MENU, "В МЕНЮ", C_WHITE)

        elif age > 194 and (self.t // 18) % 2 == 0:

            self.text(c, "ENTER - ЕЩЁ РАЗ    ESC - В МЕНЮ", cx, 70,

                      C_WHITE, self.font_small, center=True)



    def plate(self, c, rect, label, color):

                                                         

        c.fill(C_UI_EDGE, rect.inflate(2, 2))

        c.fill((30, 20, 48), rect)

        c.fill(color, pygame.Rect(rect.x, rect.y, rect.w, 1))

        self.text(c, label, rect.centerx, rect.y + 6, color,

                  self.font_small, center=True)



    def button_image(self, name, pressed):

                                                                              

        key = (name, self.orient, pressed)

        img = self.btn_cache.get(key)

        if img is None:

            r = self.btn_geom[name][2]

            img = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)

            base = (252, 214, 60) if name == "jump" else (250, 250, 252)

            alpha = 150 if pressed else 78

            pygame.draw.circle(img, (*base, alpha), (r, r), r)

            pygame.draw.circle(img, (*base, 210), (r, r), r, 3)

            if name == "pause":

                for dx in (-5, 3):

                    pygame.draw.rect(img, (250, 250, 252, 230),

                                     (r + dx, r - 8, 4, 16))

            else:

                font = pygame.font.Font(None, max(20, int(r * 0.5)))

                txt = font.render(BUTTON_LABEL[name], True, (250, 250, 252))

                shade = font.render(BUTTON_LABEL[name], True, (18, 14, 28))

                pos = txt.get_rect(center=(r, r))

                img.blit(shade, pos.move(1, 2))

                img.blit(txt, pos)

            self.btn_cache[key] = img

        return img



    def draw_buttons(self):

                                                                      

        if not self.touch_ui or self.state != STATE_PLAY or self.resume_t > 0:

            return

        held = {self.button_at(p) for p in self.pointers.values()}

        cd = self.world.rider.trick_cd

        for name, (cx, cy, r) in self.btn_geom.items():

            img = self.button_image(name, name in held)

            self.screen.blit(img, (cx - r, cy - r))

            if cd > 0 and name in ("trick", "super"):

                self._draw_cooldown(cx, cy, r, cd / float(TRICK_COOLDOWN))



    def _draw_cooldown(self, cx, cy, r, left):

                                                                              

        veil = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)

        pts = [(r, r)]

        steps = max(3, int(40 * left))

        for i in range(steps + 1):

            a = 2 * math.pi * left * i / steps

            pts.append((r + r * math.sin(a), r - r * math.cos(a)))

        pygame.draw.polygon(veil, (10, 6, 22, 170), pts)

        self.screen.blit(veil, (cx - r, cy - r))

        font = pygame.font.Font(None, max(20, int(r * 0.7)))

        txt = font.render("%.1f" % (left * TRICK_COOLDOWN / FPS), True, (250, 250, 252))

        self.screen.blit(txt, txt.get_rect(center=(cx, cy)))



    def present(self):

        



                                                                         

        sw, sh = self.screen.get_size()

        if WEB and self.orient == "portrait":

            k = sw / CANVAS_W

            w, h = sw, int(CANVAS_H * k)

            self.view = (0.0, 0.0, k)

            self.screen.fill((10, 5, 18))

            self.screen.blit(pygame.transform.scale(self.canvas, (w, h)),

                             (0, 0))

        else:

            k = max(1, min(sw // CANVAS_W, sh // CANVAS_H))

            w, h = CANVAS_W * k, CANVAS_H * k

            ox, oy = (sw - w) // 2, (sh - h) // 2

            self.view = (float(ox), float(oy), float(k))

            if (w, h) != (sw, sh):

                self.screen.fill((0, 0, 0))

            self.screen.blit(pygame.transform.scale(self.canvas, (w, h)),

                             (ox, oy))

        self.draw_buttons()

        pygame.display.flip()



                  

    def read_safe_area(self):

                                                                           

        if not WEB or self.orient != "landscape":

            return 0, 0

        try:

            win = platform.window

            k = CANVAS_W / max(1.0, float(win.innerWidth))

            left = float(win.OT_SAFE_L or 0) * k

            right = float(win.OT_SAFE_R or 0) * k

            return (int(left) + 3 if left else 0), (int(right) + 3 if right else 0)

        except Exception:

            return 0, 0



    def make_display(self):

        if WEB:

            self.orient, self.win_size = web_window()

            self.safe_l, self.safe_r = self.read_safe_area()

            self.rebuild_buttons()

            return pygame.display.set_mode(self.win_size)

        return pygame.display.set_mode((WIN_W, WIN_H), pygame.RESIZABLE)



    def check_orientation(self):

                                                                        

        if self.acc_open():

                                                                                          

                                                                                   

            return

        if (web_window() != (self.orient, self.win_size)

                or self.read_safe_area() != (self.safe_l, self.safe_r)):

            self.screen = self.make_display()

            self.pointers.clear()

            self.jump_ptr = None



                  

    async def run(self):

        self.screen = self.make_display()

        pygame.display.set_caption("Oliver Tree — 8-bit Scooter Run")

        clock = pygame.time.Clock()

        step = 1000.0 / FPS

        acc, last, frame = 0.0, pygame.time.get_ticks(), 0

        while self.running:

            for ev in pygame.event.get():

                self.handle_event(ev)

                                                                   

                                                                  

            now = pygame.time.get_ticks()

            acc += min(now - last, 100)

            last = now

            n = 0

            while acc >= step and n < 3:

                self.update()

                acc -= step

                n += 1

            if n == 3:

                acc = 0.0

            self.draw()

            self.present()

            frame += 1

            if WEB and frame % 30 == 0:

                self.check_orientation()

            if WEB and frame % 3 == 0:

                self.poll_shell()

            if WEB and frame % 20 == 0:

                self.poll_update()

            if WEB and frame % 20 == 10:

                self.poll_account()

            if WEB and self.state == STATE_BOARD and frame % 10 == 5:

                self.poll_board()

            if WEB and frame == 2:

                platform.window.console.log("OT_READY")                              

                try:

                    platform.window.otReady()                                         

                except Exception:

                    pass

            clock.tick(FPS)

            await asyncio.sleep(0)

        pygame.quit()









async def main():

                                                                      

    pygame.mixer.pre_init(44100, -16, 2, 2048 if WEB else 512)

    pygame.init()

    try:

        pygame.mixer.init()

        sound = True

    except pygame.error:

        sound = False                                                        

    await App(sound=sound).run()





if __name__ == "__main__":

    asyncio.run(main())

