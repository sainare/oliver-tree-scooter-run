# /// script
# dependencies = [
#   "pygame-ce",
# ]
# ///
"""OLIVER TREE — 8-BIT SCOOTER RUN.

Раннер на самокате в духе 8-битной консоли: выбираешь персонажа,
едешь по сцене концерта и прыгаешь через препятствия.

Управление:
    <- ->        выбор персонажа
    ENTER        подтвердить / рестарт
    ПРОБЕЛ / UP  прыжок (у Рикерсона — двойной)
    <- -> / DOWN трюки в воздухе
    P / ESC      пауза
    M            выключить звук
    F11          полный экран
"""

import asyncio
import json
import math
import os
import random
import sys

import pygame

import sprites as sp
import world as wd
from chiptune import Audio
from songs import CAT_KEYS, CAT_ORDER, CAT_LABELS, TITLES
from settings import (CANVAS_W, CANVAS_H, WIN_W, WIN_H, FPS,
                      RESUME_FRAMES,
                      CHARACTERS, TRICK_COOLDOWN, GROUND_Y, C_WHITE, C_BLACK, C_YELLOW,
                      C_GREEN, C_RED, C_ROAD, C_ROAD_HI, C_STAR,
                      C_UI_BOX, C_UI_BOX_SEL, C_UI_EDGE, TAPES, BOOST_FRAMES, ZONES)

WEB = sys.platform == "emscripten"      # игра запущена в браузере (pygbag)
if WEB:
    import platform

MENU_COLS = 3

# переход между экранами: старая картинка рассыпается на пиксельные клетки
TRANS_FRAMES = 24
TRANS_CELL = 12
_trng = random.Random(11)
_cols = -(-CANVAS_W // TRANS_CELL)
_rows = -(-CANVAS_H // TRANS_CELL)
# клетка: прямоугольник и порог, когда она открывается (волна слева направо + шум)
TRANS_CELLS = [(pygame.Rect(cx * TRANS_CELL, cy * TRANS_CELL, TRANS_CELL, TRANS_CELL),
                (cx / _cols) * 0.62 + _trng.random() * 0.38)
               for cy in range(_rows) for cx in range(_cols)]
# плитки меню: одна геометрия и для отрисовки, и для касаний
TILE_W, TILE_H, TILE_GX, TILE_GY, TILE_Y0 = 36, 36, 12, 13, 20

# логический размер окна в браузере и кнопки на нём: (центр x, центр y, радиус)
WEB_SIZE = {"landscape": (640, 360), "portrait": (360, 640)}
def button_layout(orient, width, safe_l=0, safe_r=0, scale=1.0, lefty=False):
    """safe_l / safe_r — отступы от выреза камеры в пикселях окна.

    scale — размер кнопок из настроек, lefty — прыжок слева, трюки справа."""
    if orient == "landscape":         # правые кнопки держатся правого края
        g = {"jump": (width - 85 - safe_r, 282, 62 * scale),
             "trick": (74 + safe_l, 296, 46 * scale),
             "super": (64 + safe_l, 184, 36 * scale),
             "pause": (width - 30 - safe_r, 98, 22)}
        if lefty:                     # зеркально: левая рука прыгает
            g["jump"] = (85 + safe_l, 282, 62 * scale)
            g["trick"] = (width - 74 - safe_r, 296, 46 * scale)
            g["super"] = (width - 64 - safe_r, 184, 36 * scale)
    else:
        g = {"jump": (262, 460, 84 * scale), "trick": (86, 430, 62 * scale),
             "super": (110, 566, 46 * scale), "pause": (180, 246, 26)}
        if lefty:
            g["jump"] = (98, 460, 84 * scale)
            g["trick"] = (274, 430, 62 * scale)
            g["super"] = (250, 566, 46 * scale)
    return {k: (int(x), int(y), int(r)) for k, (x, y, r) in g.items()}


def web_window():
    """Ориентация и логический размер окна под экран телефона.

    Высота в альбоме всегда 360, ширина повторяет пропорции экрана:
    канвас встаёт по центру, а по бокам остаётся место под кнопки."""
    win = platform.window
    iw, ih = max(1, int(win.innerWidth)), max(1, int(win.innerHeight))
    if ih > iw:
        return "portrait", WEB_SIZE["portrait"]
    return "landscape", (CANVAS_W * 2, 360)

# кнопки-плашки на самом канвасе (координаты канваса 320x180)
_MID = CANVAS_W // 2
MENU_START = pygame.Rect(_MID - 64, 146, 128, 22)
PAUSE_RESUME = pygame.Rect(_MID - 80, 68, 160, 21)
PAUSE_MUSIC = pygame.Rect(_MID - 80, 92, 160, 21)
PAUSE_SOUND = pygame.Rect(_MID - 80, 116, 160, 21)
PAUSE_MENU = pygame.Rect(_MID - 80, 140, 160, 21)
OVER_AGAIN = pygame.Rect(_MID - 120, 76, 108, 22)
OVER_MENU = pygame.Rect(_MID + 12, 76, 108, 22)
# главное меню, выбор персонажа и экран настроек
HOME_PLAY = pygame.Rect(_MID - 62, 62, 124, 22)
HOME_MUSIC = pygame.Rect(_MID - 62, 88, 124, 22)
HOME_SETTINGS = pygame.Rect(_MID - 62, 114, 124, 22)
SEL_MUSIC = pygame.Rect(CANVAS_W - 54, 3, 50, 14)
MENU_BACK = pygame.Rect(4, 3, 54, 14)
SET_ROWS = (("music", "МУЗЫКА"), ("sfx", "ЗВУКИ"),
            ("pick", "ВЫБОР МУЗЫКИ"), ("vibrate", "ВИБРАЦИЯ"),
            ("shake", "ТРЯСКА ЭКРАНА"), ("btn", "РАЗМЕР КНОПОК"),
            ("lefty", "РЕЖИМ ЛЕВШИ"), ("reset", "СБРОС РЕКОРДОВ"))
SET_X, SET_Y0, SET_W, SET_H, SET_STEP = _MID - 124, 18, 248, 14, 15
SET_BACK = pygame.Rect(_MID - 50, 142, 100, 18)
# экран выбора музыки: вкладки (меню, персонаж, забег, загрузка) и список из 17 строк
MUS_TAB_Y, MUS_TAB_H = 14, 13
MUS_LIST_Y, MUS_ROW_H, MUS_PER_COL = 31, 13, 9
MUS_BACK = pygame.Rect(_MID - 50, 152, 100, 18)
BTN_SIZES = (0.85, 1.0, 1.2)
BTN_SIZE_NAMES = ("МАЛЫЕ", "СРЕДНИЕ", "БОЛЬШИЕ")
DEFAULT_CFG = {"music": 8, "sfx": 8,
               # какой трек играет в каждом месте: 0 — случайный, 1..16 — по списку
               "mus_menu": 0, "mus_select": 0,
               "mus_game": CAT_KEYS["game"].index("g2") + 1,   # СОЛНЕЧНЫЙ ДЕНЬ
               "mus_load": 0,
               "vibrate": True,
               "shake": True, "btn": 1, "lefty": False}
BACKGROUND_EVENTS = tuple(getattr(pygame, n) for n in
                          ("WINDOWFOCUSLOST", "WINDOWMINIMIZED", "WINDOWHIDDEN")
                          if hasattr(pygame, n))
BUTTON_LABEL = {"jump": "ПРЫЖОК", "trick": "ТРЮК", "super": "СУПЕР",
                "pause": "II"}

# редкие звёзды на титульном экране — фиксированные, чтобы не мельтешили
_rng = random.Random(451)
TITLE_STARS = [(_rng.randrange(CANVAS_W), _rng.randrange(4, 96))
               for _ in range(34)]

# пепел на экране проигрыша: x, скорость, фаза, длина пути
ASHES = [(_rng.randrange(CANVAS_W), _rng.uniform(0.25, 0.75),
          _rng.randrange(200), _rng.randint(90, 150)) for _ in range(22)]

(STATE_TITLE, STATE_MENU, STATE_PLAY, STATE_PAUSE, STATE_OVER, STATE_SETTINGS,
 STATE_MUSIC) = range(7)
JUMP_KEYS = (pygame.K_SPACE, pygame.K_UP, pygame.K_w)
DUCK_KEYS = (pygame.K_DOWN, pygame.K_s)
TRICK_KEYS = (pygame.K_LEFT, pygame.K_RIGHT, pygame.K_a, pygame.K_d)


def _phase(age, start, dur):
    """Насколько продвинулась фаза анимации: 0 до старта, 1 после.

    Внутри — с замедлением к концу, чтобы движение не обрывалось резко.
    """
    if age <= start:
        return 0.0
    if age >= start + dur:
        return 1.0
    t = (age - start) / dur
    return 1.0 - (1.0 - t) ** 2


def data_dir():
    """Куда класть файл рекордов (рядом с exe или со скриптом)."""
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


class App:
    def __init__(self, sound=True):
        self.canvas = pygame.Surface((CANVAS_W, CANVAS_H))
        self.screen = None
        self.fullscreen = False
        self.font_big = pygame.font.Font(None, 30)
        self.font = pygame.font.Font(None, 17)
        self.font_small = pygame.font.Font(None, 14)
        self.trans = None                  # [снимок старого кадра, кадр перехода]
        self.touch_ui = WEB                # экранные кнопки и подсказки
        self.orient = "landscape"
        self.win_size = WEB_SIZE["landscape"]
        self.safe_l = self.safe_r = 0      # отступы от выреза камеры, пиксели канваса
        self.btn_geom = button_layout("landscape", self.win_size[0])
        self.pointers = {}                 # id касания -> (x, y) на экране
        self.finger_seen = False
        self.jump_ptr = None               # чем зажат прыжок
        self.btn_cache = {}
        self.view = (0.0, 0.0, 1.0)        # сдвиг x, y и масштаб канваса
        self.audio = Audio(enabled=sound, music_dir=data_dir())
        self.art = self._load_art()
        self.scores = self._load_scores()
        self.cfg = self._load_cfg()
        self.set_sel = 0                   # выбранная строка настроек (клавиатура)
        self.playlist = [CAT_KEYS["game"][0]]   # треки текущего забега
        self.mus_tab = 0                   # экран выбора музыки: вкладка
        self.mus_cur = 0                   # строка под курсором (клавиатура)
        self.mus_back = STATE_TITLE        # куда вернуться
        self.session_pick = {}             # случайный трек на сеанс: категория -> ключ
        self.track_i = 0
        self.last_first = None
        self.now_playing = None            # [название, кадров на экране]
        self.reset_armed = 0               # кадров, пока «СБРОС» ждёт подтверждения
        self.state = STATE_TITLE
        self.sel = 0
        self.world = None
        self.t = 0
        self.over_t = 0
        self.resume_t = 0
        self.running = True
        self.apply_cfg()
        self.audio.play_music(self.cat_key("menu"))
        self.audio.preload(self.cat_key("select"))   # выбор персонажа начнётся без паузы

    # --- ресурсы ---
    @staticmethod
    def _make_helis():
        right = sp.make_helicopter()
        left = [pygame.transform.flip(f, True, False) for f in right]
        return {"right": right, "left": left}

    def _load_art(self):
        zones = [wd.make_background(pal) for pal in ZONES]
        art = {
            "zones": zones,
            "menu_bg": wd.make_menu_backdrop(),
            "sky": zones[0]["sky"],          # для титульника
            "clouds": zones[0]["clouds"],
            "city": zones[0]["city"],
            "font": self.font_small,
            "riders": {c["key"]: sp.make_rider_set(c) for c in CHARACTERS},
            "portraits": {c["key"]: sp.make_portrait(c) for c in CHARACTERS},
            "faces": {c["key"]: sp.make_face(c) for c in CHARACTERS},
            "sitting": {c["key"]: sp.make_sitting(c) for c in CHARACTERS},
            "launch_ramp": sp.make_launch_ramp(),
            "helis": self._make_helis(),
            "obstacles": {
                "cone": sp.make_cone(),
                "hydrant": sp.make_hydrant(),
                "pothole": sp.make_pothole(),
                "sign": sp.make_sign(),
                "dumpster": sp.make_dumpster(),
                "spikeball": sp.make_spikeball(),
                "van": sp.make_van(),
                "ramp": sp.make_ramp(),
            },
            # на дороге — крупные кассета и звезда, в HUD — маленькие значки
            "tapes": [sp.make_tape_pickup(t["label"]) for t in TAPES],
            "star": sp.make_star(),
            "star_pickup": sp.make_star(21),
            "life": sp.scaled(sp.make_heart(True), 2),
            "balloons": sp.make_balloons(),
            "heart": sp.make_heart(True),
            "heart_off": sp.make_heart(False),
        }
        art["tape"] = sp.make_cassette(TAPES[0]["label"])   # значок счётчика в HUD
        self.audio.load_tapes(TAPES)
        return art

    def _score_path(self):
        return os.path.join(data_dir(), "highscores.json")

    def _load_scores(self):
        try:
            if WEB:
                raw = platform.window.localStorage.getItem("oliver_scores")
                data = json.loads(str(raw)) if raw else {}
            else:
                with open(self._score_path(), encoding="utf-8") as f:
                    data = json.load(f)
            return {k: int(v) for k, v in data.items()}
        except Exception:
            return {}

    def _save_scores(self):
        try:
            if WEB:
                platform.window.localStorage.setItem(
                    "oliver_scores", json.dumps(self.scores))
                return
            with open(self._score_path(), "w", encoding="utf-8") as f:
                json.dump(self.scores, f, ensure_ascii=False, indent=1)
        except Exception:
            pass                     # рекорд не сохранился — не повод падать

    # --- настройки ---
    def _load_cfg(self):
        cfg = dict(DEFAULT_CFG)
        try:
            if WEB:
                raw = platform.window.localStorage.getItem("oliver_cfg")
                data = json.loads(str(raw)) if raw else {}
            else:
                with open(os.path.join(data_dir(), "settings.json"),
                          encoding="utf-8") as f:
                    data = json.load(f)
            for k, v in data.items():
                if k in cfg and type(v) is type(cfg[k]):
                    cfg[k] = v
        except Exception:
            pass
        cfg["music"] = max(0, min(10, cfg["music"]))
        cfg["sfx"] = max(0, min(10, cfg["sfx"]))
        cfg["btn"] = max(0, min(2, cfg["btn"]))
        for cat in CAT_ORDER:
            cfg["mus_" + cat] = max(0, min(16, cfg["mus_" + cat]))
        return cfg

    def _save_cfg(self):
        try:
            if WEB:
                platform.window.localStorage.setItem(
                    "oliver_cfg", json.dumps(self.cfg))
                return
            with open(os.path.join(data_dir(), "settings.json"), "w",
                      encoding="utf-8") as f:
                json.dump(self.cfg, f, ensure_ascii=False, indent=1)
        except Exception:
            pass

    def apply_cfg(self):
        self.audio.set_levels(self.cfg["music"] / 10.0, self.cfg["sfx"] / 10.0)
        self.rebuild_buttons()
        if self.world:
            self.world.shake_on = self.cfg["shake"]

    def rebuild_buttons(self):
        self.btn_geom = button_layout(
            self.orient, self.win_size[0],
            self.safe_l * 2, self.safe_r * 2,
            BTN_SIZES[self.cfg["btn"]], self.cfg["lefty"])
        self.btn_cache.clear()

    def vibrate(self, ms):
        """Вибро-отклик: через оболочку приложения, иначе через браузер."""
        if not (WEB and self.cfg["vibrate"]):
            return
        win = platform.window
        try:
            win.OTNative.vibrate(int(ms))
        except Exception:
            try:
                win.navigator.vibrate(int(ms))
            except Exception:
                pass

    def set_row_rect(self, i):
        return pygame.Rect(SET_X, SET_Y0 + i * SET_STEP, SET_W, SET_H - 2)

    def change_setting(self, i, delta=0, absolute=None):
        """Строка настроек i: шаг по ползунку, переключение или цикл."""
        cfg = self.cfg
        key = SET_ROWS[i][0]
        if key in ("music", "sfx"):
            v = absolute if absolute is not None else cfg[key] + delta
            cfg[key] = max(0, min(10, v))
        elif key == "pick":                          # список песен: на отдельном экране
            self.open_music(0, STATE_SETTINGS)
            return
        elif key == "vibrate":
            cfg["vibrate"] = not cfg["vibrate"]
        elif key == "shake":
            cfg["shake"] = not cfg["shake"]
        elif key == "btn":
            cfg["btn"] = (cfg["btn"] + (delta or 1)) % 3
        elif key == "lefty":
            cfg["lefty"] = not cfg["lefty"]
        elif key == "reset":
            if self.reset_armed > 0:             # второй тап подряд — сбрасываем
                self.scores = {}
                self._save_scores()
                self.reset_armed = -90           # «ГОТОВО» на 1.5 секунды
                self.audio.play("over")
                return
            self.reset_armed = 180               # ждём подтверждения 3 секунды
            return
        self.apply_cfg()
        self._save_cfg()
        self.audio.play("move")
        if key == "vibrate":
            self.vibrate(60)

    # --- выбор музыки ---
    def cat_key(self, cat):
        """Трек для меню/выбора персонажа: выбранный или случайный (один на сеанс)."""
        keys = CAT_KEYS[cat]
        v = self.cfg["mus_" + cat]
        if 0 < v <= len(keys):
            return keys[v - 1]
        key = self.session_pick.get(cat)
        if key is None:
            key = self.session_pick[cat] = random.choice(keys)
        return key

    def _make_playlist(self):
        """Порядок треков забега: один выбранный или все 16 вперемешку."""
        keys = CAT_KEYS["game"]
        v = self.cfg["mus_game"]
        if 0 < v <= len(keys):
            return [keys[v - 1]]
        keys = list(keys)
        random.shuffle(keys)
        # не начинать с трека прошлого забега и с того, что звучит прямо сейчас
        # (иначе «СЛУЧАЙНО» на паузе иногда будто не срабатывает)
        avoid = (self.last_first, self.audio.desired)
        for _ in range(len(avoid)):
            if keys[0] in avoid:
                keys.append(keys.pop(0))
        self.last_first = keys[0]
        return keys

    def play_track(self, fade):
        key = self.playlist[self.track_i % len(self.playlist)]
        self.audio.play_music(key)
        self.audio.fade_in(fade)                     # трек нарастает с тишины
        if len(self.playlist) > 1:                   # следующий — готовим заранее
            self.audio.preload(self.playlist[(self.track_i + 1) % len(self.playlist)])
        self.now_playing = [TITLES[key], 240]

    def next_track(self):
        """Сменилась зона — играет следующий трек плейлиста."""
        if len(self.playlist) > 1:
            self.track_i += 1
            self.play_track(50)

    # --- текст ---
    def text(self, surf, msg, x, y, color=C_WHITE, font=None, center=False,
             shadow=True):
        """Текст с полной обводкой по контуру.

        Одной тени со смещением не хватало: на пёстром фоне буквы
        сливались с картинкой той стороной, где тени нет.
        """
        font = font or self.font
        img = font.render(msg, False, color)      # без сглаживания — пиксельно
        rect = img.get_rect()
        if center:
            rect.midtop = (x, y)
        else:
            rect.topleft = (x, y)
        if shadow:
            back = font.render(msg, False, C_BLACK)
            for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1),
                           (-1, -1), (1, -1), (-1, 1), (1, 1)):
                surf.blit(back, (rect.x + dx, rect.y + dy))
        surf.blit(img, rect)
        return rect

    def wrap(self, msg, font, width):
        """Разбить строку по словам так, чтобы влезала в заданную ширину."""
        words, lines, cur = msg.split(), [], ""
        for word in words:
            probe = (cur + " " + word).strip()
            if cur and font.size(probe)[0] > width:
                lines.append(cur)
                cur = word
            else:
                cur = probe
        if cur:
            lines.append(cur)
        return lines

    # --- действия: одни и те же для клавиш и касаний ---
    def act_jump(self):
        self.world.jump()

    def act_trick(self):
        self.world.skip_intro()
        rider = self.world.rider
        if rider.on_ground:                     # на земле — вращение
            rider.start_ground_trick(self.audio)
        else:
            rider.start_trick("tailwhip", self.audio)

    def act_super(self):
        self.world.skip_intro()
        self.world.rider.start_trick("superman", self.audio)

    def act_pause(self):
        self.state = STATE_PAUSE
        self.audio.play("pause")
        self.audio.pause_music()           # на паузе музыка молчит

    def act_resume(self):
        self.state = STATE_PLAY
        self.resume_t = RESUME_FRAMES        # обратный отсчёт
        self.audio.play("pause")
        self.audio.resume_music()

    def act_menu_pick(self, index):
        """Тап по плитке: сначала выбор, повторный тап — старт."""
        if index == self.sel:
            self.audio.play("select")
            self.start_game(self.sel)
        else:
            self.sel = index
            self.audio.play("move")

    # --- события ---
    def handle_event(self, ev):
        if ev.type == pygame.QUIT:
            self.running = False
            return
        if ev.type == pygame.VIDEORESIZE and not self.fullscreen and not WEB:
            self.screen = pygame.display.set_mode((max(ev.w, CANVAS_W),
                                                   max(ev.h, CANVAS_H)),
                                                  pygame.RESIZABLE)
            return
        if ev.type in BACKGROUND_EVENTS:
            self.on_background()               # звонок или свёрнутая вкладка
            return
        if self._pointer_event(ev):
            return
        if ev.type != pygame.KEYDOWN and ev.type != pygame.KEYUP:
            return

        if ev.type == pygame.KEYDOWN:
            if ev.key == pygame.K_F11 and not WEB:
                self.toggle_fullscreen()
                return
            if ev.key == pygame.K_m:
                self.audio.toggle_mute()
                return

        if self.state == STATE_TITLE:
            if ev.type == pygame.KEYDOWN:
                if ev.key == pygame.K_ESCAPE:
                    self.running = False
                elif ev.key == pygame.K_s:
                    self.to_settings()
                elif ev.key == pygame.K_t:
                    self.open_music(0, STATE_TITLE)
                else:                            # любая другая клавиша — играть
                    self.to_select()
        elif self.state == STATE_SETTINGS:
            self._event_settings(ev)
        elif self.state == STATE_MUSIC:
            self._event_music(ev)
        elif self.state == STATE_MENU:
            self._event_menu(ev)
        elif self.state == STATE_PLAY:
            self._event_play(ev)
        elif self.state == STATE_PAUSE:
            if ev.type == pygame.KEYDOWN and ev.key in (pygame.K_p,
                                                        pygame.K_ESCAPE):
                self.act_resume()
            elif ev.type == pygame.KEYDOWN and ev.key == pygame.K_q:
                self.to_menu()
            elif ev.type == pygame.KEYDOWN and ev.key == pygame.K_t:
                self.open_music(2, STATE_PAUSE)
        elif self.state == STATE_OVER:
            if ev.type == pygame.KEYDOWN:
                if ev.key in (pygame.K_RETURN, pygame.K_KP_ENTER,
                              pygame.K_SPACE):
                    self.start_game(self.sel)
                elif ev.key in (pygame.K_ESCAPE, pygame.K_q):
                    self.to_menu()

    def on_background(self):
        """Вкладку свернули — играющий забег встаёт на паузу."""
        if self.state == STATE_PLAY:
            self.act_pause()
        self.pointers.clear()
        self.jump_ptr = None

    def poll_shell(self):
        """Оболочка приложения сообщает о сворачивании флагом window.otBgFlag."""
        try:
            win = platform.window
            if win.otBgFlag:
                win.otBgFlag = False
                platform.window.console.log("OT_BG")
                self.on_background()
                self.audio.bg_resume()         # пауза уже стоит — музыку можно вернуть
        except Exception:
            pass

    def start_transition(self):
        """Запомнить текущий кадр: он рассыплется поверх нового экрана."""
        if self.screen is not None:
            self.trans = [self.canvas.copy(), 0]

    def to_select(self):
        self.start_transition()
        self.audio.play("select")
        self.state = STATE_MENU
        self.audio.play_music(self.cat_key("select"))

    def to_title(self):
        """Назад в главное меню (музыка главного меню)."""
        self.start_transition()
        self.audio.play("move")
        self.state = STATE_TITLE
        self.audio.play_music(self.cat_key("menu"))

    def to_settings(self):
        self.start_transition()
        self.audio.play("select")
        self.state = STATE_SETTINGS
        self.reset_armed = 0
        self.audio.play_music(self.cat_key("menu"))

    # --- экран выбора музыки ---
    def open_music(self, tab, back):
        """Список песен: tab — вкладка (0 меню, 1 персонаж, 2 забег, 3 загрузка)."""
        self.start_transition()
        self.audio.play("select")
        self.mus_tab = tab
        self.mus_back = back
        self.mus_cur = self.cfg["mus_" + CAT_ORDER[tab]]
        self.state = STATE_MUSIC
        if back == STATE_PAUSE:
            self.audio.resume_music()         # на паузе музыка молчала: для прослушивания включаем

    def close_music(self):
        self.start_transition()
        self.audio.play("move")
        back = self.mus_back
        self.state = back
        if back == STATE_PAUSE:               # музыка забега — на паузе тишина
            self.audio.play_music(self.playlist[self.track_i % len(self.playlist)])
            self.audio.pause_music()
        elif back == STATE_MENU:
            self.audio.play_music(self.cat_key("select"))
        else:
            self.audio.play_music(self.cat_key("menu"))

    def preview_key(self, cat):
        """Какой трек играть для вкладки: выбранный, а при «случайно» — любой."""
        keys = CAT_KEYS[cat]
        v = self.cfg["mus_" + cat]
        if 0 < v <= len(keys):
            return keys[v - 1]
        if cat in ("menu", "select"):
            return self.cat_key(cat)
        return random.choice(keys)

    def music_tab(self, tab):
        """Переключили вкладку: сразу играет трек этой вкладки."""
        self.mus_tab = tab % len(CAT_ORDER)
        self.mus_cur = self.cfg["mus_" + CAT_ORDER[self.mus_tab]]
        self.audio.play("move")
        self.audio.play_music(self.preview_key(CAT_ORDER[self.mus_tab]))
        self.audio.fade_in(20)

    def music_pick(self, value):
        """Выбрали песню value (0 — случайная, 1..16) на текущей вкладке."""
        cat = CAT_ORDER[self.mus_tab]
        self.cfg["mus_" + cat] = max(0, min(16, value))
        self._save_cfg()
        self.mus_cur = self.cfg["mus_" + cat]
        if cat in ("menu", "select"):
            self.session_pick.pop(cat, None)      # «случайно» выберет заново
        self.audio.play("select")
        if cat == "game" and self.world is not None:      # забег идёт: меняем его музыку
            self.playlist = self._make_playlist()
            self.track_i = 0
            self.play_track(25)
        else:
            self.audio.play_music(self.preview_key(cat))
            self.audio.fade_in(25)

    def _event_music(self, ev):
        if ev.type != pygame.KEYDOWN:
            return
        if ev.key in (pygame.K_ESCAPE, pygame.K_q):
            self.close_music()
        elif ev.key in (pygame.K_LEFT, pygame.K_a):
            self.music_tab(self.mus_tab - 1)
        elif ev.key in (pygame.K_RIGHT, pygame.K_d):
            self.music_tab(self.mus_tab + 1)
        elif ev.key in (pygame.K_UP, pygame.K_w):
            self.mus_cur = (self.mus_cur - 1) % 17
        elif ev.key in (pygame.K_DOWN, pygame.K_s):
            self.mus_cur = (self.mus_cur + 1) % 17
        elif ev.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
            self.music_pick(self.mus_cur)

    def music_tab_rect(self, i):
        tw = (CANVAS_W - 12) // len(CAT_ORDER)
        return pygame.Rect(6 + i * tw, MUS_TAB_Y, tw - 2, MUS_TAB_H)

    def music_row_rect(self, idx):
        cw = (CANVAS_W - 14) // 2
        col, row = divmod(idx, MUS_PER_COL)
        return pygame.Rect(6 + col * (cw + 2), MUS_LIST_Y + row * MUS_ROW_H,
                           cw, MUS_ROW_H - 1)

    def _press_music(self, cx, cy):
        if MUS_BACK.collidepoint(cx, cy):
            self.close_music()
            return
        for i in range(len(CAT_ORDER)):
            if self.music_tab_rect(i).inflate(2, 4).collidepoint(cx, cy):
                if i != self.mus_tab:
                    self.music_tab(i)
                return
        for idx in range(17):
            if self.music_row_rect(idx).inflate(2, 1).collidepoint(cx, cy):
                self.mus_cur = idx
                self.music_pick(idx)
                return

    def _event_settings(self, ev):
        if ev.type != pygame.KEYDOWN:
            return
        n = len(SET_ROWS)
        if ev.key in (pygame.K_ESCAPE, pygame.K_q):
            self.to_title()
        elif ev.key in (pygame.K_UP, pygame.K_w):
            self.set_sel = (self.set_sel - 1) % n
        elif ev.key in (pygame.K_DOWN, pygame.K_s):
            self.set_sel = (self.set_sel + 1) % n
        elif ev.key in (pygame.K_LEFT, pygame.K_a):
            self.change_setting(self.set_sel, -1)
        elif ev.key in (pygame.K_RIGHT, pygame.K_d):
            self.change_setting(self.set_sel, 1)
        elif ev.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
            self.change_setting(self.set_sel, 1)

    def _event_menu(self, ev):
        if ev.type != pygame.KEYDOWN:
            return
        n = len(CHARACTERS)
        if ev.key in (pygame.K_LEFT, pygame.K_a):
            self.sel = (self.sel - 1) % n
            self.audio.play("move")
        elif ev.key in (pygame.K_RIGHT, pygame.K_d):
            self.sel = (self.sel + 1) % n
            self.audio.play("move")
        elif ev.key in (pygame.K_UP, pygame.K_w):
            self.sel = (self.sel - MENU_COLS) % n
            self.audio.play("move")
        elif ev.key in (pygame.K_DOWN, pygame.K_s):
            self.sel = (self.sel + MENU_COLS) % n
            self.audio.play("move")
        elif ev.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
            self.audio.play("select")
            self.start_game(self.sel)
        elif ev.key == pygame.K_TAB:
            self.open_music(1, STATE_MENU)
        elif ev.key == pygame.K_ESCAPE:
            self.to_title()

    def _event_play(self, ev):
        rider = self.world.rider
        if ev.type == pygame.KEYDOWN:
            if ev.key in JUMP_KEYS:
                self.act_jump()
            elif ev.key in TRICK_KEYS:
                self.act_trick()
            elif ev.key in DUCK_KEYS:            # трюк, приседания больше нет
                self.act_super()
            elif ev.key in (pygame.K_p, pygame.K_ESCAPE):
                self.act_pause()
        elif ev.key in JUMP_KEYS:
            rider.release_jump()

    # --- касания и мышь ---
    def _pointer_event(self, ev):
        """Свести палец и мышь к «нажал / отпустил». True — событие съедено."""
        t = ev.type
        if t in (pygame.FINGERDOWN, pygame.FINGERUP):
            self.finger_seen = True
            self.touch_ui = True
            sw, sh = self.screen.get_size()
            pos = (ev.x * sw, ev.y * sh)
            pid = ("f", ev.finger_id)
        elif t in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP):
            if ev.button != 1:
                return False
            # браузер дублирует касание «мышью» (и раньше пальцевого события):
            # палец учитывается отдельно, поэтому такой клик пропускаем
            if getattr(ev, "touch", False):
                return True
            pos = ev.pos
            pid = "m"
        elif t == pygame.FINGERMOTION:
            return True
        else:
            return False
        if t in (pygame.FINGERDOWN, pygame.MOUSEBUTTONDOWN):
            self.pointers[pid] = pos
            self.on_press(pid, pos)
        else:
            self.pointers.pop(pid, None)
            self.on_release(pid, pos)
        return True

    def to_canvas(self, pos):
        ox, oy, k = self.view
        return ((pos[0] - ox) / k, (pos[1] - oy) / k)

    def button_at(self, pos):
        if not self.touch_ui:
            return None
        best, best_d = None, 1e9
        for name, (cx, cy, r) in self.btn_geom.items():
            d = math.hypot(pos[0] - cx, pos[1] - cy)
            if d <= r + 14 and d < best_d:            # с запасом под палец
                best, best_d = name, d
        return best

    def on_press(self, pid, pos):
        cx, cy = self.to_canvas(pos)
        if self.state == STATE_TITLE:
            if HOME_PLAY.collidepoint(cx, cy):
                self.to_select()
            elif HOME_MUSIC.collidepoint(cx, cy):
                self.open_music(0, STATE_TITLE)
            elif HOME_SETTINGS.collidepoint(cx, cy):
                self.to_settings()
        elif self.state == STATE_SETTINGS:
            self._press_settings(cx, cy)
        elif self.state == STATE_MUSIC:
            self._press_music(cx, cy)
        elif self.state == STATE_MENU:
            if MENU_BACK.collidepoint(cx, cy):
                self.to_title()
                return
            if SEL_MUSIC.collidepoint(cx, cy):
                self.open_music(1, STATE_MENU)
                return
            for i, box in enumerate(self.menu_tiles()):
                if box.inflate(6, 6).collidepoint(cx, cy):
                    self.act_menu_pick(i)
                    return
            if MENU_START.collidepoint(cx, cy):
                self.audio.play("select")
                self.start_game(self.sel)
        elif self.state == STATE_PLAY:
            if self.resume_t > 0:
                return
            name = self.button_at(pos)
            if name == "jump":
                self.jump_ptr = pid
                self.act_jump()
            elif name == "trick":
                self.act_trick()
            elif name == "super":
                self.act_super()
            elif name == "pause":
                self.act_pause()
        elif self.state == STATE_PAUSE:
            if PAUSE_RESUME.collidepoint(cx, cy):
                self.act_resume()
            elif PAUSE_MUSIC.collidepoint(cx, cy):
                self.open_music(2, STATE_PAUSE)
            elif PAUSE_SOUND.collidepoint(cx, cy):
                self.audio.toggle_mute()
            elif PAUSE_MENU.collidepoint(cx, cy):
                self.to_menu()
        elif self.state == STATE_OVER:
            if self.over_t > 194:
                if OVER_AGAIN.collidepoint(cx, cy):
                    self.start_game(self.sel)
                elif OVER_MENU.collidepoint(cx, cy):
                    self.to_menu()

    def _press_settings(self, cx, cy):
        if SET_BACK.collidepoint(cx, cy):
            self.to_title()
            return
        for i in range(len(SET_ROWS)):
            r = self.set_row_rect(i)
            if not r.inflate(4, 2).collidepoint(cx, cy):
                continue
            self.set_sel = i
            if SET_ROWS[i][0] in ("music", "sfx"):
                bar_x = r.right - 84
                if cx < r.right - 108:                   # подпись строки: только выбор
                    return
                if cx < bar_x - 2:                       # левее ползунка — минус
                    self.change_setting(i, -1)
                elif cx > bar_x + 62:                    # правее — плюс
                    self.change_setting(i, 1)
                else:                                    # по самому ползунку
                    self.change_setting(i, absolute=int((cx - bar_x) // 6) + 1)
            else:
                self.change_setting(i, 1)
            return

    def on_release(self, pid, pos):
        if pid == self.jump_ptr:
            self.jump_ptr = None
            if self.state == STATE_PLAY and self.world:
                self.world.rider.release_jump()

    def menu_tiles(self):
        cols = MENU_COLS
        x0 = (CANVAS_W - (cols * TILE_W + (cols - 1) * TILE_GX)) // 2
        return [pygame.Rect(x0 + (i % cols) * (TILE_W + TILE_GX),
                            TILE_Y0 + (i // cols) * (TILE_H + TILE_GY),
                            TILE_W, TILE_H)
                for i in range(len(CHARACTERS))]

    # --- переходы ---
    def start_game(self, index):
        self.start_transition()
        char = CHARACTERS[index]
        best = self.scores.get(char["key"], 0)
        self.world = wd.World(char, self.art, self.audio, best=best)
        self.world.haptic = self.vibrate
        self.world.shake_on = self.cfg["shake"]
        self.world.on_zone = self.next_track
        self.playlist = self._make_playlist()
        self.track_i = 0
        self.state = STATE_PLAY
        self.resume_t = 0
        self.jump_ptr = None
        self.play_track(wd.INTRO_DARK)           # трек нарастает вместе со светом

    def to_menu(self):
        self.start_transition()
        self.state = STATE_MENU
        self.world = None
        self.resume_t = 0          # иначе новый забег стартует замороженным
        self.jump_ptr = None
        self.audio.play_music(self.cat_key("select"))

    def toggle_fullscreen(self):
        self.fullscreen = not self.fullscreen
        if self.fullscreen:
            self.screen = pygame.display.set_mode(
                (0, 0), pygame.FULLSCREEN | pygame.SCALED)
        else:
            self.screen = pygame.display.set_mode(
                (WIN_W, WIN_H), pygame.RESIZABLE)

    # --- логика ---
    def update(self):
        self.t += 1
        self.audio.tick()
        if self.reset_armed > 0:
            self.reset_armed -= 1
        elif self.reset_armed < 0:
            self.reset_armed += 1
        if self.trans:
            self.trans[1] += 1
            if self.trans[1] >= TRANS_FRAMES:
                self.trans = None
        if self.state == STATE_OVER:
            self.over_t += 1
        if self.state != STATE_PLAY:
            return
        if self.resume_t > 0:            # после паузы даём собраться
            self.resume_t -= 1
            return
        w = self.world
        if self.now_playing and self.now_playing[1] > 0:
            self.now_playing[1] -= 1
        w.update()
        if w.rider.dead and w.speed <= 0.01:
            key = w.rider.char["key"]
            if w.score > self.scores.get(key, 0):
                self.scores[key] = w.score
                self._save_scores()
            self.state = STATE_OVER
            self.over_t = 0
            self.audio.play_music("over")        # печальный трек на проигрыш

    # --- отрисовка ---
    def draw(self):
        c = self.canvas
        if self.state == STATE_TITLE:
            self._draw_title(c)
        elif self.state == STATE_SETTINGS:
            self._draw_settings(c)
        elif self.state == STATE_MUSIC:
            self._draw_music(c)
        elif self.state == STATE_MENU:
            self._draw_menu(c)
        else:
            self.world.draw(c)
            self._draw_hud(c)
            if self.state == STATE_PAUSE:
                self._draw_pause(c)
            elif self.state == STATE_OVER:
                self._draw_over(c)
            elif self.resume_t > 0:
                self._draw_resume(c)
        if self.trans:
            self._draw_transition(c)

    def _draw_transition(self, c):
        """Старый кадр держится только на клетках, которые ещё не открылись."""
        snap, t = self.trans
        p = t / float(TRANS_FRAMES)
        edge = []
        for rect, th in TRANS_CELLS:
            if th > p:
                c.blit(snap, rect.topleft, rect)
            elif th > p - 0.06:                 # свежеоткрытая клетка — светлая кромка
                edge.append(rect)
        for rect in edge:
            c.fill((255, 232, 150), pygame.Rect(rect.x + 3, rect.y + 3, 6, 6))

    def _dim(self, surf, alpha=170):
        veil = pygame.Surface((CANVAS_W, CANVAS_H), pygame.SRCALPHA)
        veil.fill((10, 5, 18, alpha))
        surf.blit(veil, (0, 0))

    def _draw_title(self, c, prompt=True):
        """Титульный экран: логотип, огонь по низу и мигающее PRESS START."""
        for y in range(CANVAS_H):                 # тёмное небо с градиентом
            t = y / CANVAS_H
            c.fill((int(18 + 40 * t), int(10 + 14 * t), int(38 + 30 * t)),
                   pygame.Rect(0, y, CANVAS_W, 1))
        for i, (sx, sy) in enumerate(TITLE_STARS):
            if (self.t // 10 + i) % 5:
                c.fill(C_WHITE, pygame.Rect(sx, sy, 1, 1))

        wobble = int(math.sin(self.t * 0.07) * 2)
        self.text(c, "OLIVER TREE", CANVAS_W // 2, 22 + wobble, C_YELLOW,
                  self.font_big, center=True)
        self.text(c, "8-BIT SCOOTER RUN", CANVAS_W // 2, 46, C_STAR,
                  self.font, center=True)

        rider = self.art["riders"][CHARACTERS[self.sel]["key"]]["run"]
        img = rider[(self.t // 6) % 4]
        rx = (self.t * 1.6) % (CANVAS_W + 60) - 40
        c.blit(img, (int(rx), 104 - img.get_height() + 4))

        wd.draw_flames(c, self.t, CANVAS_H - 6, 34)

        if not prompt:                   # заставка оболочки без подсказок
            return
        self.plate(c, HOME_PLAY, "ИГРАТЬ", C_YELLOW)
        self.plate(c, HOME_MUSIC, "МУЗЫКА", C_WHITE)
        self.plate(c, HOME_SETTINGS, "НАСТРОЙКИ", C_WHITE)
        if not self.touch_ui:
            self.text(c, "ENTER - ИГРАТЬ   T - МУЗЫКА   S - НАСТРОЙКИ   ESC - ВЫХОД",
                      CANVAS_W // 2, 140, C_WHITE, self.font_small,
                      center=True)

    def _draw_settings(self, c):
        """Настройки: ползунки громкости, переключатели, размер кнопок."""
        for y in range(CANVAS_H):
            t = y / CANVAS_H
            c.fill((int(18 + 40 * t), int(10 + 14 * t), int(38 + 30 * t)),
                   pygame.Rect(0, y, CANVAS_W, 1))
        for i, (sx, sy) in enumerate(TITLE_STARS):
            if (self.t // 10 + i) % 5:
                c.fill(C_WHITE, pygame.Rect(sx, sy, 1, 1))
        self.text(c, "НАСТРОЙКИ", CANVAS_W // 2, 2, C_YELLOW, self.font,
                  center=True)
        cfg = self.cfg
        for i, (key, label) in enumerate(SET_ROWS):
            r = self.set_row_rect(i)
            sel = (i == self.set_sel and not self.touch_ui)
            c.fill(C_YELLOW if sel else (78, 62, 108), r.inflate(2, 2))
            c.fill((30, 20, 48), r)
            self.text(c, label, r.x + 6, r.y + 2,
                      C_YELLOW if sel else C_WHITE, self.font_small)
            if key in ("music", "sfx"):                   # ползунок из 10 делений
                val = cfg[key]
                for bx, txt in ((r.right - 102, "-"), (r.right - 18, "+")):
                    box = pygame.Rect(bx, r.y + 1, 14, r.h - 2)
                    c.fill((70, 56, 98), box)
                    self.text(c, txt, box.centerx - 2, box.y + 1, C_WHITE,
                              self.font_small, shadow=False)
                bar_x = r.right - 84
                for k in range(10):
                    c.fill(C_STAR if k < val else (60, 48, 84),
                           pygame.Rect(bar_x + k * 6, r.y + 3, 5, r.h - 6))
                continue
            on_off = ("ВКЛ", C_GREEN), ("ВЫКЛ", C_RED)
            if key in ("vibrate", "shake", "lefty"):
                txt, col = on_off[0 if cfg[key] else 1]
            elif key == "btn":
                txt, col = BTN_SIZE_NAMES[cfg["btn"]], C_STAR
            elif key == "pick":
                txt, col = "ОТКРЫТЬ >", C_STAR
            else:                                         # сброс рекордов
                if self.reset_armed > 0:
                    txt, col = "ТОЧНО? ЕЩЁ ТАП", C_RED
                elif self.reset_armed < 0:
                    txt, col = "ГОТОВО", C_GREEN
                else:
                    txt, col = "ТАП", (200, 190, 220)
            w = self.font_small.size(txt)[0]
            self.text(c, txt, r.right - 8 - w, r.y + 2, col, self.font_small)
        self.plate(c, SET_BACK, "НАЗАД", C_YELLOW)

    def _draw_music(self, c):
        """Выбор песен: вкладки по местам, в каждой — случайная и 16 треков."""
        for y in range(CANVAS_H):
            t = y / CANVAS_H
            c.fill((int(18 + 40 * t), int(10 + 14 * t), int(38 + 30 * t)),
                   pygame.Rect(0, y, CANVAS_W, 1))
        for i, (sx, sy) in enumerate(TITLE_STARS):
            if (self.t // 10 + i) % 5:
                c.fill(C_WHITE, pygame.Rect(sx, sy, 1, 1))
        self.text(c, "ВЫБОР МУЗЫКИ", CANVAS_W // 2, 2, C_YELLOW, self.font,
                  center=True)
        for i, cat in enumerate(CAT_ORDER):
            r = self.music_tab_rect(i)
            on = i == self.mus_tab
            c.fill(C_YELLOW if on else (78, 62, 108), r.inflate(2, 2))
            c.fill((86, 60, 24) if on else (30, 20, 48), r)
            self.text(c, CAT_LABELS[cat], r.centerx, r.y + 2,
                      C_YELLOW if on else C_WHITE, self.font_small, center=True)
        cat = CAT_ORDER[self.mus_tab]
        keys = CAT_KEYS[cat]
        chosen = self.cfg["mus_" + cat]
        for idx in range(17):
            r = self.music_row_rect(idx)
            kb = idx == self.mus_cur and not self.touch_ui
            c.fill(C_YELLOW if kb else (78, 62, 108), r.inflate(2, 2))
            c.fill((34, 84, 48) if idx == chosen else (30, 20, 48), r)
            label = "СЛУЧАЙНО" if idx == 0 else "%d. %s" % (idx, TITLES[keys[idx - 1]])
            if idx == chosen:
                label = "> " + label
            self.text(c, label, r.x + 4, r.y + 2,
                      C_GREEN if idx == chosen else C_WHITE, self.font_small)
        self.plate(c, MUS_BACK, "НАЗАД", C_YELLOW)

    def _draw_menu(self, c):
        """Экран выбора: сетка плиток с лицами, как на экране шоу."""
        c.blit(self.art["menu_bg"], (0, 0))
        wd.draw_spotlights(c, self.t)

        # на узком канвасе крупный заголовок наезжал бы на кнопки по углам
        self.text(c, "ВЫБЕРИ ПЕРСОНАЖА", CANVAS_W // 2,
                  1 if CANVAS_W >= 380 else 4, C_WHITE,
                  self.font_big if CANVAS_W >= 380 else self.font, center=True)
        if self.touch_ui:
            self.plate(c, MENU_BACK, "< НАЗАД", C_WHITE)
        self.plate(c, SEL_MUSIC, "ПЕСНИ", C_WHITE)

        cols = MENU_COLS
        bw, bh = 36, 36
        gx, gy = 12, 13                       # по вертикали — место под имя
        x0 = (CANVAS_W - (cols * bw + (cols - 1) * gx)) // 2
        y0 = 20

        for i, ch in enumerate(CHARACTERS):
            bx = x0 + (i % cols) * (bw + gx)
            by = y0 + (i // cols) * (bh + gy)
            picked = (i == self.sel)
            box = pygame.Rect(bx, by, bw, bh)
            c.fill(C_UI_EDGE, box.inflate(4, 4))
            c.fill(C_UI_BOX_SEL if picked else C_UI_BOX, box)
            face = self.art["faces"][ch["key"]]
            c.blit(face, (bx + (bw - face.get_width()) // 2, by + 5))
            if picked and (self.t // 8) % 2 == 0:
                pygame.draw.rect(c, C_YELLOW, box.inflate(8, 8), 2)
            self.text(c, ch.get("short", ch["name"]), bx + bw // 2,
                      by + bh + 2, C_YELLOW if picked else C_WHITE,
                      self.font_small, center=True)

        # ниже сетки места мало, поэтому имя и рекорд идут одной строкой
        ch = CHARACTERS[self.sel]
        y = 120
        for line in self.wrap(ch["note"], self.font_small, CANVAS_W - 16):
            self.text(c, line, CANVAS_W // 2, y, C_WHITE,
                      self.font_small, center=True)
            y += 11
        best = self.scores.get(ch["key"], 0)
        self.text(c, f'{ch["name"]}   РЕКОРД {best}', CANVAS_W // 2, y + 2,
                  C_STAR, self.font_small, center=True)
        if self.touch_ui:
            self.plate(c, MENU_START, "СТАРТ", C_YELLOW)
            self.text(c, "ТАП ПО ПЕРСОНАЖУ - ВЫБОР, ЕЩЁ ТАП - СТАРТ",
                      CANVAS_W // 2, 170, C_WHITE, self.font_small,
                      center=True)
        else:
            if (self.t // 20) % 2 == 0:
                self.text(c, "PRESS START", CANVAS_W // 2, 154, C_WHITE,
                          self.font, center=True)
            self.text(c, "СТРЕЛКИ - ВЫБОР    ENTER - СТАРТ",
                      CANVAS_W // 2, 168, C_WHITE, self.font_small,
                      center=True)

    def _draw_resume(self, c):
        """Обратный отсчёт после паузы, чтобы не влететь в препятствие."""
        left = self.resume_t // FPS + 1
        self._dim(c, 90)
        step = self.resume_t % FPS                 # цифра «вдыхает» каждую сек.
        color = C_STAR if step > FPS // 2 else C_WHITE
        self.text(c, str(left), CANVAS_W // 2, 56, color,
                  self.font_big, center=True)
        self.text(c, "ПРИГОТОВЬСЯ", CANVAS_W // 2, 88, C_WHITE,
                  self.font, center=True)

    def _draw_hud(self, c):
        w = self.world
        sl, sr = self.safe_l, self.safe_r
        for i in range(max(3, w.rider.lives)):
            img = self.art["heart"] if i < w.rider.lives else self.art["heart_off"]
            c.blit(img, (6 + sl + i * 12, 6))
        score = f"{w.score:06d}"
        self.text(c, score, CANVAS_W - 6 - sr - self.font.size(score)[0], 5,
                  C_WHITE)
        c.blit(self.art["tape"], (CANVAS_W // 2 - 18, 5))
        self.text(c, f"x{w.tapes}", CANVAS_W // 2 - 2, 6, C_YELLOW)
        if w.best:
            best = f"BEST {w.best}"
            self.text(c, best, CANVAS_W - 6 - sr
                      - self.font_small.size(best)[0], 18,
                      (188, 176, 210), self.font_small)
        if self.now_playing and self.now_playing[1] > 0:
            self.text(c, "ТРЕК: " + self.now_playing[0], CANVAS_W // 2, 19,
                      (255, 190, 226), self.font_small, center=True)
        if w.rider.boost > 0:                 # обратный отсчёт неуязвимости
            left = w.rider.boost / BOOST_FRAMES
            c.blit(self.art["star"], (6 + sl, 18))
            c.fill(C_BLACK, pygame.Rect(18 + sl, 21, 42, 5))
            c.fill(C_STAR, pygame.Rect(19 + sl, 22, int(40 * left), 3))
            self.text(c, f"{w.rider.boost // 60 + 1}", 63 + sl, 18, C_STAR,
                      self.font_small)
        elif self.audio.muted:
            self.text(c, "MUTE", 6 + sl, 20, (200, 120, 120), self.font_small)

    def _draw_pause(self, c):
        self._dim(c)
        self.text(c, "ПАУЗА", CANVAS_W // 2, 44 if self.touch_ui else 66,
                  C_YELLOW, self.font_big, center=True)
        if self.touch_ui:
            self.plate(c, PAUSE_RESUME, "ПРОДОЛЖИТЬ", C_YELLOW)
            self.plate(c, PAUSE_MUSIC, "МУЗЫКА", C_WHITE)
            self.plate(c, PAUSE_SOUND,
                       "ЗВУК: ВЫКЛ" if self.audio.muted else "ЗВУК: ВКЛ",
                       C_WHITE)
            self.plate(c, PAUSE_MENU, "В МЕНЮ", C_WHITE)
            return
        self.text(c, "P - ПРОДОЛЖИТЬ", CANVAS_W // 2, 98, C_WHITE,
                  self.font, center=True)
        self.text(c, "T - МУЗЫКА", CANVAS_W // 2, 114, (190, 180, 210),
                  self.font_small, center=True)
        self.text(c, "Q - В МЕНЮ", CANVAS_W // 2, 128, (190, 180, 210),
                  self.font_small, center=True)

    def _draw_over(self, c):
        """Финал ставится по фазам, а не проявляется целиком из черноты.

        Огонь расходится от центра -> проступает силуэт -> по одной падают
        буквы -> накручивается счёт -> всплывают итоги и шары.
        """
        w = self.world
        age = self.over_t
        cx = CANVAS_W // 2
        ground = 174
        c.fill((6, 5, 10))

        # 1. огонь занимается в центре и расходится к краям
        lit = _phase(age, 0, 52)
        if lit > 0:
            half = int((cx + 26) * lit)
            wd.draw_fire_glow(c, self.t, cx, CANVAS_H - 40)
            keep = c.get_clip()
            c.set_clip(pygame.Rect(cx - half, 0, half * 2, CANVAS_H))
            dying = max(0.55, 1.0 - max(0, age - 200) / 1100.0)
            wd.draw_flames(c, self.t, CANVAS_H - 2, int(72 * dying * lit))
            c.set_clip(keep)

        # 2. пепел — только когда уже разгорелось
        if age > 46:
            for ax0, speed, phase, span in ASHES:
                life = (self.t * speed + phase) % span
                ay = CANVAS_H - 6 - life
                if ay < 30:
                    continue
                drift = math.sin((life + phase) * 0.06) * 6
                fade = 1.0 - life / span
                shade = int(250 * fade * fade)
                if shade < 25:
                    continue
                c.fill((shade, int(shade * 0.55), int(shade * 0.2)),
                       pygame.Rect(int(ax0 + drift) % CANVAS_W, int(ay), 1, 1))

        # 3. силуэт проступает из темноты
        BACKLIT = (150, 138, 156)
        K = 2
        seen = _phase(age, 28, 46)
        sx = cx - (sp.SIT_W + 2) * K // 2
        sy = ground - (sp.SIT_H + 2) * K
        if seen > 0:
            sit = sp.scaled(self.art["sitting"][w.rider.char["key"]], K).copy()
            tint = tuple(int(v * seen) for v in BACKLIT)
            sit.fill(tint, special_flags=pygame.BLEND_RGB_MULT)
            bow = min(3, max(0, age - 200) // 90)      # плечи оседают позже
            c.blit(sit, (sx, sy + bow))

        # 4. шары всплывают снизу и переходят в медленное парение
        rise = _phase(age, 62, 50)
        if rise > 0:
            bal = sp.scaled(self.art["balloons"], K).copy()
            tint = tuple(int(v * rise) for v in BACKLIT)
            bal.fill(tint, special_flags=pygame.BLEND_RGB_MULT)
            # всплыли к кулаку и застыли: дальше связка не шевелится
            lift = (1.0 - rise) * 34
            hand_x = sx + sp.SIT_HAND[0] * K
            hand_y = sy + sp.SIT_HAND[1] * K
            c.blit(bal, (hand_x - sp.BALLOON_ANCHOR[0] * K,
                         int(hand_y - sp.BALLOON_ANCHOR[1] * K + lift)))

        # 5. буквы GAME OVER падают сверху по одной и отскакивают
        title = "GAME OVER"
        widths = [self.font_big.size(t)[0] for t in title]
        tx = cx - sum(widths) // 2
        landed_now = False
        for i, glyph in enumerate(title):
            start = 56 + i * 4
            p = _phase(age, start, 18)
            if p > 0:
                dy = int(-52 * (1.0 - p) ** 2)
                if 0.80 < p < 1.0:                    # короткий отскок
                    dy += int(math.sin((p - 0.80) / 0.20 * math.pi) * 3)
                if age - (start + 18) in (0, 1):
                    landed_now = True
                self.text(c, glyph, tx, 6 + dy, C_RED, self.font_big)
            tx += widths[i]

        # от удара последней буквы сцену коротко встряхивает
        if landed_now:
            c.scroll(0, 1)

        # 6. счёт накручивается, следом проступают итоги
        cnt = _phase(age, 108, 46)
        if cnt > 0:
            self.text(c, f"СЧЁТ  {int(w.score * cnt)}", cx, 30,
                      C_WHITE, self.font, center=True)
        if _phase(age, 156, 1) > 0:
            self.text(c, f"КАССЕТ {w.tapes}   САЛЬТО {w.flips}   "
                         f"ТРЮКОВ {w.tricks}   ЗВЁЗД {w.stars}",
                      cx, 45, C_STAR, self.font_small, center=True)
        if _phase(age, 174, 1) > 0:
            best = self.scores.get(w.rider.char["key"], 0)
            if w.score >= best and w.score > 0:
                blink = C_GREEN if (self.t // 12) % 2 else C_YELLOW
                self.text(c, "НОВЫЙ РЕКОРД!", cx, 57, blink,
                          self.font_small, center=True)
            else:
                self.text(c, f"РЕКОРД {best}", cx, 57, (150, 142, 160),
                          self.font_small, center=True)
        if age > 194 and self.touch_ui:
            self.plate(c, OVER_AGAIN, "ЕЩЁ РАЗ", C_YELLOW)
            self.plate(c, OVER_MENU, "В МЕНЮ", C_WHITE)
        elif age > 194 and (self.t // 18) % 2 == 0:
            self.text(c, "ENTER - ЕЩЁ РАЗ    ESC - В МЕНЮ", cx, 70,
                      C_WHITE, self.font_small, center=True)

    def plate(self, c, rect, label, color):
        """Кнопка-плашка для касаний на самом канвасе."""
        c.fill(C_UI_EDGE, rect.inflate(2, 2))
        c.fill((30, 20, 48), rect)
        c.fill(color, pygame.Rect(rect.x, rect.y, rect.w, 1))
        self.text(c, label, rect.centerx, rect.y + 6, color,
                  self.font_small, center=True)

    def button_image(self, name, pressed):
        """Полупрозрачная круглая кнопка; собирается один раз и кэшируется."""
        key = (name, self.orient, pressed)
        img = self.btn_cache.get(key)
        if img is None:
            r = self.btn_geom[name][2]
            img = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
            base = (252, 214, 60) if name == "jump" else (250, 250, 252)
            alpha = 150 if pressed else 78
            pygame.draw.circle(img, (*base, alpha), (r, r), r)
            pygame.draw.circle(img, (*base, 210), (r, r), r, 3)
            if name == "pause":
                for dx in (-5, 3):
                    pygame.draw.rect(img, (250, 250, 252, 230),
                                     (r + dx, r - 8, 4, 16))
            else:
                font = pygame.font.Font(None, max(20, int(r * 0.5)))
                txt = font.render(BUTTON_LABEL[name], True, (250, 250, 252))
                shade = font.render(BUTTON_LABEL[name], True, (18, 14, 28))
                pos = txt.get_rect(center=(r, r))
                img.blit(shade, pos.move(1, 2))
                img.blit(txt, pos)
            self.btn_cache[key] = img
        return img

    def draw_buttons(self):
        """Экранные кнопки поверх картинки: только пока идёт забег."""
        if not self.touch_ui or self.state != STATE_PLAY or self.resume_t > 0:
            return
        held = {self.button_at(p) for p in self.pointers.values()}
        cd = self.world.rider.trick_cd
        for name, (cx, cy, r) in self.btn_geom.items():
            img = self.button_image(name, name in held)
            self.screen.blit(img, (cx - r, cy - r))
            if cd > 0 and name in ("trick", "super"):
                self._draw_cooldown(cx, cy, r, cd / float(TRICK_COOLDOWN))

    def _draw_cooldown(self, cx, cy, r, left):
        """Кнопка «заряжается»: тёмный сектор по часовой стрелке и секунды."""
        veil = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
        pts = [(r, r)]
        steps = max(3, int(40 * left))
        for i in range(steps + 1):
            a = 2 * math.pi * left * i / steps
            pts.append((r + r * math.sin(a), r - r * math.cos(a)))
        pygame.draw.polygon(veil, (10, 6, 22, 170), pts)
        self.screen.blit(veil, (cx - r, cy - r))
        font = pygame.font.Font(None, max(20, int(r * 0.7)))
        txt = font.render("%.1f" % (left * TRICK_COOLDOWN / FPS), True, (250, 250, 252))
        self.screen.blit(txt, txt.get_rect(center=(cx, cy)))

    def present(self):
        """Растянуть канвас и отцентровать с полями.

        На компьютере масштаб целый — пиксели остаются чёткими. В браузере
        на телефоне экран мал, там канвас тянется во всю ширину (или
        в портрете прижат к верху, а снизу остаётся место под кнопки)."""
        sw, sh = self.screen.get_size()
        if WEB and self.orient == "portrait":
            k = sw / CANVAS_W
            w, h = sw, int(CANVAS_H * k)
            self.view = (0.0, 0.0, k)
            self.screen.fill((10, 5, 18))
            self.screen.blit(pygame.transform.scale(self.canvas, (w, h)),
                             (0, 0))
        else:
            k = max(1, min(sw // CANVAS_W, sh // CANVAS_H))
            w, h = CANVAS_W * k, CANVAS_H * k
            ox, oy = (sw - w) // 2, (sh - h) // 2
            self.view = (float(ox), float(oy), float(k))
            if (w, h) != (sw, sh):
                self.screen.fill((0, 0, 0))
            self.screen.blit(pygame.transform.scale(self.canvas, (w, h)),
                             (ox, oy))
        self.draw_buttons()
        pygame.display.flip()

    # --- окно ---
    def read_safe_area(self):
        """Вырез камеры: оболочка сообщает отступы в window.OT_SAFE_L/R."""
        if not WEB or self.orient != "landscape":
            return 0, 0
        try:
            win = platform.window
            k = CANVAS_W / max(1.0, float(win.innerWidth))
            left = float(win.OT_SAFE_L or 0) * k
            right = float(win.OT_SAFE_R or 0) * k
            return (int(left) + 3 if left else 0), (int(right) + 3 if right else 0)
        except Exception:
            return 0, 0

    def make_display(self):
        if WEB:
            self.orient, self.win_size = web_window()
            self.safe_l, self.safe_r = self.read_safe_area()
            self.rebuild_buttons()
            return pygame.display.set_mode(self.win_size)
        return pygame.display.set_mode((WIN_W, WIN_H), pygame.RESIZABLE)

    def check_orientation(self):
        """Телефон повернули — пересобрать окно под новую ориентацию."""
        if (web_window() != (self.orient, self.win_size)
                or self.read_safe_area() != (self.safe_l, self.safe_r)):
            self.screen = self.make_display()
            self.pointers.clear()
            self.jump_ptr = None

    # --- цикл ---
    async def run(self):
        self.screen = self.make_display()
        pygame.display.set_caption("Oliver Tree — 8-bit Scooter Run")
        clock = pygame.time.Clock()
        step = 1000.0 / FPS
        acc, last, frame = 0.0, pygame.time.get_ticks(), 0
        while self.running:
            for ev in pygame.event.get():
                self.handle_event(ev)
            # шаг физики фиксирован: если кадр вышел долгим (слабый
            # телефон), игра догоняет несколькими апдейтами подряд
            now = pygame.time.get_ticks()
            acc += min(now - last, 100)
            last = now
            n = 0
            while acc >= step and n < 3:
                self.update()
                acc -= step
                n += 1
            if n == 3:
                acc = 0.0
            self.draw()
            self.present()
            frame += 1
            if WEB and frame % 30 == 0:
                self.check_orientation()
            if WEB and frame % 3 == 0:
                self.poll_shell()
            if WEB and frame == 2:
                platform.window.console.log("OT_READY")   # оболочка убирает заставку
                try:
                    platform.window.otReady()                 # то же для веб-страницы
                except Exception:
                    pass
            clock.tick(FPS)
            await asyncio.sleep(0)
        pygame.quit()




async def main():
    # в браузере маленький буфер даёт треск и заикание: берём побольше
    pygame.mixer.pre_init(44100, -16, 2, 2048 if WEB else 512)
    pygame.init()
    try:
        pygame.mixer.init()
        sound = True
    except pygame.error:
        sound = False                # без звуковой карты игра всё равно идёт
    await App(sound=sound).run()


if __name__ == "__main__":
    asyncio.run(main())
