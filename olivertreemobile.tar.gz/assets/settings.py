"""Общие настройки, палитра и описания персонажей."""

# --- экран -------------------------------------------------------------
import sys


def _canvas_width():
    """Ширина сцены: 320, а на вытянутом экране телефона — шире.

    Высота остаётся 180, ширина повторяет пропорции экрана, чтобы игра
    занимала весь экран без чёрных полос по бокам."""
    if sys.platform == "emscripten":
        try:
            import platform
            w, h = platform.window.innerWidth, platform.window.innerHeight
            if w > h:
                return max(320, min(426, round(180 * w / h / 2) * 2))
        except Exception:
            pass
    return 320


CANVAS_W, CANVAS_H = _canvas_width(), 180   # внутреннее «8-битное» разрешение
SCALE = 3                          # во сколько раз растягиваем на окно
WIN_W, WIN_H = CANVAS_W * SCALE, CANVAS_H * SCALE
FPS = 60

GROUND_Y = 148                     # линия асфальта на канвасе
PLAYER_X = 54                      # игрок стоит на месте по X

# --- цвета сцены (яркий дневной 8-бит, как на экране шоу) --------------
C_SKY_TOP = (52, 146, 226)
C_SKY_BOT = (136, 208, 242)
C_CLOUD = (250, 252, 255)
C_CLOUD_SH = (198, 220, 244)
C_CITY = (72, 126, 202)
C_CITY_DARK = (56, 104, 176)
C_CITY_WIN = (126, 172, 228)
C_TREE = (54, 168, 78)
C_TREE_DARK = (28, 116, 54)
C_TRUNK = (124, 76, 42)
# асфальт чёрный во всех зонах; цвет зоны остаётся только на кромке
C_ROAD = (26, 24, 30)
C_ROAD_HI = (248, 146, 198)
C_ROAD_DARK = (13, 12, 16)
C_ROAD_LINE = (250, 244, 226)
C_WHITE = (250, 250, 252)
C_BLACK = (18, 14, 28)
C_YELLOW = (252, 214, 60)
C_PINK = (255, 96, 160)
C_CYAN = (90, 230, 230)
C_RED = (232, 60, 72)
C_GREEN = (110, 220, 110)
C_UI_BOX = (226, 46, 58)          # красные плитки выбора персонажа
C_UI_BOX_SEL = (250, 238, 210)    # выбранная — светлая
C_UI_EDGE = (250, 250, 252)
C_STAR = (252, 226, 110)          # звезда-буст и её надпись

# --- зоны: окружение меняется по ходу забега ---------------------------
ZONE_SCORE = 1200                 # через столько очков окружение сменится
ZONE_FX_FRAMES = 54               # длительность анимации перехода
ZONES = [
    dict(name="ДЕНЬ", backdrop="city", scenery="tree",
         sky_top=C_SKY_TOP, sky_bot=C_SKY_BOT,
         cloud=C_CLOUD, cloud_sh=C_CLOUD_SH,
         city=C_CITY, city_dark=C_CITY_DARK, city_win=C_CITY_WIN,
         tree=C_TREE, tree_dark=C_TREE_DARK, trunk=C_TRUNK,
         road=C_ROAD, road_hi=C_ROAD_HI, road_dark=C_ROAD_DARK,
         stars=False),
    dict(name="ЗАКАТ", backdrop="mesas", scenery="palm",
         sky_top=(120, 62, 148), sky_bot=(250, 176, 108),
         cloud=(254, 216, 190), cloud_sh=(216, 146, 148),
         city=(96, 66, 138), city_dark=(72, 48, 108), city_win=(250, 208, 130),
         tree=(56, 118, 92), tree_dark=(30, 74, 66), trunk=(96, 58, 42),
         road=C_ROAD, road_hi=(240, 128, 168), road_dark=C_ROAD_DARK,
         stars=False),
    dict(name="НОЧЬ", backdrop="mountains", scenery="pine",
         sky_top=(16, 14, 52), sky_bot=(64, 48, 116),
         cloud=(178, 184, 224), cloud_sh=(120, 126, 176),
         city=(42, 38, 88), city_dark=(28, 26, 66), city_win=(252, 228, 140),
         tree=(34, 92, 62), tree_dark=(18, 56, 40), trunk=(72, 46, 32),
         road=C_ROAD, road_hi=(196, 96, 156), road_dark=C_ROAD_DARK,
         stars=True),
    dict(name="РАССВЕТ", backdrop="hills", scenery="tree",
         sky_top=(96, 132, 206), sky_bot=(252, 206, 172),
         cloud=(255, 236, 224), cloud_sh=(214, 172, 178),
         city=(110, 122, 178), city_dark=(84, 94, 148), city_win=(250, 232, 190),
         tree=(78, 158, 104), tree_dark=(42, 104, 72), trunk=(114, 72, 42),
         road=C_ROAD, road_hi=(252, 186, 202), road_dark=C_ROAD_DARK,
         stars=False),
    dict(name="ГРОЗА", backdrop="factory", scenery="pine",
         sky_top=(48, 54, 74), sky_bot=(126, 134, 152),
         cloud=(206, 210, 222), cloud_sh=(142, 148, 166),
         city=(64, 72, 96), city_dark=(46, 52, 72), city_win=(206, 214, 236),
         tree=(46, 104, 78), tree_dark=(24, 62, 50), trunk=(76, 54, 38),
         road=C_ROAD, road_hi=(198, 134, 164), road_dark=C_ROAD_DARK,
         stars=False),
    dict(name="НЕОН", backdrop="city", scenery="cactus",
         sky_top=(28, 10, 56), sky_bot=(96, 24, 110),
         cloud=(188, 120, 224), cloud_sh=(128, 68, 168),
         city=(58, 26, 96), city_dark=(38, 16, 70), city_win=(120, 250, 236),
         tree=(38, 158, 148), tree_dark=(20, 96, 96), trunk=(88, 46, 92),
         road=C_ROAD, road_hi=(255, 108, 200), road_dark=C_ROAD_DARK,
         stars=True),
]

# --- физика ------------------------------------------------------------
SPEED_START = 2.4
SPEED_MAX = 5.8
SPEED_GAIN = 0.0016               # прирост за кадр
START_LIVES = 3
RESUME_FRAMES = 3 * FPS           # отсчёт перед возвратом в игру
INVULN_FRAMES = 70

# --- персонажи ---------------------------------------------------------
# jump   — стартовая вертикальная скорость (чем меньше, тем выше прыжок)
# grav   — притяжение за кадр
# speed  — множитель скорости бега
# double — доступен ли двойной прыжок
# Шесть узнаваемых образов самого Оливера вместо выдуманных друзей.
# hat     — форма головы/убора, face — что на лице, outfit — крой одежды
# top/top2/top3    — верх: основа, тень, акцент (полосы, воротник)
# pants/pants2/pants3 — клёш: основа, тень, манжет
SKIN = (244, 194, 152)
SKIN_SH = (206, 152, 112)

CHARACTERS = [
    dict(
        key="bowl", short="OLIVER", name="OLIVER", subtitle="Фирменный образ",
        note="Горшок, красные очки и фиолетовая кофта. Всё сбалансировано.",
        hat="bowl", face="redshades", outfit="sweater",
        hair=(48, 38, 36), hair2=(84, 68, 62), hair3=(28, 22, 22),
        skin=SKIN, skin2=SKIN_SH,
        top=(154, 112, 198), top2=(104, 70, 148), top3=(192, 160, 224),
        under=(224, 48, 62),                     # красная футболка под кофтой
        pants=(178, 184, 192), pants2=(130, 136, 148), pants3=(212, 218, 226),
        shoes=(242, 242, 248), shoes2=(158, 160, 176),
        jump=-4.55, grav=0.295, speed=1.00, double=False,
    ),
    dict(
        key="windbreaker", short="ВЕТРОВКА", name="WINDBREAKER", subtitle="Ugly Is Beautiful",
        note="Жёлтая ветровка и мешковатые джинсы. Прыгает выше всех.",
        hat="bowl", face="plain", outfit="windbreaker",
        hair=(96, 58, 30), hair2=(146, 96, 48), hair3=(64, 36, 18),
        skin=SKIN, skin2=SKIN_SH,
        top=(248, 214, 64), top2=(184, 146, 26), top3=(250, 246, 232),
        pants=(76, 116, 210), pants2=(44, 72, 150), pants3=(126, 162, 236),
        shoes=(242, 242, 248), shoes2=(158, 160, 176),
        jump=-5.25, grav=0.355, speed=1.05, double=False,
    ),
    dict(
        key="stunt", short="ШЛЕМ", name="STUNT", subtitle="Трюковой образ",
        note="Шлем и гоглы для трюков. Медленный, зато двойной прыжок.",
        hat="helmet", face="goggles", outfit="jumpsuit",
        hair=(58, 40, 26), hair2=(96, 68, 42), hair3=(38, 26, 16),
        skin=SKIN, skin2=SKIN_SH,
        top=(228, 56, 62), top2=(158, 28, 38), top3=(250, 246, 236),
        pants=(228, 56, 62), pants2=(158, 28, 38), pants3=(250, 246, 236),
        shoes=(250, 236, 90), shoes2=(180, 160, 40),
        jump=-4.35, grav=0.315, speed=0.93, double=True,
    ),
    dict(
        key="cowboy", short="КОВБОЙ", name="COWBOY", subtitle="Cowboy Tears",
        note="Ковбойская эра: шляпа и деним. Ровный ход, крепкий прыжок.",
        hat="cowboy", face="stache", outfit="denim",
        hair=(112, 74, 38), hair2=(150, 104, 58), hair3=(78, 50, 24),
        skin=SKIN, skin2=SKIN_SH,
        top=(96, 138, 196), top2=(58, 92, 146), top3=(214, 226, 244),
        pants=(150, 168, 196), pants2=(102, 118, 148), pants3=(206, 218, 238),
        shoes=(126, 76, 40), shoes2=(84, 48, 24),
        jump=-4.70, grav=0.300, speed=0.97, double=False,
    ),
    dict(
        key="rocker", short="РОКЕР", name="ROCKER", subtitle="Alone In A Crowd",
        note="Гитарная эра: патлы и косуха. Медленнее, но висит долго.",
        hat="longhair", face="shades", outfit="leather",
        hair=(74, 60, 56), hair2=(116, 98, 92), hair3=(44, 34, 32),
        skin=(238, 186, 148), skin2=(198, 146, 110),
        top=(52, 48, 60), top2=(30, 28, 36), top3=(178, 182, 196),
        pants=(44, 42, 54), pants2=(28, 26, 34), pants3=(88, 84, 104),
        shoes=(34, 30, 32), shoes2=(20, 18, 20),
        jump=-4.40, grav=0.225, speed=0.95, double=False,
    ),
    dict(
        key="track", short="СПОРТ", name="TRACKSUIT", subtitle="Life Goes On",
        note="Спортивный костюм и кепка. Самый быстрый, прыжок пониже.",
        hat="cap", face="plain", outfit="tracksuit",
        hair=(88, 56, 30), hair2=(130, 88, 48), hair3=(60, 36, 18),
        skin=SKIN, skin2=SKIN_SH,
        top=(72, 190, 130), top2=(36, 130, 86), top3=(250, 250, 250),
        pants=(72, 190, 130), pants2=(36, 130, 86), pants3=(250, 250, 250),
        shoes=(240, 240, 246), shoes2=(150, 152, 168),
        jump=-4.35, grav=0.315, speed=1.16, double=False,
    ),
]

# сколько прыжков из десяти заканчиваются бекфлипом
BACKFLIP_CHANCE = 0.28
BACKFLIP_BONUS = 100

# --- трюки в воздухе ---------------------------------------------------
# Крутятся только по нажатию игрока и только пока он в полёте.
# Не докрутил до приземления — бонуса нет (но и штрафа тоже).
# Длительность подобрана под самый короткий прыжок в игре (27.6 кадра):
# иначе трюк физически невозможно докрутить и он кажется сломанным.
TRICKS = {
    "tailwhip": dict(title="ТЕЙЛВИП", frames=18, bonus=150),
    "superman": dict(title="СУПЕРМЕН", frames=16, bonus=120),
    # вилли: встаёт на заднее колесо, держит и опускается обратно
    "wheelie": dict(title="ВИЛЛИ", frames=150, bonus=80,
                    rise=18, angle=34),   # + = нос вверх
}

MAX_LIVES = 5                     # больше сердец в HUD не помещается
LIFE_CHANCE = 0.09                # доля выпадений сердца вместо кассеты
LIFE_MIN_GAP = 26 * FPS
RAMP_BOOST = 1.55                 # во сколько раз трамплин усиливает прыжок
RAMP_BONUS = 60
RAMP_REACH = 78                   # на такую высоту тянется зона трамплина

# --- буст: звезда даёт неуязвимость ------------------------------------
BOOST_SECONDS = 10
BOOST_FRAMES = BOOST_SECONDS * FPS
BOOST_CHANCE = 0.16               # доля выпадений звезды вместо кассеты
BOOST_MIN_GAP = 18 * FPS          # не чаще одной звезды в 18 секунд
TAPE_BONUS = 50

# Кассеты подписаны названиями песен Оливера (названия — просто названия).
# riff — оригинальный чиптюн-мотив, у каждой кассеты свой рисунок
# (падение, скачок, дуга, качели), чтобы они различались на слух, который играет при подборе. Если рядом
# с игрой положить файл tape_<slug>.ogg / .wav, вместо риффа заиграет он.
TAPES = [
    dict(slug="hurt", title="HURT", label=(250, 214, 60),
         riff=["G5", "Eb5", "C5"]),                        # падение
    dict(slug="alienboy", title="ALIEN BOY", label=(120, 226, 226),
         riff=["C5", "C6", "Bb5", "G5"]),                  # скачок и спуск
    dict(slug="lifegoeson", title="LIFE GOES ON", label=(140, 220, 130),
         riff=["Eb5", "F5", "G5", "Bb5", "C6"]),           # подъём ступенями
    dict(slug="cashmachine", title="CASH MACHINE", label=(246, 152, 196),
         riff=["Bb4", "F5", "Bb4", "D5"]),                 # качели
    dict(slug="miracleman", title="MIRACLE MAN", label=(250, 160, 90),
         riff=["Ab4", "C5", "Eb5", "C5"]),                 # дуга
    dict(slug="whenimdown", title="WHEN I'M DOWN", label=(178, 156, 246),
         riff=["G5", "F5", "Eb5", "D5", "C5"]),            # долгий спуск
]
