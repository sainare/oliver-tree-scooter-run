                                                     



                                                                         

import sys

import looks





def _canvas_width():

    


                                                     

    if sys.platform == "emscripten":

        try:

            import platform

            w, h = platform.window.innerWidth, platform.window.innerHeight

            if w > h:

                return max(320, min(426, round(180 * w / h / 2) * 2))

        except Exception:

            pass

    return 320





CANVAS_W, CANVAS_H = _canvas_width(), 180                                     

SCALE = 3                                                              

WIN_W, WIN_H = CANVAS_W * SCALE, CANVAS_H * SCALE

FPS = 60



GROUND_Y = 148                                                

                                                                       

                                      

PLAYER_X = 54 + (max(26, (CANVAS_W - 320) // 2) if sys.platform == "emscripten" else 0)



                                                                         

C_SKY_TOP = (52, 146, 226)

C_SKY_BOT = (136, 208, 242)

C_CLOUD = (250, 252, 255)

C_CLOUD_SH = (198, 220, 244)

C_CITY = (72, 126, 202)

C_CITY_DARK = (56, 104, 176)

C_CITY_WIN = (126, 172, 228)

C_TREE = (54, 168, 78)

C_TREE_DARK = (28, 116, 54)

C_TRUNK = (124, 76, 42)

                                                                   

C_ROAD = (26, 24, 30)

C_ROAD_HI = (248, 146, 198)

C_ROAD_DARK = (13, 12, 16)

C_ROAD_LINE = (250, 244, 226)

C_WHITE = (250, 250, 252)

C_BLACK = (18, 14, 28)

C_YELLOW = (252, 214, 60)

C_PINK = (255, 96, 160)

C_CYAN = (90, 230, 230)

C_RED = (232, 60, 72)

C_GREEN = (110, 220, 110)

C_UI_BOX = (226, 46, 58)                                           

C_UI_BOX_SEL = (250, 238, 210)                         

C_UI_EDGE = (250, 250, 252)

C_STAR = (252, 226, 110)                                    



                                                                         

ZONE_SCORE = 300                                                                                              

ZONE_FX_FRAMES = 54                                               

ZONES = [

    dict(name="ДЕНЬ", backdrop="city", scenery="tree",

         sky_top=C_SKY_TOP, sky_bot=C_SKY_BOT,

         cloud=C_CLOUD, cloud_sh=C_CLOUD_SH,

         city=C_CITY, city_dark=C_CITY_DARK, city_win=C_CITY_WIN,

         tree=C_TREE, tree_dark=C_TREE_DARK, trunk=C_TRUNK,

         road=C_ROAD, road_hi=C_ROAD_HI, road_dark=C_ROAD_DARK,

         stars=False),

    dict(name="ЗАКАТ", backdrop="mesas", scenery="palm",

         sky_top=(120, 62, 148), sky_bot=(250, 176, 108),

         cloud=(254, 216, 190), cloud_sh=(216, 146, 148),

         city=(96, 66, 138), city_dark=(72, 48, 108), city_win=(250, 208, 130),

         tree=(56, 118, 92), tree_dark=(30, 74, 66), trunk=(96, 58, 42),

         road=C_ROAD, road_hi=(240, 128, 168), road_dark=C_ROAD_DARK,

         stars=False),

    dict(name="НОЧЬ", backdrop="mountains", scenery="pine",

         sky_top=(16, 14, 52), sky_bot=(64, 48, 116),

         cloud=(178, 184, 224), cloud_sh=(120, 126, 176),

         city=(42, 38, 88), city_dark=(28, 26, 66), city_win=(252, 228, 140),

         tree=(34, 92, 62), tree_dark=(18, 56, 40), trunk=(72, 46, 32),

         road=C_ROAD, road_hi=(196, 96, 156), road_dark=C_ROAD_DARK,

         stars=True),

    dict(name="РАССВЕТ", backdrop="hills", scenery="tree",

         sky_top=(96, 132, 206), sky_bot=(252, 206, 172),

         cloud=(255, 236, 224), cloud_sh=(214, 172, 178),

         city=(110, 122, 178), city_dark=(84, 94, 148), city_win=(250, 232, 190),

         tree=(78, 158, 104), tree_dark=(42, 104, 72), trunk=(114, 72, 42),

         road=C_ROAD, road_hi=(252, 186, 202), road_dark=C_ROAD_DARK,

         stars=False),

    dict(name="ГРОЗА", backdrop="factory", scenery="pine",

         sky_top=(48, 54, 74), sky_bot=(126, 134, 152),

         cloud=(206, 210, 222), cloud_sh=(142, 148, 166),

         city=(64, 72, 96), city_dark=(46, 52, 72), city_win=(206, 214, 236),

         tree=(46, 104, 78), tree_dark=(24, 62, 50), trunk=(76, 54, 38),

         road=C_ROAD, road_hi=(198, 134, 164), road_dark=C_ROAD_DARK,

         stars=False),

    dict(name="НЕОН", backdrop="city", scenery="cactus",

         sky_top=(28, 10, 56), sky_bot=(96, 24, 110),

         cloud=(188, 120, 224), cloud_sh=(128, 68, 168),

         city=(58, 26, 96), city_dark=(38, 16, 70), city_win=(120, 250, 236),

         tree=(38, 158, 148), tree_dark=(20, 96, 96), trunk=(88, 46, 92),

         road=C_ROAD, road_hi=(255, 108, 200), road_dark=C_ROAD_DARK,

         stars=True),

]



                                                                         

                                                                          

SPEED_START = 3.1

SPEED_MAX = 7.6

SPEED_GAIN = 0.0030                                

SPEED_LOCK = 4.2                                                                           

START_LIVES = 3                                                                   

                                                                                

                                                                                

                                                                                     

RIDER_SCALE = 1.2                                    

OBST_SCALE = 1.2                                                                   

                                                                                        

                                                                             

                                                                           

OBST_LEVELS = (("МАЛО", 1.45), ("МНОГО", 1.0), ("ОЧЕНЬ МНОГО", 0.58))

                                                                              

OBJ_SCALE = 1.2

                                                                                                  

START_LEVELS = (("МЕДЛЕННО", 2.5), ("ОБЫЧНАЯ", 3.1), ("БЫСТРО", 4.4), ("ОЧЕНЬ БЫСТРО", 5.8))

RESUME_FRAMES = 3 * FPS                                          

INVULN_FRAMES = 50                                                       

SLOW_FRAMES = 190                                                                    

SLOW_START = 0.22                                                  



                                                                         

                                                                        

                             

                                  

                                     

                                                                   

                                                                        

                                                                  

                                                  

SKIN = (244, 194, 152)

SKIN_SH = (206, 152, 112)



CHARACTERS = [

    dict(

        key="bowl", short="OLIVER", name="OLIVER", subtitle="Фирменный образ",

        note="Горшок, красные очки и фиолетовая кофта. Всё сбалансировано.",

        hat="bowl", face="redshades", outfit="sweater",

        hair=(48, 38, 36), hair2=(84, 68, 62), hair3=(28, 22, 22),

        skin=SKIN, skin2=SKIN_SH,

        top=(154, 112, 198), top2=(104, 70, 148), top3=(192, 160, 224),

        under=(224, 48, 62),                                                  

        pants=(178, 184, 192), pants2=(130, 136, 148), pants3=(212, 218, 226),

        shoes=(242, 242, 248), shoes2=(158, 160, 176),

        jump=-5.32, grav=0.295, speed=1.00, double=False,

    ),

    dict(

        key="windbreaker", short="ВЕТРОВКА", name="WINDBREAKER", subtitle="Ugly Is Beautiful",

        note="Жёлтая ветровка и мешковатые джинсы. Прыгает выше всех.",

        hat="bowl", face="plain", outfit="windbreaker",

        hair=(96, 58, 30), hair2=(146, 96, 48), hair3=(64, 36, 18),

        skin=SKIN, skin2=SKIN_SH,

        top=(248, 214, 64), top2=(184, 146, 26), top3=(250, 246, 232),

        pants=(76, 116, 210), pants2=(44, 72, 150), pants3=(126, 162, 236),

        shoes=(242, 242, 248), shoes2=(158, 160, 176),

        jump=-6.14, grav=0.355, speed=1.05, double=False,

    ),

    dict(

        key="stunt", short="ШЛЕМ", name="STUNT", subtitle="Трюковой образ",

        note="Шлем и гоглы для трюков. Медленный, зато двойной прыжок.",

        hat="helmet", face="goggles", outfit="jumpsuit",

        hair=(58, 40, 26), hair2=(96, 68, 42), hair3=(38, 26, 16),

        skin=SKIN, skin2=SKIN_SH,

        top=(228, 56, 62), top2=(158, 28, 38), top3=(250, 246, 236),

        pants=(228, 56, 62), pants2=(158, 28, 38), pants3=(250, 246, 236),

        shoes=(250, 236, 90), shoes2=(180, 160, 40),

        jump=-5.09, grav=0.315, speed=0.93, double=True,

    ),

    dict(

        key="cowboy", short="КОВБОЙ", name="COWBOY", subtitle="Cowboy Tears",

        note="Ковбойская эра: шляпа и деним. Ровный ход, крепкий прыжок.",

        hat="cowboy", face="stache", outfit="denim",

        hair=(112, 74, 38), hair2=(150, 104, 58), hair3=(78, 50, 24),

        skin=SKIN, skin2=SKIN_SH,

        top=(96, 138, 196), top2=(58, 92, 146), top3=(214, 226, 244),

        pants=(150, 168, 196), pants2=(102, 118, 148), pants3=(206, 218, 238),

        shoes=(126, 76, 40), shoes2=(84, 48, 24),

        jump=-5.50, grav=0.300, speed=0.97, double=False,

    ),

    dict(

        key="rocker", short="РОКЕР", name="ROCKER", subtitle="Alone In A Crowd",

        note="Гитарная эра: патлы и косуха. Медленнее, но висит долго.",

        hat="longhair", face="shades", outfit="leather",

        hair=(74, 60, 56), hair2=(116, 98, 92), hair3=(44, 34, 32),

        skin=(238, 186, 148), skin2=(198, 146, 110),

        top=(52, 48, 60), top2=(30, 28, 36), top3=(178, 182, 196),

        pants=(44, 42, 54), pants2=(28, 26, 34), pants3=(88, 84, 104),

        shoes=(34, 30, 32), shoes2=(20, 18, 20),

        jump=-5.15, grav=0.225, speed=0.95, double=False,

    ),

    dict(

        key="track", short="СПОРТ", name="TRACKSUIT", subtitle="Life Goes On",

        note="Спортивный костюм и кепка. Самый быстрый, прыжок пониже.",

        hat="cap", face="plain", outfit="tracksuit",

        hair=(88, 56, 30), hair2=(130, 88, 48), hair3=(60, 36, 18),

        skin=SKIN, skin2=SKIN_SH,

        top=(72, 190, 130), top2=(36, 130, 86), top3=(250, 250, 250),

        pants=(72, 190, 130), pants2=(36, 130, 86), pants3=(250, 250, 250),

        shoes=(240, 240, 246), shoes2=(150, 152, 168),

        jump=-5.09, grav=0.315, speed=1.16, double=False,

    ),

]



BASE_CHAR_COUNT = len(CHARACTERS)



_COSTUME_DATA = (

    ("cowboy_stache", "УСАТЫЙ КОВБОЙ", "КОВБОЙ+", "Шляпа, усы, красный комбинезон", 200, "bowl",

     {"hat": 4, "face": 4, "top": 3, "pants": 4, "hair": 5, "shoes": 3}),

    ("sea", "МОРЯК", "МОРЯК", "Усы, синяя кофта, белые штаны", 200, "bowl",

     {"hat": 1, "face": 4, "outfit": 1, "top": 4, "pants": 6, "hair": 2, "shoes": 5}),

    ("pink_denim", "РОЗОВЫЙ ДЖИНС", "РОЗОВЫЙ", "Кепка, красные очки, джинсовка", 250, "bowl",

     {"hat": 3, "face": 1, "outfit": 4, "top": 7, "pants": 2, "hair": 5, "shoes": 1}),

    ("neon_rocker", "НЕОНОВЫЙ РОКЕР", "НЕОН", "Патлы, чёрные очки, косуха", 250, "bowl",

     {"hat": 5, "face": 2, "outfit": 5, "top": 10, "pants": 3, "hair": 6, "shoes": 4}),

    ("cyber", "КИБЕР-ГОГЛЫ", "КИБЕР", "Шлем, гоглы, зелёный комбез", 300, "bowl",

     {"hat": 2, "face": 3, "outfit": 3, "top": 6, "pants": 7, "hair": 1, "shoes": 2}),

    ("fire", "ОГНЕННЫЙ ТРЮКАЧ", "ОГОНЬ", "Шлем, гоглы, оранжевый комбез", 350, "bowl",

     {"hat": 2, "face": 3, "outfit": 3, "top": 9, "pants": 4, "hair": 3, "shoes": 3}),

    ("gold", "ЗОЛОТОЙ ЧЕМПИОН", "ЗОЛОТО", "Кепка, олимпийка, золото", 400, "bowl",

     {"hat": 3, "face": 5, "outfit": 6, "top": 2, "pants": 6, "hair": 4, "shoes": 4}),

    ("ghost", "ЧЁРНЫЙ ПРИЗРАК", "ПРИЗРАК", "Всё чёрное, седые волосы", 500, "bowl",

     {"hat": 1, "face": 2, "outfit": 2, "top": 5, "pants": 3, "hair": 7, "shoes": 2}),

)



def _build_costumes():

    result = []

    for key, name, short, desc, price, base_key, style in _COSTUME_DATA:

        base = next(c for c in CHARACTERS if c["key"] == base_key)

        ch = looks.styled(base, style)

        ch["key"] = key

        ch["short"] = short

        ch["name"] = name

        ch["subtitle"] = desc

        ch["note"] = desc

        ch["price"] = price

        ch["perm_key"] = "skin_" + key

        result.append(ch)

    return result



CHARACTERS.extend(_build_costumes())

SKINS = ()



                                                   

BACKFLIP_CHANCE = 0.28

BACKFLIP_BONUS = 25



                                                                         

                                                              

                                                             

                                                                       

                                                                   

TRICK_COOLDOWN = int(1.5 * FPS)                                         

TRICKS = {

    "tailwhip": dict(title="ТЕЙЛВИП", frames=18, bonus=38),

    "superman": dict(title="СУПЕРМЕН", frames=16, bonus=30),

                                                                 

    "wheelie": dict(title="ВИЛЛИ", frames=150, bonus=20,

                    rise=18, angle=34),                  

}



MAX_LIVES = 6                                                

LIFE_CHANCE = 0.10                                                      

LIFE_MIN_GAP = 22 * FPS

                                                                         

                                                                           

                                                                            

RAMP_APEX = 88                                                               

RAMP_APEX_JUMP = 102                                             

RAMP_GRAV = 0.8                                                                      

RAMP_JUMP_GRACE = 12                                                             

RAMP_JUMP_AHEAD = 48                                                                         

RAMP_BONUS = 15

RAMP_SUPER_BONUS = 30

RAMP_REACH = 78                                                               



                                                                         

BOOST_SECONDS = 10

BOOST_FRAMES = BOOST_SECONDS * FPS

BOOST_CHANCE = 0.16                                                     

BOOST_MIN_GAP = 18 * FPS                                            

TAPE_BONUS = 12



                                                                                       

SHOP_ITEMS = [

    ("djump", "ДВОЙНОЙ ПРЫЖОК", "второй прыжок в воздухе у всех", (150,)),

    ("hp", "ДОП. ЖИЗНЬ", "+1 жизнь в начале каждого забега", (250,)),

]

                                                                                             

PREP_ITEMS = [

    ("hp1", "ДОП. ЖИЗНЬ НА ЗАБЕГ", "+1 жизнь только сейчас", 60, 0),

    ("star", "ЗВЕЗДА", "неуязвимость 15 сек", 25, 15),

    ("fly", "ПОЛЁТ", "10 сек над препятствиями", 40, 10),

    ("speed", "ЗЕЛЬЕ СКОРОСТИ", "ровная скорость 15 сек", 25, 15),

]



                                                                          

                                                                 

                                                                                                        

                                                                         

TAPES = [

    dict(slug="hurt", title="HURT", label=(250, 214, 60),

         riff=["G5", "Eb5", "C5"]),                                 

    dict(slug="alienboy", title="ALIEN BOY", label=(120, 226, 226),

         riff=["C5", "C6", "Bb5", "G5"]),                                  

    dict(slug="lifegoeson", title="LIFE GOES ON", label=(140, 220, 130),

         riff=["Eb5", "F5", "G5", "Bb5", "C6"]),                             

    dict(slug="cashmachine", title="CASH MACHINE", label=(246, 152, 196),

         riff=["Bb4", "F5", "Bb4", "D5"]),                         

    dict(slug="miracleman", title="MIRACLE MAN", label=(250, 160, 90),

         riff=["Ab4", "C5", "Eb5", "C5"]),                       

    dict(slug="whenimdown", title="WHEN I'M DOWN", label=(178, 156, 246),

         riff=["G5", "F5", "Eb5", "D5", "C5"]),                          

]

