




   



import math

import pygame



from settings import C_BLACK, RIDER_SCALE



SPR_W, SPR_H = 34, 46

CX = SPR_W // 2                                            

C_LENS = (120, 226, 226)



                                       

HEAD_X, HEAD_Y, HEAD_W, HEAD_H = 10, 2, 13, 12

TORSO_Y = 14

PANTS_Y = 22

SHOES_Y = 32

DECK_Y = 36                                                      

WHEEL_R = 4

WHEEL_BACK = (8, 40)

WHEEL_FRONT = (27, 40)

BAR_X, BAR_Y = 29, 13                                        





def _r(surf, color, x, y, w, h):

                                                                         

    surf.fill(color, pygame.Rect(int(x), int(y), int(w), int(h)))





def add_outline(surf, color=C_BLACK):

                                                                   

    w, h = surf.get_size()

    out = pygame.Surface((w + 2, h + 2), pygame.SRCALPHA)

    silhouette = pygame.mask.from_surface(surf).to_surface(

        setcolor=color, unsetcolor=(0, 0, 0, 0))

    for dx, dy in ((0, 1), (2, 1), (1, 0), (1, 2)):

        out.blit(silhouette, (dx, dy))

    out.blit(surf, (1, 1))

    return out





                                                                         

def _hat_bowl(s, ch, hx, hy):

                                                                       

    h, h2, h3 = ch["hair"], ch["hair2"], ch["hair3"]

    _r(s, h, hx - 1, hy - 1, 15, 9)

    _r(s, h, hx - 2, hy + 1, 17, 6)

    _r(s, h, hx - 2, hy + 5, 4, 6)                              

    _r(s, h, hx + 11, hy + 5, 4, 6)

    _r(s, h, hx, hy + 6, 13, 2)                                

    _r(s, h3, hx - 2, hy + 7, 17, 1)                              

    _r(s, h2, hx + 1, hy, 8, 1)                               

    _r(s, h2, hx - 1, hy + 2, 1, 4)





def _hat_helmet(s, ch, hx, hy):

                                                             

    base, dark, stripe = ch["top"], ch["top2"], ch["top3"]

    _r(s, ch["hair"], hx + 11, hy + 7, 4, 5)                  

    _r(s, base, hx - 2, hy - 1, 17, 8)

    _r(s, base, hx - 1, hy - 2, 15, 3)

    _r(s, stripe, hx + 4, hy - 2, 3, 9)                           

    _r(s, dark, hx - 2, hy + 5, 17, 2)

    _r(s, dark, hx + 12, hy + 6, 5, 2)                           

    _r(s, dark, hx - 2, hy + 7, 2, 5)                     

    _r(s, stripe, hx, hy, 5, 1)





def _hat_cap(s, ch, hx, hy):

    base, dark = ch["top"], ch["top2"]

    _r(s, ch["hair"], hx - 1, hy + 5, 4, 6)

    _r(s, ch["hair"], hx + 11, hy + 6, 3, 4)

    _r(s, base, hx - 1, hy, 15, 5)

    _r(s, ch["top3"], hx + 4, hy + 1, 2, 3)                     

    _r(s, dark, hx - 1, hy + 4, 15, 2)

    _r(s, dark, hx + 11, hy + 5, 7, 2)                    

    _r(s, ch["top3"], hx + 11, hy + 5, 7, 1)









def _hat_cowboy(s, ch, hx, hy):

                                                                     

    felt = (142, 106, 62)

    felt_d = (98, 70, 38)

    band = (58, 44, 34)

    _r(s, ch["hair"], hx - 1, hy + 6, 4, 5)                           

    _r(s, ch["hair"], hx + 11, hy + 6, 3, 4)

    _r(s, felt, hx + 1, hy - 2, 11, 6)                  

    _r(s, felt_d, hx + 5, hy - 2, 2, 4)                              

    _r(s, band, hx, hy + 3, 13, 2)                      

    _r(s, felt, hx - 4, hy + 5, 21, 2)                 

    _r(s, felt_d, hx - 4, hy + 6, 21, 1)

    _r(s, felt, hx - 5, hy + 5, 1, 1)

    _r(s, felt, hx + 16, hy + 5, 1, 1)





def _hat_longhair(s, ch, hx, hy):

                                  

    h, h2, h3 = ch["hair"], ch["hair2"], ch["hair3"]

    _r(s, h, hx - 1, hy - 1, 15, 7)

    _r(s, h, hx - 2, hy, 17, 5)

    _r(s, h, hx - 3, hy + 3, 3, 17)                           

    _r(s, h, hx + 13, hy + 3, 3, 14)                     

    _r(s, h3, hx - 3, hy + 13, 3, 1)

    _r(s, h3, hx + 13, hy + 12, 3, 1)

    _r(s, h2, hx + 1, hy - 1, 7, 1)                               

    _r(s, h2, hx - 3, hy + 6, 1, 9)





_HAT = {"bowl": _hat_bowl, "helmet": _hat_helmet, "cap": _hat_cap,

        "cowboy": _hat_cowboy, "longhair": _hat_longhair}





                                                                         

def _face_eyes(s, ch, hx, hy, brow=True):

    for ex in (hx + 3, hx + 8):

        _r(s, C_BLACK, ex, hy + 8, 2, 2)

        _r(s, (250, 250, 250), ex, hy + 8, 1, 1)                  

    if brow:

        _r(s, ch["hair3"], hx + 2, hy + 6, 3, 1)

        _r(s, ch["hair3"], hx + 8, hy + 6, 3, 1)





def _face_plain(s, ch, hx, hy):

    _face_eyes(s, ch, hx, hy)

    _r(s, ch["skin2"], hx + 6, hy + 8, 1, 2)            

    _r(s, (176, 92, 92), hx + 5, hy + 11, 4, 1)





def _face_stache(s, ch, hx, hy):

    _face_eyes(s, ch, hx, hy)

    _r(s, ch["skin2"], hx + 6, hy + 8, 1, 2)

    _r(s, ch["hair"], hx + 3, hy + 10, 8, 2)            

    _r(s, ch["hair3"], hx + 3, hy + 11, 8, 1)









def _face_goggles(s, ch, hx, hy):

    _r(s, (44, 42, 54), hx - 2, hy + 6, 17, 4)                   

    _r(s, C_LENS, hx + 2, hy + 7, 4, 2)

    _r(s, C_LENS, hx + 7, hy + 7, 4, 2)

    _r(s, (250, 250, 250), hx + 2, hy + 7, 1, 1)

    _r(s, (250, 250, 250), hx + 7, hy + 7, 1, 1)

    _r(s, ch["hair"], hx + 3, hy + 10, 8, 2)                      

    _r(s, (176, 92, 92), hx + 5, hy + 12, 3, 1)





def _face_redshades(s, ch, hx, hy):

                                            

    _r(s, (170, 44, 48), hx + 1, hy + 6, 12, 4)            

    _r(s, (238, 96, 88), hx + 2, hy + 7, 4, 2)            

    _r(s, (238, 96, 88), hx + 8, hy + 7, 4, 2)

    _r(s, (252, 206, 196), hx + 2, hy + 7, 1, 1)         

    _r(s, (252, 206, 196), hx + 8, hy + 7, 1, 1)

    _r(s, (170, 44, 48), hx + 6, hy + 7, 2, 1)                

    _r(s, ch["skin2"], hx + 6, hy + 10, 1, 1)           

    _r(s, (176, 92, 92), hx + 5, hy + 11, 4, 1)





def _face_shades(s, ch, hx, hy):

    _r(s, (26, 24, 32), hx + 1, hy + 7, 11, 3)                  

    _r(s, (70, 66, 84), hx + 2, hy + 7, 3, 1)

    _r(s, ch["skin2"], hx + 6, hy + 10, 1, 1)

    _r(s, (176, 92, 92), hx + 5, hy + 11, 4, 1)





_FACE = {"plain": _face_plain, "stache": _face_stache,

         "goggles": _face_goggles,

         "shades": _face_shades, "redshades": _face_redshades}





                                                                         

def _outfit_windbreaker(s, ch, x, y, w, h):

                                                                 

    _r(s, ch["top"], x, y, w, h)

    _r(s, ch["top2"], x, y, w, 2)

    _r(s, ch["top3"], x, y + 3, w, 2)                               

    _r(s, ch["top2"], x + w // 2, y + 2, 1, h - 4)          

    _r(s, ch["top2"], x + 2, y + h - 4, 4, 2)              

    _r(s, ch["top2"], x, y + h - 2, w, 2)                         





def _outfit_jumpsuit(s, ch, x, y, w, h):

                                                                  

    _r(s, ch["top"], x, y, w, h)

    _r(s, ch["top2"], x, y, w, 2)

    _r(s, ch["top3"], x + 3, y + 2, 2, h - 3)

    _r(s, ch["top3"], x + w - 6, y + 2, 2, h - 3)

    _r(s, ch["top2"], x + w // 2, y + 2, 1, h - 4)

    _r(s, ch["top3"], x + w // 2 - 3, y + 1, 7, 1)            









def _outfit_denim(s, ch, x, y, w, h):

                                                                      

    _r(s, ch["top"], x, y, w, h)

    _r(s, ch["top2"], x, y, w, 2)

    _r(s, ch["top3"], x + w // 2 - 3, y + 1, 7, 2)                 

    _r(s, ch["top2"], x + w // 2, y + 2, 1, h - 3)

    for i in range(2):                                             

        _r(s, ch["top3"], x + w // 2, y + 4 + i * 3, 1, 1)

    _r(s, ch["top2"], x + 2, y + 4, 4, 3)                         

    _r(s, ch["top2"], x + w - 6, y + 4, 4, 3)





def _outfit_leather(s, ch, x, y, w, h):

                                                    

    _r(s, ch["top"], x, y, w, h)

    _r(s, ch["top2"], x, y, w, 2)

    _r(s, ch["top2"], x + w // 2 - 4, y + 1, 4, 2)                 

    _r(s, ch["top2"], x + w // 2 + 1, y + 1, 4, 2)

    for i in range(5):                                                 

        _r(s, ch["top3"], x + 4 + i, y + 3 + i, 1, 1)

    _r(s, ch["top3"], x + 1, y + 3, 1, 1)

    _r(s, ch["top3"], x + w - 2, y + 3, 1, 1)

    _r(s, ch["top2"], x, y + h - 2, w, 2)





def _outfit_tracksuit(s, ch, x, y, w, h):

                                                                

    _r(s, ch["top"], x, y, w, h)

    _r(s, ch["top2"], x, y, w, 2)

    _r(s, ch["top3"], x + 1, y, 2, h)                             

    _r(s, ch["top3"], x + w - 3, y, 2, h)

    _r(s, ch["top2"], x + w // 2, y + 1, 1, h - 2)

    _r(s, ch["top3"], x + w // 2 - 2, y + 1, 5, 1)                        





def _outfit_sweater(s, ch, x, y, w, h):

                                                                      

    under = ch.get("under", ch["top2"])

    _r(s, ch["top"], x, y, w, h)

    _r(s, ch["top2"], x, y, w, 2)                               

    _r(s, under, x + w // 2 - 3, y + 2, 7, h - 2)                             

    _r(s, ch["top2"], x + w // 2 - 4, y + 2, 1, h - 3)               

    _r(s, ch["top2"], x + w // 2 + 4, y + 2, 1, h - 3)

    _r(s, ch["top3"], x + w // 2 - 3, y + 1, 7, 1)              

    _r(s, ch["top3"], x + 2, y + 4, 2, 1)                                  

    _r(s, ch["top2"], x, y + h - 2, w, 2)                               





_OUTFIT = {"windbreaker": _outfit_windbreaker, "jumpsuit": _outfit_jumpsuit,

           "sweater": _outfit_sweater,

           "denim": _outfit_denim,

           "leather": _outfit_leather, "tracksuit": _outfit_tracksuit}





                                                                         

def _draw_body(s, ch, pose, frame):

    skin = ch["skin"]

    pants, pants2, shoes = ch["pants"], ch["pants2"], ch["shoes"]



    head_y, torso_y, pants_y = HEAD_Y, TORSO_Y, PANTS_Y

                                                                           

                                                           

    step = 2 if pose == "air" else 0



                                                              

    bottom = SHOES_Y

    if pose == "air":                                                        

        bottom -= 3

    span = max(2, bottom - pants_y)

    pants3 = ch.get("pants3", pants)

    for i in range(span):

        t = i / (span - 1)

        w = int(round(11 + t * 15))                                      

        left = CX - w // 2

        _r(s, pants, left, pants_y + i, w, 1)

        _r(s, pants2, left, pants_y + i, 2, 1)                             

        _r(s, pants3, left + w - 2, pants_y + i, 1, 1)                   

        if i >= span - 2:                                                     

            _r(s, pants3, left + 1, pants_y + i, w - 2, 1)

    _r(s, pants2, CX - 5, pants_y + span // 3, 4, 1)                         

    _r(s, pants2, CX + 2, pants_y + span // 3 + 1, 4, 1)

                                                                 

    half = int(span * 0.62)

    for i in range(half, span):

        t = (i - half) / max(span - half - 1, 1)

        gw = int(round(1 + t * 4))

        _r(s, (0, 0, 0, 0), CX - gw // 2 + step, pants_y + i, gw, 1)



                                                        

    sh2 = ch["shoes2"]

    for sx, sw in ((CX - 9 - step, 8), (CX + 2 + step, 9)):

        _r(s, shoes, sx, bottom, sw, 3)

        _r(s, sh2, sx, bottom + 2, sw, 1)                      

        _r(s, sh2, sx + sw - 2, bottom, 2, 2)                

        _r(s, sh2, sx + 2, bottom, 1, 1)                        

        _r(s, sh2, sx + 4, bottom + 1, 1, 1)



                                              

    _OUTFIT[ch["outfit"]](s, ch, 8, torso_y, 17, 10)



                                          

    arm_y = torso_y + 2

    _r(s, ch["top2"], 22, arm_y, 6, 3)

    _r(s, ch["top3"], 22, arm_y, 6, 1)                                

    _r(s, ch["top3"], 25, arm_y + 2, 3, 1)                           

    _r(s, skin, 27, arm_y - 1, 3, 3)

    _r(s, ch["skin2"], 27, arm_y + 1, 3, 1)                            



                    

    _r(s, skin, HEAD_X, head_y + 1, HEAD_W, HEAD_H - 2)

    _r(s, skin, HEAD_X + 1, head_y, HEAD_W - 2, HEAD_H)

    _r(s, ch["skin2"], HEAD_X, head_y + 2, 2, HEAD_H - 4)                  

    _r(s, ch["skin2"], HEAD_X + 1, head_y + HEAD_H - 1, HEAD_W - 2, 1)

    _r(s, skin, HEAD_X - 1, head_y + 5, 1, 3)                    

    _r(s, ch["skin2"], HEAD_X - 1, head_y + 7, 1, 1)               

    _r(s, ch["skin2"], HEAD_X + 2, head_y + HEAD_H - 2, 9, 1)                  



    _FACE[ch["face"]](s, ch, HEAD_X, head_y)

    _HAT[ch["hat"]](s, ch, HEAD_X, head_y)





def _draw_scooter(s, spin):

                                                                          

    metal = (176, 182, 202)

    metal_mid = (132, 138, 162)

    metal_dark = (82, 86, 108)

    tire = (238, 92, 168)                                             

    tread = (176, 46, 116)

    hub = (255, 216, 238)



          

    _r(s, metal, 4, DECK_Y, 26, 2)

    _r(s, metal_mid, 4, DECK_Y + 2, 26, 1)

    _r(s, metal_dark, 4, DECK_Y + 3, 26, 1)

    _r(s, metal_mid, 2, DECK_Y - 2, 3, 3)                             

    _r(s, metal_mid, 29, DECK_Y - 1, 3, 2)



                                   

    pygame.draw.line(s, metal_dark, (28, DECK_Y), (BAR_X + 1, BAR_Y + 2), 3)

    pygame.draw.line(s, metal, (28, DECK_Y), (BAR_X, BAR_Y + 2), 1)

    _r(s, metal, BAR_X - 6, BAR_Y, 11, 2)

    _r(s, metal_dark, BAR_X - 6, BAR_Y + 2, 11, 1)

    _r(s, (40, 38, 48), BAR_X - 6, BAR_Y, 3, 3)               

    _r(s, (40, 38, 48), BAR_X + 3, BAR_Y, 2, 3)



                                                                      

    for (cx, cy) in (WHEEL_BACK, WHEEL_FRONT):

        pygame.draw.circle(s, tire, (cx, cy), WHEEL_R)

        pygame.draw.circle(s, hub, (cx, cy), WHEEL_R - 2)

        dx = math.cos(spin) * (WHEEL_R - 1)

        dy = math.sin(spin) * (WHEEL_R - 1)

        pygame.draw.line(s, tread, (cx - dx, cy - dy), (cx + dx, cy + dy), 1)





def make_rider(ch, pose="run", frame=0, spin=0.0, parts="all"):

    


       

    s = pygame.Surface((SPR_W, SPR_H), pygame.SRCALPHA)

    if parts in ("all", "scooter"):

        _draw_scooter(s, spin)

    if parts in ("all", "body"):

        _draw_body(s, ch, pose, frame)

    return add_outline(s)





def make_rider_set(ch):

                                                                            

    spins = [0.0, 0.35, 0.7, 1.05]

    frames = {

        "run": [make_rider(ch, "run", i, spins[i]) for i in range(4)],

        "air": [make_rider(ch, "air", 0, s) for s in spins],

        "body": [make_rider(ch, "air", 0, 0.0, parts="body")],

        "scooter": [make_rider(ch, "air", 0, s, parts="scooter")

                    for s in spins],

    }

    return {pose: [scaled(f, RIDER_SCALE) for f in lst]

            for pose, lst in frames.items()}





SIT_W, SIT_H = 38, 36





def _back_head(s, ch, hx, hy):

                                                                  

    hat = ch["hat"]

    h, h2, h3 = ch["hair"], ch["hair2"], ch["hair3"]



    if hat == "helmet":

        _r(s, ch["top"], hx - 1, hy, 15, 12)

        _r(s, ch["top3"], hx + 5, hy, 3, 12)                               

        _r(s, ch["top2"], hx - 1, hy + 10, 15, 2)

        _r(s, h, hx + 1, hy + 11, 11, 2)                                     

        return

    if hat == "cap":

        _r(s, ch["top"], hx - 1, hy, 15, 8)

        _r(s, ch["top2"], hx - 1, hy + 6, 15, 2)

        _r(s, ch["top3"], hx + 5, hy + 1, 3, 5)

        _r(s, h, hx, hy + 8, 13, 5)

        _r(s, h3, hx, hy + 11, 13, 2)

        return

    if hat == "cowboy":

        _r(s, h, hx, hy + 6, 13, 7)

        _r(s, (142, 106, 62), hx + 2, hy - 1, 9, 7)             

        _r(s, (58, 44, 34), hx + 1, hy + 4, 11, 2)              

        _r(s, (142, 106, 62), hx - 4, hy + 6, 21, 2)           

        _r(s, (98, 70, 38), hx - 4, hy + 7, 21, 1)

        return



    _r(s, h, hx - 1, hy, 15, 13)                                         

    _r(s, h, hx, hy - 1, 13, 14)

    if hat == "longhair":

        _r(s, h, hx - 2, hy + 4, 4, 12)

        _r(s, h, hx + 11, hy + 4, 4, 11)

    _r(s, h2, hx + 2, hy, 7, 2)                                           

    _r(s, h3, hx - 1, hy + 11, 15, 2)





def make_sitting(ch):

                                                                       

    s = pygame.Surface((SIT_W, SIT_H), pygame.SRCALPHA)

    cx = SIT_W // 2

    top, top2, top3 = ch["top"], ch["top2"], ch["top3"]

    skin, skin2 = ch["skin"], ch["skin2"]



                            

    for i in range(9):

        w = 16 + i * 2

        _r(s, ch["pants"], cx - w // 2, 25 + i, w, 1)

    _r(s, ch["pants2"], cx - 13, 32, 26, 2)

    _r(s, ch["pants2"], cx - 1, 26, 2, 8)                                    



    _r(s, top, cx - 9, 14, 18, 13)                              

    _r(s, top2, cx - 9, 14, 18, 2)                              

    _r(s, top2, cx - 1, 16, 2, 11)                                     

    _r(s, top3, cx - 9, 24, 18, 1)

    _r(s, top2, cx - 12, 17, 4, 10)                                             



                                                                      

                                                   

    _r(s, top, cx + 8, 14, 5, 6)                                

    _r(s, top2, cx + 8, 19, 5, 1)

    _r(s, top, cx + 10, 6, 4, 9)                                           

    _r(s, top3, cx + 10, 6, 1, 9)                                      

    _r(s, top2, cx + 13, 6, 1, 9)                                               

    _r(s, skin, cx + 9, 2, 5, 5)                                

    _r(s, skin2, cx + 9, 6, 5, 1)

    _r(s, skin2, cx + 13, 2, 1, 5)



    _r(s, skin, cx - 3, 12, 6, 3)                             

    _r(s, skin2, cx - 3, 12, 6, 1)

    _back_head(s, ch, cx - 6, 0)

    return add_outline(s)





                                              

                                                               

SIT_HAND = (SIT_W // 2 + 11 + 1, 4 + 1)





def make_portrait(ch):

                                                      

    return make_rider(ch, "run", 0, 0.5)





FACE_W, FACE_H = 26, 26





def make_face(ch):

                                                           

    s = pygame.Surface((FACE_W, FACE_H), pygame.SRCALPHA)

    skin = ch["skin"]

    hx, hy = 6, 5                                             



    _OUTFIT[ch["outfit"]](s, ch, 1, 20, 24, 6)                           

    _r(s, skin, hx + 4, 18, 6, 3)                        

    _r(s, ch["skin2"], hx + 4, 18, 6, 1)



    _r(s, skin, hx, hy + 1, 13, 12)

    _r(s, skin, hx + 1, hy, 11, 14)

    _r(s, ch["skin2"], hx, hy + 2, 2, 10)                          

    _r(s, ch["skin2"], hx + 1, hy + 13, 11, 1)

    _r(s, skin, hx - 1, hy + 6, 1, 4)                    

    _r(s, skin, hx + 13, hy + 6, 1, 4)



    _FACE[ch["face"]](s, ch, hx, hy)

    _HAT[ch["hat"]](s, ch, hx, hy)

    return s





                                                                        

def make_cone():

    s = pygame.Surface((12, 14), pygame.SRCALPHA)

    orange, white, dark = (246, 128, 40), (250, 244, 232), (188, 84, 20)

    for i, (x, w) in enumerate([(5, 2), (4, 4), (4, 4), (3, 6), (2, 8), (1, 10)]):

        _r(s, orange, x, i * 2, w, 2)

    _r(s, white, 3, 6, 6, 2)

    _r(s, dark, 0, 12, 12, 2)

    return add_outline(s)





def make_amp():

    s = pygame.Surface((18, 18), pygame.SRCALPHA)

    body, panel, ring = (46, 40, 56), (28, 24, 36), (150, 150, 170)

    _r(s, body, 0, 0, 18, 18)

    _r(s, panel, 2, 2, 14, 14)

    for cy in (6, 13):

        pygame.draw.circle(s, ring, (9, cy), 3)

        pygame.draw.circle(s, (18, 16, 24), (9, cy), 1)

    _r(s, (232, 196, 72), 2, 0, 14, 1)

    return add_outline(s)





def make_barrier():

    s = pygame.Surface((22, 12), pygame.SRCALPHA)

    frame, warn1, warn2 = (170, 172, 190), (232, 76, 76), (244, 236, 216)

    _r(s, frame, 0, 2, 22, 6)

    for i in range(6):

        _r(s, warn1 if i % 2 else warn2, 1 + i * 3.5, 3, 3, 4)

    _r(s, frame, 2, 8, 2, 4)

    _r(s, frame, 18, 8, 2, 4)

    return add_outline(s)





def make_spikeball():

                                                     

    s = pygame.Surface((16, 16), pygame.SRCALPHA)

    body, dark, hi = (214, 62, 58), (150, 34, 38), (250, 150, 140)

    for i in range(8):                                           

        a = i * math.pi / 4

        dx, dy = math.cos(a), math.sin(a)

        for k in (6, 7):

            _r(s, dark, 8 + dx * k - 1, 8 + dy * k - 1, 2, 2)

    pygame.draw.circle(s, dark, (8, 8), 6)

    pygame.draw.circle(s, body, (8, 8), 5)

    _r(s, hi, 5, 4, 3, 2)                               

    _r(s, dark, 6, 9, 4, 2)                                   

    return add_outline(s)





def make_van():

                                                          

    s = pygame.Surface((28, 16), pygame.SRCALPHA)

    body, dark, glass = (128, 96, 206), (84, 58, 150), (176, 220, 246)

    wheel, rim = (34, 30, 42), (198, 200, 216)

    _r(s, body, 0, 2, 28, 10)

    _r(s, dark, 0, 9, 28, 3)

    _r(s, body, 18, 0, 10, 4)                             

    _r(s, glass, 20, 1, 7, 3)                                     

    _r(s, dark, 2, 4, 14, 4)                            

    _r(s, (250, 214, 60), 26, 5, 2, 2)                  

    for cx in (6, 21):

        pygame.draw.circle(s, wheel, (cx, 13), 3)

        pygame.draw.circle(s, rim, (cx, 13), 1)

    return add_outline(s)





def make_hydrant():

                                                           

    s = pygame.Surface((12, 16), pygame.SRCALPHA)

    body, dark, cap = (228, 62, 58), (158, 32, 38), (246, 148, 140)

    _r(s, dark, 1, 14, 10, 2)                                

    _r(s, body, 3, 4, 6, 11)

    _r(s, dark, 3, 4, 2, 11)                                  

    _r(s, body, 1, 7, 10, 3)                                       

    _r(s, dark, 1, 9, 10, 1)

    _r(s, body, 4, 2, 4, 2)                               

    _r(s, cap, 4, 1, 4, 1)

    _r(s, cap, 6, 5, 1, 3)                              

    return add_outline(s)





def make_dumpster():

                                                

    s = pygame.Surface((24, 18), pygame.SRCALPHA)

    body, dark, lid = (68, 132, 96), (40, 92, 64), (98, 168, 124)

    wheel = (34, 30, 42)

    _r(s, body, 1, 4, 22, 12)

    _r(s, dark, 1, 11, 22, 5)                                 

    _r(s, lid, 0, 2, 24, 3)                               

    _r(s, dark, 0, 4, 24, 1)

    for x in (5, 12, 19):                                          

        _r(s, dark, x, 6, 1, 5)

    for cx in (5, 18):

        pygame.draw.circle(s, wheel, (cx, 16), 2)

    return add_outline(s)





def make_sign():

                                  

    s = pygame.Surface((16, 22), pygame.SRCALPHA)

    post, post_d = (176, 180, 196), (112, 116, 136)

    face, rim, mark = (232, 76, 76), (250, 246, 240), (250, 246, 240)

    _r(s, post, 7, 8, 2, 14)

    _r(s, post_d, 8, 8, 1, 14)

    _r(s, rim, 1, 1, 14, 9)

    _r(s, face, 2, 2, 12, 7)

    _r(s, mark, 4, 5, 8, 2)                                               

    return add_outline(s)





def make_pothole():

                                                                 

    s = pygame.Surface((30, 10), pygame.SRCALPHA)

    hole, deep, rim = (58, 26, 48), (28, 10, 26), (250, 210, 234)

    _r(s, rim, 1, 2, 28, 2)                                         

    _r(s, hole, 0, 3, 30, 6)

    _r(s, deep, 3, 5, 24, 4)

    for x in (2, 9, 17, 25):                                       

        _r(s, rim, x, 1, 2, 1)

    return add_outline(s)





BALLOON_KNOT = (11, 17)                                                 





def make_balloons():

    



       

    s = pygame.Surface((24, 18), pygame.SRCALPHA)

    string = (228, 224, 236)

    knot_x, knot_y = BALLOON_KNOT

    balls = (((236, 72, 96), (255, 150, 168), 2, 1),

             ((252, 206, 84), (255, 238, 168), 13, 0),

             ((104, 190, 246), (188, 230, 255), 8, 6))

    for color, hi, bx, by in balls:

        pygame.draw.line(s, string, (bx + 3, by + 8), (knot_x, knot_y), 1)

    for color, hi, bx, by in balls:

        pygame.draw.ellipse(s, color, pygame.Rect(bx, by, 8, 10))

        _r(s, hi, bx + 2, by + 2, 2, 3)                  

        _r(s, color, bx + 3, by + 9, 2, 2)                  

    return add_outline(s)





                                         

BALLOON_ANCHOR = (BALLOON_KNOT[0] + 1, BALLOON_KNOT[1] + 1)





                                                                        

                                                                            

RAMP_W, RAMP_H = 60, 32                                                  

RAMP_X0 = 1                                                                      

RAMP_SPRITE_W = RAMP_W + 7                                                 





def ramp_height(dx):

                                                                       

    if dx <= 0:

        return 0.0

    if dx >= RAMP_W:

        return float(RAMP_H)

    t = dx / RAMP_W

    return RAMP_H * (t * t * 0.72 + t * 0.28)





def make_ramp():

    
                                                                        

    W, H = RAMP_W, RAMP_H

    s = pygame.Surface((RAMP_SPRITE_W, H + 5), pygame.SRCALPHA)

    base = H + 4                                                                 

    body, body_dk = (54, 96, 156), (36, 66, 116)

    deck, deck_hi, deck_dk = (108, 206, 226), (210, 248, 254), (62, 150, 182)

    frame, bolt, arrow = (78, 88, 116), (236, 240, 250), (252, 214, 60)

    for x in range(W):

        h = int(round(ramp_height(x + 0.5)))

        if h <= 0:

            continue

        top = base - h

        _r(s, body, x, top, 1, h + 1)                           

        if h > 9:                                                    

            _r(s, body_dk, x, base - h // 3, 1, h // 3 + 1)

        if x % 12 == 11 and h > 6:                                       

            _r(s, body_dk, x, top + 4, 1, h - 4)

        _r(s, deck, x, top, 1, 3)                          

        _r(s, deck_hi, x, top, 1, 1)                               

        if x % 6 == 0:                                                 

            _r(s, deck_dk, x, top + 1, 1, 1)

    for ax in (W - 32, W - 21, W - 10):                                      

        cy = base - int(ramp_height(ax)) // 2 - 1

        if base - cy < 6:

            continue

        for k, dy in enumerate((-2, -1, 0, 1, 2)):

            px = ax + (2 - abs(dy))

            _r(s, arrow, px - 1, cy + dy, 2, 1)

    _r(s, frame, W, base - H + 2, 3, H - 1)                           

    _r(s, body_dk, W, base - H + 2, 1, H - 1)

    for y in range(base - H + 6, base - 1, 7):                        

        _r(s, bolt, W + 1, y, 1, 1)

    _r(s, deck, W - 3, base - H - 1, 5, 2)                                       

    _r(s, bolt, W - 1, base - H - 3, 4, 3)                                

    _r(s, frame, W - 1, base - H - 1, 4, 1)

    _r(s, (255, 255, 255), W, base - H - 3, 1, 1)

    _r(s, deck_dk, 0, base, W + 3, 1)                                     

    return add_outline(s)





                                                           

LAUNCH_W, LAUNCH_H, LAUNCH_PLAT, LAUNCH_PAD = 130, 50, 40, 14                                    





def launch_height(dx):

                                                                           

    if dx <= LAUNCH_PLAT:

        return float(LAUNCH_H)

    if dx >= LAUNCH_W:

        return 0.0

    t = (dx - LAUNCH_PLAT) / (LAUNCH_W - LAUNCH_PLAT)

    return LAUNCH_H * (1.0 - t) ** 1.7





def make_launch_ramp():

                                                                         

    W, H, P, PAD = LAUNCH_W, LAUNCH_H, LAUNCH_PLAT, LAUNCH_PAD

    base = H + 3 + PAD                                                             

    s = pygame.Surface((W + 4, H + 6 + PAD), pygame.SRCALPHA)

    body, body_dk = (58, 74, 140), (40, 52, 104)

    deck, deck_dk = (250, 214, 60), (196, 150, 30)

    frame, bolt = (78, 88, 116), (232, 238, 248)

    for x in range(W):

        h = int(launch_height(x))

        top = base - h

        if x < P:                                                  

            _r(s, body, 2 + x, top, 1, 5)

            _r(s, body_dk, 2 + x, top + 4, 1, 1)

        else:                                                         

            _r(s, body, 2 + x, top, 1, h + 1)

            if h > 6:

                _r(s, body_dk, 2 + x, top + h // 2, 1, h + 1 - h // 2)

            if (x - P) % 12 == 0 and h > 4:                    

                _r(s, body_dk, 2 + x, top + 2, 1, h - 1)

        _r(s, deck, 2 + x, top, 1, 2)                                   

        if x % 8 == 0 and x < P:

            _r(s, deck_dk, 2 + x, top + 1, 1, 1)

    top_plat = base - H

    for lx in (6, 26):                                                

        _r(s, frame, 2 + lx, top_plat + 5, 3, H - 2)

        _r(s, bolt, 2 + lx, top_plat + 5, 3, 1)

    for i in range(17):                                                

        _r(s, frame, 2 + 9 + i, top_plat + 7 + int(i * 1.6), 1, 2)

    _r(s, frame, 3, top_plat - PAD + 1, 2, PAD)                   

    for i in range(6):

        _r(s, (232, 60, 72), 5 + i, top_plat - PAD + 1 + i // 2, 1, 5 - i // 2)

    _r(s, deck, 3, top_plat - PAD, 2, 1)

    return add_outline(s)





def make_helicopter():

                                                                               

    frames = []

    body, body_dk, glass = (216, 56, 64), (150, 34, 48), (140, 232, 240)

    metal, dark = (170, 176, 192), (60, 56, 78)

    for blade in (0, 1):

        s = pygame.Surface((32, 15), pygame.SRCALPHA)

        if blade == 0:                                                

            _r(s, metal, 1, 1, 30, 1)

        else:                                                           

            _r(s, metal, 9, 1, 14, 1)

            _r(s, dark, 5, 1, 3, 1)

            _r(s, dark, 24, 1, 3, 1)

        _r(s, dark, 15, 2, 2, 2)                                   

        _r(s, body, 10, 4, 14, 6)                            

        _r(s, body, 12, 3, 9, 1)

        _r(s, body_dk, 10, 9, 14, 1)

        _r(s, glass, 19, 5, 5, 3)                            

        _r(s, (255, 255, 255), 20, 5, 1, 1)                

        _r(s, metal, 2, 5, 9, 2)                                      

        _r(s, body, 0, 3, 3, 5)                            

        if blade == 0:                                               

            _r(s, metal, 0, 2, 1, 7)

        else:

            _r(s, metal, 0, 4, 2, 3)

        _r(s, dark, 11, 12, 13, 1)                         

        _r(s, dark, 13, 10, 1, 2)

        _r(s, dark, 21, 10, 1, 2)

        frames.append(add_outline(s))

    return frames





def make_drone():

    s = pygame.Surface((20, 10), pygame.SRCALPHA)

    body, lens, rotor = (58, 54, 72), (250, 96, 96), (190, 192, 210)

    _r(s, rotor, 0, 1, 20, 1)

    _r(s, body, 5, 3, 10, 5)

    _r(s, lens, 13, 4, 3, 3)

    _r(s, (36, 34, 46), 1, 2, 3, 2)

    _r(s, (36, 34, 46), 16, 2, 3, 2)

    return add_outline(s)





def make_cassette(label_color=(250, 214, 60)):

                                                                   

    s = pygame.Surface((14, 10), pygame.SRCALPHA)

    shell, ink, hole = (46, 42, 58), (34, 30, 44), (250, 244, 220)

    dark = tuple(int(c * 0.68) for c in label_color)

    _r(s, shell, 0, 0, 14, 10)

    _r(s, label_color, 1, 1, 12, 5)                        

    _r(s, dark, 1, 5, 12, 1)

    for y in (2, 3):                                                        

        _r(s, ink, 3, y, 8 - y, 1)

    _r(s, hole, 3, 7, 3, 2)                               

    _r(s, hole, 8, 7, 3, 2)

    _r(s, ink, 4, 7, 1, 2)

    _r(s, ink, 9, 7, 1, 2)

    return add_outline(s)





def make_tape_pickup(label_color=(250, 214, 60)):

    
                                                                           

    w, h = 20, 14

    s = pygame.Surface((w, h), pygame.SRCALPHA)

    shell, shell_hi, shell_dk = (60, 54, 78), (104, 96, 128), (32, 28, 42)

    light = tuple(min(255, c + 60) for c in label_color)

    dark = tuple(int(c * 0.62) for c in label_color)

    reel, tape, bolt = (250, 244, 222), (112, 64, 38), (176, 170, 196)

    _r(s, shell, 1, 0, w - 2, h)                                           

    _r(s, shell, 0, 1, w, h - 2)

    _r(s, shell_hi, 1, 0, w - 2, 1)                                       

    _r(s, shell_hi, 0, 1, 1, h - 3)

    _r(s, shell_dk, 1, h - 1, w - 2, 1)

    _r(s, label_color, 2, 1, w - 4, 8)                       

    _r(s, light, 2, 1, w - 4, 1)

    _r(s, dark, 2, 8, w - 4, 1)

    _r(s, shell_dk, 4, 2, 7, 1)                                       

    _r(s, dark, 12, 2, 4, 1)

    _r(s, shell_dk, 4, 4, 12, 4)                           

    _r(s, tape, 7, 5, 6, 2)                                                

    for cx in (5, 13):                                             

        _r(s, reel, cx, 4, 2, 4)

        _r(s, reel, cx - 1, 5, 4, 2)

        _r(s, shell_dk, cx, 5, 2, 2)

    _r(s, shell_hi, 5, 10, w - 10, 3)                           

    _r(s, shell_dk, 7, 11, 2, 1)                                         

    _r(s, shell_dk, 11, 11, 2, 1)

    for x, y in ((1, 1), (w - 2, 1), (1, h - 2), (w - 2, h - 2)):

        _r(s, bolt, x, y, 1, 1)                                   

    return add_outline(s)





def make_star(n=17):

                                                                            

    s = pygame.Surface((n, n), pygame.SRCALPHA)

    cx, cy = n / 2.0, n / 2.0 + 0.6

    pts = []

    for i in range(10):

        r = n * 0.46 if i % 2 == 0 else n * 0.2

        a = math.radians(-90 + i * 36)

        pts.append((cx + r * math.cos(a), cy + r * math.sin(a)))

    gold, hi, shade = (252, 212, 56), (255, 248, 196), (222, 156, 22)

    pygame.draw.polygon(s, gold, pts)

    for y in range(n):                                                                        

        for x in range(n):

            if s.get_at((x, y)).a:

                d = (x - cx) + (y - cy)

                if d < -6.0 * n / 17.0:

                    s.set_at((x, y), hi)

                elif d > 4.0 * n / 17.0:

                    s.set_at((x, y), shade)

    return add_outline(s)





def make_heart(filled=True):

    s = pygame.Surface((9, 8), pygame.SRCALPHA)

    col = (238, 64, 88) if filled else (72, 60, 84)

    _r(s, col, 1, 1, 3, 2)

    _r(s, col, 5, 1, 3, 2)

    _r(s, col, 0, 2, 9, 3)

    _r(s, col, 1, 5, 7, 1)

    _r(s, col, 2, 6, 5, 1)

    _r(s, col, 3, 7, 3, 1)

    if filled:

        _r(s, (252, 150, 168), 1, 2, 2, 1)

    return add_outline(s)





def grow(surf, k=1.2):

                                                                                        

    w, h = surf.get_size()

    return pygame.transform.scale(surf, (max(1, round(w * k)), max(1, round(h * k))))





def scaled(surf, k):

                                                                                

    w, h = surf.get_size()

    return pygame.transform.scale(surf, (round(w * k), round(h * k)))

